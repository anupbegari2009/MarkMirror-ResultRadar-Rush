export type ActiveRoute = 'landing' | 'results' | 'dashboard' | 'analytics' | 'admin';

export interface DepartmentOption {
  id: number;
  code: string;
  name: string;
  headOfDepartment: string;
}

export interface BatchOption {
  id: number;
  batchCode: string;
  startYear: number;
  endYear: number;
  label: string;
}

export interface SemesterOption {
  id: number;
  semesterNumber: number;
  title: string;
  academicYear: string;
}

export interface FiltersMetadata {
  departments: DepartmentOption[];
  batches: BatchOption[];
  semesters: SemesterOption[];
}

export interface GradingRule {
  id: number;
  scaleName: string;
  letterGrade: string;
  gradePoint: number;
  minMarks: number;
  maxMarks: number;
  isPassing: boolean;
  isVerifiedRule: boolean;
  description: string;
}

export interface SubjectMarkDetail {
  subjectId: number;
  subjectCode: string;
  subjectName: string;
  maxInternal: number;
  maxExternal: number;
  maxMarks: number;
  isCreditBearing: boolean;
  internalMarks: number;
  externalMarks: number;
  totalMarks: number;
  letterGrade: string;
  gradePoint: number;
  credits: number;
  isAbsent: boolean;
  passStatus: 'PASS' | 'FAIL' | 'ABSENT';
}

export interface StudentResultRecord {
  resultId: number;
  student: {
    hallTicket: string;
    fullName: string;
    departmentCode: string;
    departmentName: string;
    branch: string;
    batchCode: string;
    batchLabel: string;
    email?: string;
    emailMasked?: string;
    identityVerified?: boolean;
  };
  semester: {
    semesterNumber: number;
    semesterTitle: string;
    academicYear: string;
  };
  summary: {
    sgpa: number;
    cgpa: number;
    totalCreditsAttempted: number;
    totalCreditsEarned: number;
    totalMarksObtained: number;
    totalMaxMarks: number;
    resultStatus: 'PASS' | 'FAIL' | 'ABSENT';
    publishedAt: string;
  };
  subjects: SubjectMarkDetail[];
  isDemoData: boolean;
  generatedAt: string;
}

export interface StudentAnalyticsResponse {
  student: {
    id: number;
    hallTicket: string;
    fullName: string;
    departmentCode: string;
    departmentName: string;
    batchCode: string;
  };
  kpis: {
    currentSgpa: number;
    overallCgpa: number;
    totalCreditsEarned: number;
    subjectsPassed: number;
    subjectsFailed: number;
    totalSubjectsEvaluated: number;
    averageScore: number;
    sgpaDeltaFromPrevious: number;
    semestersCompleted: number;
  };
  semesterHistory: Array<{
    resultId: number;
    semesterNumber: number;
    semesterTitle: string;
    academicYear: string;
    sgpa: number;
    cgpa: number;
    creditsAttempted: number;
    creditsEarned: number;
    totalMarksObtained: number;
    totalMaxMarks: number;
    resultStatus: 'PASS' | 'FAIL' | 'ABSENT';
  }>;
  isDemoData: boolean;
}

export interface ReevaluationEstimate {
  hallTicket: string;
  items: Array<{ subjectCode: string; subjectName: string; fee: number }>;
  subjectCount: number;
  feePerSubject: number;
  processingFee: number;
  subtotal: number;
  totalFee: number;
  isSampleFeeSchedule: boolean;
  disclaimer: string;
}

export interface AnalyticsOverview {
  totalStudents: number;
  totalDepartments: number;
  totalExamRecords: number;
  averageSgpa: number;
  averageCgpa: number;
  overallPassRate: number;
  isDemoData: boolean;
}

export interface SubjectPassRateItem {
  subjectId: number;
  subjectCode: string;
  subjectName: string;
  departmentCode: string;
  semesterNumber: number;
  credits: number;
  evaluatedCount: number;
  passedCount: number;
  failedCount: number;
  averageMarks: number;
  passRate: number;
  failRate: number;
}

export interface PassRatesResponse {
  subjects: SubjectPassRateItem[];
  highestPassSubject: SubjectPassRateItem | null;
  lowestPassSubject: SubjectPassRateItem | null;
  isDemoData: boolean;
}

export interface TopperEntry {
  rank: number;
  medal: 'GOLD' | 'SILVER' | 'BRONZE' | null;
  hallTicket: string;
  fullName: string;
  departmentCode: string;
  departmentName: string;
  batchCode: string;
  semesterNumber: number;
  sgpa: number;
  cgpa: number;
  creditsEarned: number;
  totalMarksObtained: number;
  resultStatus: string;
}

export interface CgpaDistributionResponse {
  totalStudents: number;
  distribution: Array<{
    range: string;
    count: number;
    percentage: number;
  }>;
  isDemoData: boolean;
}

export interface SubjectDifficultyItem {
  subjectCode: string;
  subjectName: string;
  departmentCode: string;
  semesterNumber: number;
  evaluatedCount: number;
  passRate: number;
  failRate: number;
  averageMarks: number;
  difficultyIndex: number;
  tier: string;
}

export interface BatchComparisonResponse {
  batches: Array<{
    batchCode: string;
    batchLabel: string;
    studentCount: number;
    resultCount: number;
    averageSgpa: number;
    averageCgpa: number;
    overallPassRate: number;
  }>;
  subjectComparison: Array<{
    batchCode: string;
    subjectCode: string;
    subjectName: string;
    semesterNumber: number;
    averageMarks: number;
    passRate: number;
  }>;
  isDemoData: boolean;
}

export interface AdminUser {
  id: number;
  username: string;
  fullName: string;
  email: string;
  role: 'SUPER_ADMIN' | 'EXAM_CELL' | 'FACULTY';
  departmentId: number | null;
}

export interface AdminStudentRow {
  id: number;
  hallTicket: string;
  fullName: string;
  departmentCode: string;
  departmentName: string;
  batchCode: string;
  currentSemester: number;
  email: string;
  isDemoData: number;
  latestCgpa: number | null;
}

export interface AdminResultRow {
  resultId: number;
  hallTicket: string;
  fullName: string;
  departmentCode: string;
  batchCode: string;
  semesterNumber: number;
  academicYear: string;
  sgpa: number;
  cgpa: number;
  totalCreditsEarned: number;
  totalMarksObtained: number;
  totalMaxMarks: number;
  resultStatus: string;
  publishedAt: string;
}

export interface AdminSubjectRow {
  id: number;
  subjectCode: string;
  subjectName: string;
  departmentCode: string;
  semesterNumber: number;
  credits: number;
  maxInternal: number;
  maxExternal: number;
  passInternalMin: number;
  passExternalMin: number;
  passTotalMin: number;
  isCreditBearing: number;
}
