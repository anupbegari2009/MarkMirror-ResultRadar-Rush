import type {
  AdminResultRow,
  AdminStudentRow,
  AdminSubjectRow,
  AdminUser,
  AnalyticsOverview,
  BatchComparisonResponse,
  CgpaDistributionResponse,
  FiltersMetadata,
  GradingRule,
  PassRatesResponse,
  ReevaluationEstimate,
  StudentAnalyticsResponse,
  StudentResultRecord,
  SubjectDifficultyItem,
  TopperEntry,
} from '../types/markmirror';

async function requestJson<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options?.headers || {}),
    },
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message =
      (data && (data.error || data.message)) || `Request failed with status ${response.status}`;
    throw new Error(String(message));
  }
  return data as T;
}

function buildQuery(params: Record<string, string | number | undefined>): string {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== '' && v !== 'ALL') {
      sp.set(k, String(v));
    }
  }
  const qs = sp.toString();
  return qs ? `?${qs}` : '';
}

export async function fetchStudentProfile(hallTicket: string, dob?: string) {
  const qs = buildQuery({ dob });
  return requestJson<{
    student: {
      hallTicket: string;
      fullName: string;
      departmentCode: string;
      departmentName: string;
      batchCode: string;
      batchLabel: string;
      currentSemester: number;
      email: string;
      identityVerified: boolean;
      isDemoData: boolean;
    };
    semesters: Array<{
      resultId: number;
      semesterNumber: number;
      semesterTitle: string;
      academicYear: string;
      sgpa: number;
      cgpa: number;
      resultStatus: string;
    }>;
  }>(`/api/students/${encodeURIComponent(hallTicket)}${qs}`);
}

export async function verifyStudentIdentity(hallTicket: string, dob: string) {
  return requestJson<{ verified: boolean; hallTicket: string; email: string }>(
    `/api/students/${encodeURIComponent(hallTicket)}/verify`,
    {
      method: 'POST',
      body: JSON.stringify({ dob }),
    }
  );
}

export async function fetchStudentResults(
  hallTicket: string,
  semester?: number,
  dob?: string
): Promise<{ hallTicket: string; count: number; results: StudentResultRecord[]; demoNotice: string }> {
  const qs = buildQuery({ semester, dob });
  return requestJson(`/api/students/${encodeURIComponent(hallTicket)}/results${qs}`);
}

export async function fetchResultById(resultId: number): Promise<StudentResultRecord> {
  return requestJson(`/api/results/${resultId}`);
}

export async function fetchStudentAnalytics(hallTicket: string): Promise<StudentAnalyticsResponse> {
  return requestJson(`/api/students/${encodeURIComponent(hallTicket)}/analytics`);
}

export async function estimateReevaluation(
  hallTicket: string,
  subjectCodes: string[],
  feePerSubject: number,
  processingFee: number
): Promise<ReevaluationEstimate> {
  return requestJson(`/api/students/${encodeURIComponent(hallTicket)}/reevaluation-estimate`, {
    method: 'POST',
    body: JSON.stringify({ subjectCodes, feePerSubject, processingFee }),
  });
}

export async function fetchFiltersMetadata(): Promise<FiltersMetadata> {
  return requestJson('/api/analytics/filters');
}

export async function fetchGradingScale(): Promise<{ rules: GradingRule[]; note: string }> {
  return requestJson('/api/analytics/grading-scale');
}

export async function fetchAnalyticsOverview(filters?: {
  department?: string;
  batch?: string;
  semester?: number;
}): Promise<AnalyticsOverview> {
  const qs = buildQuery({
    department: filters?.department,
    batch: filters?.batch,
    semester: filters?.semester,
  });
  return requestJson(`/api/analytics/overview${qs}`);
}

export async function fetchPassRates(filters?: {
  department?: string;
  batch?: string;
  semester?: number;
}): Promise<PassRatesResponse> {
  const qs = buildQuery({
    department: filters?.department,
    batch: filters?.batch,
    semester: filters?.semester,
  });
  return requestJson(`/api/analytics/pass-rates${qs}`);
}

export async function fetchToppers(filters?: {
  department?: string;
  batch?: string;
  semester?: number;
  limit?: number;
}): Promise<{ toppers: TopperEntry[]; isDemoData: boolean }> {
  const qs = buildQuery({
    department: filters?.department,
    batch: filters?.batch,
    semester: filters?.semester,
    limit: filters?.limit,
  });
  return requestJson(`/api/analytics/toppers${qs}`);
}

export async function fetchCgpaDistribution(filters?: {
  department?: string;
  batch?: string;
}): Promise<CgpaDistributionResponse> {
  const qs = buildQuery({
    department: filters?.department,
    batch: filters?.batch,
  });
  return requestJson(`/api/analytics/cgpa-distribution${qs}`);
}

export async function fetchSubjectDifficulty(filters?: {
  department?: string;
  batch?: string;
}): Promise<{ subjects: SubjectDifficultyItem[]; isDemoData: boolean }> {
  const qs = buildQuery({
    department: filters?.department,
    batch: filters?.batch,
  });
  return requestJson(`/api/analytics/subject-difficulty${qs}`);
}

export async function fetchBatchComparison(
  batches: string[],
  department?: string
): Promise<BatchComparisonResponse> {
  const qs = buildQuery({
    batches: batches.join(','),
    department,
  });
  return requestJson(`/api/analytics/batch-comparison${qs}`);
}

// Admin APIs
export async function adminLogin(username: string, password: string) {
  return requestJson<{ token: string; user: AdminUser }>('/api/admin/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  });
}

export async function adminGetMe(token: string) {
  return requestJson<{ user: AdminUser }>('/api/admin/auth/me', {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function adminListStudents(
  token: string,
  params: { page?: number; limit?: number; search?: string; department?: string }
) {
  const qs = buildQuery(params);
  return requestJson<{
    students: AdminStudentRow[];
    pagination: { page: number; limit: number; total: number; totalPages: number };
  }>(`/api/admin/students${qs}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function adminCreateStudent(
  token: string,
  payload: {
    hallTicket: string;
    fullName: string;
    departmentCode: string;
    batchCode: string;
    currentSemester: number;
    dobVerification: string;
    email: string;
  }
) {
  return requestJson<{ message: string; student: AdminStudentRow }>('/api/admin/students', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
}

export async function adminListSubjects(
  token: string,
  params?: { department?: string; semester?: number }
) {
  const qs = buildQuery(params || {});
  return requestJson<{ subjects: AdminSubjectRow[] }>(`/api/admin/subjects${qs}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function adminCreateSubject(
  token: string,
  payload: {
    subjectCode: string;
    subjectName: string;
    departmentCode: string;
    semesterNumber: number;
    credits: number;
    isCreditBearing: boolean;
  }
) {
  return requestJson<{ message: string }>('/api/admin/subjects', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
}

export async function adminListResults(
  token: string,
  params: { page?: number; limit?: number; search?: string; department?: string }
) {
  const qs = buildQuery(params);
  return requestJson<{
    results: AdminResultRow[];
    pagination: { page: number; limit: number; total: number; totalPages: number };
  }>(`/api/admin/results${qs}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export async function adminCreateResult(
  token: string,
  payload: {
    hallTicket: string;
    semesterNumber: number;
    academicYear: string;
    marks: Array<{ subjectCode: string; internalMarks: number; externalMarks: number; isAbsent?: boolean }>;
  }
) {
  return requestJson<{ message: string; resultId: number; sgpa: number; resultStatus: string }>(
    '/api/admin/results',
    {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify(payload),
    }
  );
}

export async function adminUpdateResult(
  token: string,
  resultId: number,
  marks: Array<{ subjectCode: string; internalMarks: number; externalMarks: number; isAbsent?: boolean }>
) {
  return requestJson<{ message: string; resultId: number; sgpa: number; resultStatus: string }>(
    `/api/admin/results/${resultId}`,
    {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify({ marks }),
    }
  );
}

export async function adminDeleteResult(token: string, resultId: number) {
  return requestJson<{ message: string }>(`/api/admin/results/${resultId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
}
