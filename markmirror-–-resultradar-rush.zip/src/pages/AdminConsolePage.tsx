import { KeyRound, LogOut, Pencil, Plus, Search, Shield, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import {
  adminCreateResult,
  adminCreateStudent,
  adminCreateSubject,
  adminDeleteResult,
  adminGetMe,
  adminListResults,
  adminListStudents,
  adminListSubjects,
  adminLogin,
  adminUpdateResult,
  fetchAnalyticsOverview,
  fetchFiltersMetadata,
  fetchGradingScale,
  fetchResultById,
} from '../services/api';
import type {
  AdminResultRow,
  AdminStudentRow,
  AdminSubjectRow,
  AdminUser,
  AnalyticsOverview,
  FiltersMetadata,
  GradingRule,
} from '../types/markmirror';

const TOKEN_STORAGE_KEY = 'markmirror_admin_jwt';

export function AdminConsolePage() {
  const [token, setToken] = useState<string>(() => localStorage.getItem(TOKEN_STORAGE_KEY) || '');
  const [user, setUser] = useState<AdminUser | null>(null);
  const [authLoading, setAuthLoading] = useState(Boolean(token));

  // Login form
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Dashboard data
  const [activeTab, setActiveTab] = useState<'students' | 'results' | 'subjects'>('results');
  const [overview, setOverview] = useState<AnalyticsOverview | null>(null);
  const [filtersMeta, setFiltersMeta] = useState<FiltersMetadata | null>(null);
  const [gradingRules, setGradingRules] = useState<GradingRule[]>([]);

  // Search & lists
  const [searchQuery, setSearchQuery] = useState('');
  const [deptFilter, setDeptFilter] = useState('ALL');
  const [students, setStudents] = useState<AdminStudentRow[]>([]);
  const [studentPage, setStudentPage] = useState(1);
  const [studentTotalPages, setStudentTotalPages] = useState(1);

  const [results, setResults] = useState<AdminResultRow[]>([]);
  const [resultPage, setResultPage] = useState(1);
  const [resultTotalPages, setResultTotalPages] = useState(1);

  const [subjects, setSubjects] = useState<AdminSubjectRow[]>([]);
  const [statusMessage, setStatusMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(
    null
  );

  // Modals / Forms
  const [showAddStudent, setShowAddStudent] = useState(false);
  const [newStudent, setNewStudent] = useState({
    hallTicket: '',
    fullName: '',
    departmentCode: 'CSE',
    batchCode: '2022-26',
    currentSemester: 5,
    dobVerification: '2004-06-15',
    email: '',
  });

  const [showAddSubject, setShowAddSubject] = useState(false);
  const [newSubject, setNewSubject] = useState({
    subjectCode: '',
    subjectName: '',
    departmentCode: 'CSE',
    semesterNumber: 5,
    credits: 3,
    isCreditBearing: true,
  });

  const [showPublishResult, setShowPublishResult] = useState(false);
  const [publishForm, setPublishForm] = useState({
    hallTicket: '',
    semesterNumber: 5,
    academicYear: '2024-25',
    departmentCode: 'CSE',
  });
  const [publishMarks, setPublishMarks] = useState<
    Array<{ subjectCode: string; subjectName: string; internalMarks: number; externalMarks: number }>
  >([]);

  const [editingResultId, setEditingResultId] = useState<number | null>(null);
  const [editMarks, setEditMarks] = useState<
    Array<{ subjectCode: string; subjectName: string; internalMarks: number; externalMarks: number; isAbsent: boolean }>
  >([]);
  const [confirmDeleteId, setConfirmDeleteId] = useState<number | null>(null);

  useEffect(() => {
    if (!token) {
      setAuthLoading(false);
      return;
    }
    adminGetMe(token)
      .then((res) => setUser(res.user))
      .catch(() => {
        localStorage.removeItem(TOKEN_STORAGE_KEY);
        setToken('');
        setUser(null);
      })
      .finally(() => setAuthLoading(false));
  }, [token]);

  const loadWorkspaceData = async (jwt: string) => {
    try {
      const [ov, fm, gs, st, rs, sb] = await Promise.all([
        fetchAnalyticsOverview(),
        fetchFiltersMetadata(),
        fetchGradingScale(),
        adminListStudents(jwt, { page: studentPage, limit: 15, search: searchQuery, department: deptFilter }),
        adminListResults(jwt, { page: resultPage, limit: 15, search: searchQuery, department: deptFilter }),
        adminListSubjects(jwt, { department: deptFilter }),
      ]);
      setOverview(ov);
      setFiltersMeta(fm);
      setGradingRules(gs.rules);
      setStudents(st.students);
      setStudentTotalPages(st.pagination.totalPages);
      setResults(rs.results);
      setResultTotalPages(rs.pagination.totalPages);
      setSubjects(sb.subjects);
    } catch (err) {
      setStatusMessage({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to load admin records.',
      });
    }
  };

  useEffect(() => {
    if (token && user) {
      loadWorkspaceData(token);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, user, studentPage, resultPage, searchQuery, deptFilter]);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    try {
      const res = await adminLogin(username, password);
      localStorage.setItem(TOKEN_STORAGE_KEY, res.token);
      setToken(res.token);
      setUser(res.user);
      setPassword('');
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : 'Authentication failed.');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    setToken('');
    setUser(null);
  };

  const handleCreateStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);
    try {
      const res = await adminCreateStudent(token, {
        ...newStudent,
        email:
          newStudent.email.trim() ||
          `${newStudent.hallTicket.trim().toLowerCase()}@demo.markmirror.edu`,
      });
      setStatusMessage({ type: 'ok', text: res.message });
      setShowAddStudent(false);
      setNewStudent({
        hallTicket: '',
        fullName: '',
        departmentCode: 'CSE',
        batchCode: '2022-26',
        currentSemester: 5,
        dobVerification: '2004-06-15',
        email: '',
      });
      loadWorkspaceData(token);
    } catch (err) {
      setStatusMessage({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to create student.',
      });
    }
  };

  const handleCreateSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);
    try {
      const res = await adminCreateSubject(token, newSubject);
      setStatusMessage({ type: 'ok', text: res.message });
      setShowAddSubject(false);
      setNewSubject({
        subjectCode: '',
        subjectName: '',
        departmentCode: 'CSE',
        semesterNumber: 5,
        credits: 3,
        isCreditBearing: true,
      });
      loadWorkspaceData(token);
    } catch (err) {
      setStatusMessage({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to create subject.',
      });
    }
  };

  const openPublishModal = async () => {
    setShowPublishResult(true);
    try {
      const res = await adminListSubjects(token, {
        department: publishForm.departmentCode,
        semester: publishForm.semesterNumber,
      });
      setPublishMarks(
        res.subjects.map((s) => ({
          subjectCode: s.subjectCode,
          subjectName: s.subjectName,
          internalMarks: 22,
          externalMarks: 50,
        }))
      );
    } catch {
      setPublishMarks([]);
    }
  };

  const refreshPublishSubjects = async (dept: string, sem: number) => {
    try {
      const res = await adminListSubjects(token, { department: dept, semester: sem });
      setPublishMarks(
        res.subjects.map((s) => ({
          subjectCode: s.subjectCode,
          subjectName: s.subjectName,
          internalMarks: 22,
          externalMarks: 50,
        }))
      );
    } catch {
      setPublishMarks([]);
    }
  };

  const handlePublishSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);
    try {
      const res = await adminCreateResult(token, {
        hallTicket: publishForm.hallTicket,
        semesterNumber: publishForm.semesterNumber,
        academicYear: publishForm.academicYear,
        marks: publishMarks.map((m) => ({
          subjectCode: m.subjectCode,
          internalMarks: m.internalMarks,
          externalMarks: m.externalMarks,
        })),
      });
      setStatusMessage({
        type: 'ok',
        text: `${res.message} Computed SGPA: ${res.sgpa.toFixed(2)} (${res.resultStatus}).`,
      });
      setShowPublishResult(false);
      loadWorkspaceData(token);
    } catch (err) {
      setStatusMessage({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to publish result.',
      });
    }
  };

  const openEditResult = async (resultId: number) => {
    try {
      const detail = await fetchResultById(resultId);
      setEditingResultId(resultId);
      setEditMarks(
        detail.subjects.map((s) => ({
          subjectCode: s.subjectCode,
          subjectName: s.subjectName,
          internalMarks: s.internalMarks,
          externalMarks: s.externalMarks,
          isAbsent: s.isAbsent,
        }))
      );
    } catch (err) {
      setStatusMessage({
        type: 'err',
        text: err instanceof Error ? err.message : 'Unable to load result details.',
      });
    }
  };

  const handleSaveEditResult = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingResultId) return;
    setStatusMessage(null);
    try {
      const res = await adminUpdateResult(token, editingResultId, editMarks);
      setStatusMessage({
        type: 'ok',
        text: `${res.message} Updated SGPA: ${res.sgpa.toFixed(2)} (${res.resultStatus}).`,
      });
      setEditingResultId(null);
      loadWorkspaceData(token);
    } catch (err) {
      setStatusMessage({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to update result.',
      });
    }
  };

  const handleDeleteResult = async (resultId: number) => {
    setStatusMessage(null);
    try {
      const res = await adminDeleteResult(token, resultId);
      setStatusMessage({ type: 'ok', text: res.message });
      setConfirmDeleteId(null);
      loadWorkspaceData(token);
    } catch (err) {
      setStatusMessage({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to delete result.',
      });
    }
  };

  if (authLoading) {
    return (
      <div className="max-w-md mx-auto py-20 text-center text-sm text-slate-600">
        Verifying administrator session...
      </div>
    );
  }

  // Protected Sign-In Gate
  if (!user) {
    return (
      <div className="max-w-lg mx-auto px-4 py-12">
        <div className="bg-white border border-slate-200 rounded-xl p-8 space-y-6">
          <div className="space-y-2">
            <div className="w-10 h-10 rounded-lg bg-slate-900 text-white flex items-center justify-center">
              <Shield className="w-5 h-5" />
            </div>
            <h1 className="font-display text-2xl font-bold text-slate-950">
              Examination Cell & Admin Sign In
            </h1>
            <p className="text-sm text-slate-600">
              Administrative endpoints require role-based JWT authentication. Sign in to manage
              student records, subjects, and examination results.
            </p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label htmlFor="admin-user" className="block text-xs font-medium text-slate-700 mb-1">
                Administrator Username
              </label>
              <input
                id="admin-user"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                className="w-full h-11 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm font-mono focus:outline-none focus:border-blue-700"
              />
            </div>

            <div>
              <label htmlFor="admin-pass" className="block text-xs font-medium text-slate-700 mb-1">
                Password
              </label>
              <input
                id="admin-pass"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                placeholder="Enter administrator password"
                className="w-full h-11 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:border-blue-700"
              />
            </div>

            {loginError && (
              <div className="text-xs font-medium text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                {loginError}
              </div>
            )}

            <button
              type="submit"
              className="w-full h-11 bg-slate-900 hover:bg-blue-800 text-white text-sm font-semibold rounded-lg transition-colors"
            >
              Sign In to Admin Console
            </button>
          </form>

          {/* Local Hackathon Demo Credentials Helper */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 text-xs text-slate-600 space-y-2">
            <div className="font-semibold text-slate-800 flex items-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-blue-700" />
              Demonstration Evaluator Access
            </div>
            <p>
              Seeded accounts: <span className="font-mono text-slate-900">admin</span> (Super Admin)
              or <span className="font-mono text-slate-900">faculty_cse</span> (Faculty).
            </p>
            <button
              type="button"
              onClick={() => {
                setUsername('admin');
                setPassword('MarkMirror@2026');
              }}
              className="text-blue-700 font-semibold hover:underline"
            >
              Prefill Demo Super Admin Credentials
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="text-xs text-slate-500">
            Authenticated as {user.fullName} · Role: {user.role}
          </div>
          <h1 className="font-display text-2xl font-bold text-slate-950 mt-0.5">
            Examination Administration Console
          </h1>
        </div>

        <button
          type="button"
          onClick={handleLogout}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors self-start sm:self-auto whitespace-nowrap shrink-0"
        >
          <LogOut className="w-3.5 h-3.5" />
          Sign Out
        </button>
      </section>

      {/* Admin Overview KPIs */}
      <section className="grid grid-cols-2 lg:grid-cols-5 gap-4 tabular-nums">
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Total Students</div>
          <div className="font-mono text-2xl font-bold text-slate-950 mt-1">
            {overview ? overview.totalStudents : '—'}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Departments</div>
          <div className="font-mono text-2xl font-bold text-slate-950 mt-1">
            {overview ? overview.totalDepartments : '—'}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Exam Records</div>
          <div className="font-mono text-2xl font-bold text-slate-950 mt-1">
            {overview ? overview.totalExamRecords : '—'}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Average SGPA</div>
          <div className="font-mono text-2xl font-bold text-blue-800 mt-1">
            {overview ? overview.averageSgpa.toFixed(2) : '—'}
          </div>
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4">
          <div className="text-xs text-slate-500">Overall Pass Rate</div>
          <div className="font-mono text-2xl font-bold text-emerald-700 mt-1">
            {overview ? `${overview.overallPassRate.toFixed(1)}%` : '—'}
          </div>
        </div>
      </section>

      {statusMessage && (
        <div
          className={`px-4 py-3 rounded-xl border text-sm font-medium ${
            statusMessage.type === 'ok'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          {statusMessage.text}
        </div>
      )}

      {/* Navigation Tabs + Filters */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 pb-4">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start">
            {(
              [
                ['results', 'Examination Results'],
                ['students', 'Student Directory'],
                ['subjects', 'Subjects & Grading Scale'],
              ] as const
            ).map(([tabId, label]) => (
              <button
                key={tabId}
                type="button"
                onClick={() => setActiveTab(tabId)}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === tabId
                    ? 'bg-white text-slate-950 shadow-sm'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setStudentPage(1);
                  setResultPage(1);
                }}
                placeholder="Search hall ticket or name..."
                className="h-9 pl-8 pr-3 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-blue-700"
              />
            </div>

            <select
              value={deptFilter}
              onChange={(e) => {
                setDeptFilter(e.target.value);
                setStudentPage(1);
                setResultPage(1);
              }}
              aria-label="Filter by department"
              className="h-9 px-3 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900"
            >
              <option value="ALL">All Departments</option>
              {filtersMeta?.departments.map((d) => (
                <option key={d.code} value={d.code}>
                  {d.code}
                </option>
              ))}
            </select>

            {user.role !== 'FACULTY' && activeTab === 'students' && (
              <button
                type="button"
                onClick={() => setShowAddStudent(true)}
                className="h-9 px-3.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Student
              </button>
            )}

            {user.role !== 'FACULTY' && activeTab === 'results' && (
              <button
                type="button"
                onClick={openPublishModal}
                className="h-9 px-3.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                Publish Result
              </button>
            )}

            {user.role !== 'FACULTY' && activeTab === 'subjects' && (
              <button
                type="button"
                onClick={() => setShowAddSubject(true)}
                className="h-9 px-3.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Subject
              </button>
            )}
          </div>
        </div>

        {/* Tab 1: Examination Results */}
        {activeTab === 'results' && (
          <div className="space-y-4">
            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left border-collapse text-xs sm:text-sm tabular-nums">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <th className="py-2.5 px-4">ID</th>
                    <th className="py-2.5 px-4">Hall Ticket</th>
                    <th className="py-2.5 px-4">Student</th>
                    <th className="py-2.5 px-4">Branch · Batch</th>
                    <th className="py-2.5 px-4">Sem</th>
                    <th className="py-2.5 px-4 text-right">SGPA</th>
                    <th className="py-2.5 px-4 text-right">CGPA</th>
                    <th className="py-2.5 px-4 text-center">Status</th>
                    <th className="py-2.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {results.map((r) => (
                    <tr key={r.resultId} className="hover:bg-slate-50">
                      <td className="py-2.5 px-4 font-mono text-xs text-slate-500">#{r.resultId}</td>
                      <td className="py-2.5 px-4 font-mono font-semibold text-slate-900">
                        {r.hallTicket}
                      </td>
                      <td className="py-2.5 px-4 font-medium text-slate-900">{r.fullName}</td>
                      <td className="py-2.5 px-4 text-slate-600">
                        {r.departmentCode} · {r.batchCode}
                      </td>
                      <td className="py-2.5 px-4 font-mono">Sem {r.semesterNumber}</td>
                      <td className="py-2.5 px-4 text-right font-mono font-semibold text-blue-800">
                        {r.sgpa.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono">{r.cgpa.toFixed(2)}</td>
                      <td
                        className={`py-2.5 px-4 text-center text-xs font-semibold ${
                          r.resultStatus === 'PASS' ? 'text-emerald-700' : 'text-red-700'
                        }`}
                      >
                        {r.resultStatus}
                      </td>
                      <td className="py-2.5 px-4 text-right">
                        {user.role !== 'FACULTY' ? (
                          <div className="inline-flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => openEditResult(r.resultId)}
                              className="p-1.5 text-slate-600 hover:text-blue-700 rounded hover:bg-slate-100"
                              title="Edit marks"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            {user.role === 'SUPER_ADMIN' && (
                              <button
                                type="button"
                                onClick={() => setConfirmDeleteId(r.resultId)}
                                className="p-1.5 text-slate-600 hover:text-red-700 rounded hover:bg-red-50"
                                title="Delete result"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        ) : (
                          <span className="text-xs text-slate-400">Read-only</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-600">
              <span>
                Page {resultPage} of {resultTotalPages}
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  disabled={resultPage <= 1}
                  onClick={() => setResultPage((p) => Math.max(1, p - 1))}
                  className="px-3 py-1.5 border border-slate-300 rounded-lg disabled:opacity-40"
                >
                  Previous
                </button>
                <button
                  type="button"
                  disabled={resultPage >= resultTotalPages}
                  onClick={() => setResultPage((p) => p + 1)}
                  className="px-3 py-1.5 border border-slate-300 rounded-lg disabled:opacity-40"
                >
                  Next
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Student Directory */}
        {activeTab === 'students' && (
          <div className="space-y-4">
            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left border-collapse text-xs sm:text-sm tabular-nums">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <th className="py-2.5 px-4">Hall Ticket</th>
                    <th className="py-2.5 px-4">Full Name</th>
                    <th className="py-2.5 px-4">Department</th>
                    <th className="py-2.5 px-4">Batch</th>
                    <th className="py-2.5 px-4 text-right">Current Sem</th>
                    <th className="py-2.5 px-4 text-right">Latest CGPA</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {students.map((st) => (
                    <tr key={st.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-4 font-mono font-semibold text-slate-900">
                        {st.hallTicket}
                      </td>
                      <td className="py-2.5 px-4 font-medium text-slate-900">{st.fullName}</td>
                      <td className="py-2.5 px-4 text-slate-600">
                        {st.departmentName} ({st.departmentCode})
                      </td>
                      <td className="py-2.5 px-4 font-mono text-slate-600">{st.batchCode}</td>
                      <td className="py-2.5 px-4 text-right font-mono">{st.currentSemester}</td>
                      <td className="py-2.5 px-4 text-right font-mono font-semibold text-blue-800">
                        {st.latestCgpa !== null ? st.latestCgpa.toFixed(2) : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-600">
              <span>
                Page {studentPage} of {studentTotalPages}
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  disabled={studentPage <= 1}
                  onClick={() => setStudentPage((p) => Math.max(1, p - 1))}
                  className="px-3 py-1.5 border border-slate-300 rounded-lg disabled:opacity-40"
                >
                  Previous
                </button>
                <button
                  type="button"
                  disabled={studentPage >= studentTotalPages}
                  onClick={() => setStudentPage((p) => p + 1)}
                  className="px-3 py-1.5 border border-slate-300 rounded-lg disabled:opacity-40"
                >
                  Next
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Subjects & Grading Scale */}
        {activeTab === 'subjects' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left border-collapse text-xs sm:text-sm tabular-nums">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <th className="py-2.5 px-4">Code</th>
                    <th className="py-2.5 px-4">Subject Name</th>
                    <th className="py-2.5 px-4">Dept</th>
                    <th className="py-2.5 px-4 text-right">Sem</th>
                    <th className="py-2.5 px-4 text-right">Credits</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {subjects.map((sub) => (
                    <tr key={sub.id} className="hover:bg-slate-50">
                      <td className="py-2 px-4 font-mono font-semibold text-slate-900">
                        {sub.subjectCode}
                      </td>
                      <td className="py-2 px-4 font-medium text-slate-900">{sub.subjectName}</td>
                      <td className="py-2 px-4 text-slate-600">{sub.departmentCode}</td>
                      <td className="py-2 px-4 text-right font-mono">{sub.semesterNumber}</td>
                      <td className="py-2 px-4 text-right font-mono">{sub.credits.toFixed(1)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="lg:col-span-4 border border-slate-200 rounded-lg p-4 space-y-3 self-start">
              <h3 className="font-display text-base font-semibold text-slate-950">
                Active Grading Scale Rules
              </h3>
              <div className="divide-y divide-slate-200 text-xs tabular-nums">
                {gradingRules.map((g) => (
                  <div key={g.letterGrade} className="py-2 flex items-center justify-between">
                    <div>
                      <span className="font-mono font-bold text-slate-900 mr-2">
                        {g.letterGrade}
                      </span>
                      <span className="text-slate-500">
                        ({g.letterGrade === 'AB' ? 'Absent' : `${g.minMarks}–${g.maxMarks}%`})
                      </span>
                    </div>
                    <span className="font-mono font-semibold text-blue-800">{g.gradePoint} pts</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </section>

      {/* Modal: Add Student */}
      {showAddStudent && (
        <div className="fixed inset-0 z-50 bg-slate-950/50 flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateStudent}
            className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4"
          >
            <h2 className="font-display text-lg font-bold text-slate-950">Enroll New Student</h2>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Hall Ticket</label>
                <input
                  type="text"
                  required
                  placeholder="22CSE155"
                  value={newStudent.hallTicket}
                  onChange={(e) =>
                    setNewStudent({ ...newStudent, hallTicket: e.target.value.toUpperCase() })
                  }
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Department</label>
                <select
                  value={newStudent.departmentCode}
                  onChange={(e) => setNewStudent({ ...newStudent, departmentCode: e.target.value })}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                >
                  <option value="CSE">CSE</option>
                  <option value="ECE">ECE</option>
                  <option value="MECH">MECH</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={newStudent.fullName}
                onChange={(e) => setNewStudent({ ...newStudent, fullName: e.target.value })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Batch</label>
                <select
                  value={newStudent.batchCode}
                  onChange={(e) => setNewStudent({ ...newStudent, batchCode: e.target.value })}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                >
                  <option value="2022-26">2022-26</option>
                  <option value="2023-27">2023-27</option>
                  <option value="2024-28">2024-28</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Current Semester
                </label>
                <input
                  type="number"
                  min={1}
                  max={8}
                  value={newStudent.currentSemester}
                  onChange={(e) =>
                    setNewStudent({ ...newStudent, currentSemester: Number(e.target.value) })
                  }
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddStudent(false)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 rounded-lg"
              >
                Create Student
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Add Subject */}
      {showAddSubject && (
        <div className="fixed inset-0 z-50 bg-slate-950/50 flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateSubject}
            className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 space-y-4"
          >
            <h2 className="font-display text-lg font-bold text-slate-950">Add Curriculum Subject</h2>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Subject Code</label>
                <input
                  type="text"
                  required
                  placeholder="CS507"
                  value={newSubject.subjectCode}
                  onChange={(e) =>
                    setNewSubject({ ...newSubject, subjectCode: e.target.value.toUpperCase() })
                  }
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Credits</label>
                <input
                  type="number"
                  min={0}
                  max={10}
                  step={0.5}
                  value={newSubject.credits}
                  onChange={(e) => setNewSubject({ ...newSubject, credits: Number(e.target.value) })}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Subject Name</label>
              <input
                type="text"
                required
                value={newSubject.subjectName}
                onChange={(e) => setNewSubject({ ...newSubject, subjectName: e.target.value })}
                className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Department</label>
                <select
                  value={newSubject.departmentCode}
                  onChange={(e) => setNewSubject({ ...newSubject, departmentCode: e.target.value })}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                >
                  <option value="CSE">CSE</option>
                  <option value="ECE">ECE</option>
                  <option value="MECH">MECH</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Semester</label>
                <input
                  type="number"
                  min={1}
                  max={5}
                  value={newSubject.semesterNumber}
                  onChange={(e) =>
                    setNewSubject({ ...newSubject, semesterNumber: Number(e.target.value) })
                  }
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddSubject(false)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 rounded-lg"
              >
                Save Subject
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Publish Result */}
      {showPublishResult && (
        <div className="fixed inset-0 z-50 bg-slate-950/50 flex items-center justify-center p-4 overflow-y-auto">
          <form
            onSubmit={handlePublishSubmit}
            className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full p-6 space-y-4 my-8"
          >
            <h2 className="font-display text-lg font-bold text-slate-950">
              Publish Examination Result (Auto-Calculates SGPA & CGPA)
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Hall Ticket</label>
                <input
                  type="text"
                  required
                  placeholder="22CSE155"
                  value={publishForm.hallTicket}
                  onChange={(e) =>
                    setPublishForm({ ...publishForm, hallTicket: e.target.value.toUpperCase() })
                  }
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Department</label>
                <select
                  value={publishForm.departmentCode}
                  onChange={(e) => {
                    const dept = e.target.value;
                    setPublishForm({ ...publishForm, departmentCode: dept });
                    refreshPublishSubjects(dept, publishForm.semesterNumber);
                  }}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm"
                >
                  <option value="CSE">CSE</option>
                  <option value="ECE">ECE</option>
                  <option value="MECH">MECH</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Semester</label>
                <input
                  type="number"
                  min={1}
                  max={5}
                  value={publishForm.semesterNumber}
                  onChange={(e) => {
                    const sem = Number(e.target.value);
                    setPublishForm({ ...publishForm, semesterNumber: sem });
                    refreshPublishSubjects(publishForm.departmentCode, sem);
                  }}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Academic Year
                </label>
                <input
                  type="text"
                  value={publishForm.academicYear}
                  onChange={(e) => setPublishForm({ ...publishForm, academicYear: e.target.value })}
                  className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm"
                />
              </div>
            </div>

            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs tabular-nums">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <th className="py-2 px-3">Subject</th>
                    <th className="py-2 px-3 text-right">Internal (0–30)</th>
                    <th className="py-2 px-3 text-right">External (0–70)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {publishMarks.map((m, idx) => (
                    <tr key={m.subjectCode}>
                      <td className="py-2 px-3 font-medium">
                        <span className="font-mono text-slate-500 mr-2">{m.subjectCode}</span>
                        {m.subjectName}
                      </td>
                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          min={0}
                          max={30}
                          value={m.internalMarks}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            setPublishMarks((prev) =>
                              prev.map((row, i) => (i === idx ? { ...row, internalMarks: val } : row))
                            );
                          }}
                          className="w-20 h-8 px-2 text-right bg-slate-50 border border-slate-300 rounded font-mono"
                        />
                      </td>
                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          min={0}
                          max={70}
                          value={m.externalMarks}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            setPublishMarks((prev) =>
                              prev.map((row, i) => (i === idx ? { ...row, externalMarks: val } : row))
                            );
                          }}
                          className="w-20 h-8 px-2 text-right bg-slate-50 border border-slate-300 rounded font-mono"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowPublishResult(false)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 rounded-lg"
              >
                Calculate & Publish
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Edit Result */}
      {editingResultId !== null && (
        <div className="fixed inset-0 z-50 bg-slate-950/50 flex items-center justify-center p-4 overflow-y-auto">
          <form
            onSubmit={handleSaveEditResult}
            className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full p-6 space-y-4 my-8"
          >
            <h2 className="font-display text-lg font-bold text-slate-950">
              Update Marks · Result #{editingResultId}
            </h2>
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-left text-xs tabular-nums">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <th className="py-2 px-3">Subject</th>
                    <th className="py-2 px-3 text-right">Internal (0–30)</th>
                    <th className="py-2 px-3 text-right">External (0–70)</th>
                    <th className="py-2 px-3 text-center">Absent</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {editMarks.map((m, idx) => (
                    <tr key={m.subjectCode}>
                      <td className="py-2 px-3 font-medium">
                        <span className="font-mono text-slate-500 mr-2">{m.subjectCode}</span>
                        {m.subjectName}
                      </td>
                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          min={0}
                          max={30}
                          disabled={m.isAbsent}
                          value={m.internalMarks}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            setEditMarks((prev) =>
                              prev.map((row, i) => (i === idx ? { ...row, internalMarks: val } : row))
                            );
                          }}
                          className="w-20 h-8 px-2 text-right bg-slate-50 border border-slate-300 rounded font-mono disabled:opacity-40"
                        />
                      </td>
                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          min={0}
                          max={70}
                          disabled={m.isAbsent}
                          value={m.externalMarks}
                          onChange={(e) => {
                            const val = Number(e.target.value);
                            setEditMarks((prev) =>
                              prev.map((row, i) => (i === idx ? { ...row, externalMarks: val } : row))
                            );
                          }}
                          className="w-20 h-8 px-2 text-right bg-slate-50 border border-slate-300 rounded font-mono disabled:opacity-40"
                        />
                      </td>
                      <td className="py-2 px-3 text-center">
                        <input
                          type="checkbox"
                          checked={m.isAbsent}
                          onChange={(e) => {
                            const checked = e.target.checked;
                            setEditMarks((prev) =>
                              prev.map((row, i) => (i === idx ? { ...row, isAbsent: checked } : row))
                            );
                          }}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingResultId(null)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-700 rounded-lg"
              >
                Recalculate & Save
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Confirm Delete */}
      {confirmDeleteId !== null && (
        <div className="fixed inset-0 z-50 bg-slate-950/50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-xl max-w-sm w-full p-6 space-y-4">
            <h2 className="font-display text-lg font-bold text-slate-950">Delete Result Record?</h2>
            <p className="text-sm text-slate-600">
              Result #{confirmDeleteId} will be permanently removed and the student&apos;s CGPA
              history will be recomputed.
            </p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmDeleteId(null)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 rounded-lg"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleDeleteResult(confirmDeleteId)}
                className="px-4 py-2 text-xs font-semibold text-white bg-red-700 hover:bg-red-800 rounded-lg"
              >
                Delete Record
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
