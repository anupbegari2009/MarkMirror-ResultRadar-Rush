import type { ChartConfiguration } from 'chart.js';
import { ArrowRight, BarChart3, Calculator, FileCheck2, Search, ShieldCheck } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { ChartCanvas } from '../components/ChartCanvas';
import { UniversityCrest } from '../components/UniversityCrest';
import {
  fetchAnalyticsOverview,
  fetchPassRates,
  fetchStudentResults,
} from '../services/api';
import type {
  ActiveRoute,
  AnalyticsOverview,
  PassRatesResponse,
  StudentResultRecord,
} from '../types/markmirror';

interface LandingPageProps {
  onLookupHallTicket: (hallTicket: string, semester?: number) => void;
  onNavigate: (route: ActiveRoute) => void;
}

export function LandingPage({ onLookupHallTicket, onNavigate }: LandingPageProps) {
  const [hallTicketInput, setHallTicketInput] = useState('22CSE104');
  const [inputError, setInputError] = useState<string | null>(null);
  const [overview, setOverview] = useState<AnalyticsOverview | null>(null);
  const [passRates, setPassRates] = useState<PassRatesResponse | null>(null);
  const [sampleRecord, setSampleRecord] = useState<StudentResultRecord | null>(null);
  const [loadingPreview, setLoadingPreview] = useState(true);

  useEffect(() => {
    let active = true;
    Promise.all([
      fetchAnalyticsOverview(),
      fetchPassRates({ department: 'CSE', semester: 5 }),
      fetchStudentResults('22CSE104', 5),
    ])
      .then(([ov, pr, sr]) => {
        if (!active) return;
        setOverview(ov);
        setPassRates(pr);
        setSampleRecord(sr.results[0] || null);
      })
      .catch(() => {
        // Fallback handled gracefully by empty/skeleton state
      })
      .finally(() => {
        if (active) setLoadingPreview(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = hallTicketInput.trim().toUpperCase();
    if (!/^[0-9]{2}[A-Z]{2,6}[0-9]{2,5}$/.test(cleaned)) {
      setInputError('Enter a valid hall ticket number (e.g. 22CSE104).');
      return;
    }
    setInputError(null);
    onLookupHallTicket(cleaned);
  };

  const previewChartConfig = useMemo<ChartConfiguration | null>(() => {
    if (!passRates || passRates.subjects.length === 0) return null;
    return {
      type: 'bar',
      data: {
        labels: passRates.subjects.map((s) => s.subjectName),
        datasets: [
          {
            label: 'Pass Rate (%)',
            data: passRates.subjects.map((s) => s.passRate),
            backgroundColor: passRates.subjects.map((s) =>
              s.subjectCode === 'CS503' ? '#B91C1C' : '#1D4ED8'
            ),
            borderRadius: 6,
            maxBarThickness: 38,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.parsed.y}% Pass Rate`,
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            grid: { color: '#E2E8F0' },
            ticks: {
              callback: (v) => `${v}%`,
              color: '#475569',
              font: { family: 'JetBrains Mono, monospace', size: 11 },
            },
          },
          x: {
            grid: { display: false },
            ticks: {
              color: '#334155',
              font: { family: 'Public Sans, sans-serif', size: 11 },
            },
          },
        },
      },
    };
  }, [passRates]);

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Section */}
      <section className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            {/* Left Column: Primary Lookup CTA */}
            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              <div className="text-xs font-medium text-slate-500">
                Examination Portal · ResultRadar Rush · Demonstration Dataset
              </div>

              <h1 className="font-display text-3xl sm:text-4xl lg:text-[42px] font-bold tracking-tight text-slate-950 leading-[1.15] text-balance">
                Centralized university examination results and academic analytics.
              </h1>

              <p className="text-base text-slate-600 max-w-2xl leading-relaxed">
                Look up semester marks by hall ticket number, compute credit-weighted SGPA and CGPA,
                export A4 printable marksheets, and inspect department-wide pass trends backed by a
                normalized SQLite academic ledger.
              </p>

              {/* Hall Ticket Quick Search */}
              <form onSubmit={handleSubmit} className="max-w-xl space-y-2.5">
                <div className="flex flex-col sm:flex-row gap-2.5">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={hallTicketInput}
                      onChange={(e) => {
                        setHallTicketInput(e.target.value.toUpperCase());
                        if (inputError) setInputError(null);
                      }}
                      placeholder="Enter Hall Ticket (e.g. 22CSE104)"
                      aria-label="Hall ticket number"
                      className="w-full h-12 pl-10 pr-4 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm font-medium text-slate-950 placeholder:text-slate-400 focus:outline-none focus:border-blue-700 focus:bg-white transition-colors"
                    />
                  </div>
                  <button
                    type="submit"
                    className="h-12 px-6 bg-blue-700 hover:bg-blue-800 text-white text-sm font-semibold rounded-lg transition-colors duration-150 inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
                  >
                    Search Results
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

                {inputError && <p className="text-xs font-medium text-red-700">{inputError}</p>}

                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                  <span>Quick demonstration records:</span>
                  {['22CSE104', '22CSE101', '22ECE101', '22MECH101'].map((sample) => (
                    <button
                      key={sample}
                      type="button"
                      onClick={() => {
                        setHallTicketInput(sample);
                        setInputError(null);
                        onLookupHallTicket(sample);
                      }}
                      className="font-mono font-medium text-blue-700 hover:text-blue-900 underline underline-offset-2"
                    >
                      {sample}
                    </button>
                  ))}
                </div>
              </form>
            </div>

            {/* Right Column: Live Verified Sample Transcript Preview */}
            <div className="lg:col-span-5 flex">
              <div className="w-full bg-slate-900 text-white rounded-xl border border-slate-800 p-6 flex flex-col justify-between space-y-5">
                <div className="flex items-start justify-between gap-4 border-b border-slate-800 pb-4">
                  <div className="flex items-center gap-3">
                    <UniversityCrest className="w-10 h-10 shrink-0" />
                    <div>
                      <div className="text-xs text-slate-400">Live Database Sample</div>
                      <div className="font-display text-base font-semibold text-white">
                        {sampleRecord ? sampleRecord.student.fullName : 'Loading record...'}
                      </div>
                    </div>
                  </div>
                  <span className="font-mono text-xs text-slate-300">
                    {sampleRecord ? sampleRecord.student.hallTicket : '22CSE104'}
                  </span>
                </div>

                {loadingPreview ? (
                  <div className="space-y-3 py-4">
                    <div className="h-4 bg-slate-800 rounded w-3/4" />
                    <div className="h-4 bg-slate-800 rounded w-full" />
                    <div className="h-4 bg-slate-800 rounded w-5/6" />
                  </div>
                ) : sampleRecord ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-3 tabular-nums">
                      <div className="bg-slate-800/70 rounded-lg p-3">
                        <div className="text-[11px] text-slate-400">Sem 5 SGPA</div>
                        <div className="font-mono text-xl font-bold text-white mt-0.5">
                          {sampleRecord.summary.sgpa.toFixed(2)}
                        </div>
                      </div>
                      <div className="bg-slate-800/70 rounded-lg p-3">
                        <div className="text-[11px] text-slate-400">Overall CGPA</div>
                        <div className="font-mono text-xl font-bold text-white mt-0.5">
                          {sampleRecord.summary.cgpa.toFixed(2)}
                        </div>
                      </div>
                      <div className="bg-slate-800/70 rounded-lg p-3">
                        <div className="text-[11px] text-slate-400">Status</div>
                        <div className="font-mono text-sm font-bold text-emerald-400 mt-1.5">
                          {sampleRecord.summary.resultStatus}
                        </div>
                      </div>
                    </div>

                    <div className="divide-y divide-slate-800 text-xs tabular-nums">
                      {sampleRecord.subjects.slice(0, 4).map((subj) => (
                        <div key={subj.subjectCode} className="py-2 flex items-center justify-between gap-2">
                          <div className="truncate text-slate-200">
                            <span className="font-mono text-slate-400 mr-2">{subj.subjectCode}</span>
                            {subj.subjectName}
                          </div>
                          <div className="font-mono text-slate-100 shrink-0">
                            {subj.totalMarks} · {subj.letterGrade}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-slate-300">Unable to load preview record.</div>
                )}

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400">Demonstration Data · Verified by Engine</span>
                  <button
                    type="button"
                    onClick={() => onLookupHallTicket('22CSE104', 5)}
                    className="font-semibold text-blue-400 hover:text-blue-300 inline-flex items-center gap-1"
                  >
                    Open Full Marksheet
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 4-Column Live KPI Strip */}
          <div className="mt-10 pt-8 border-t border-slate-200 grid grid-cols-2 lg:grid-cols-4 gap-6 tabular-nums">
            <div>
              <div className="text-xs font-medium text-slate-500">Registered Students</div>
              <div className="font-mono text-2xl font-bold text-slate-950 mt-1">
                {overview ? overview.totalStudents : '—'}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Across 3 engineering cohorts</div>
            </div>
            <div>
              <div className="text-xs font-medium text-slate-500">Published Exam Records</div>
              <div className="font-mono text-2xl font-bold text-slate-950 mt-1">
                {overview ? overview.totalExamRecords : '—'}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Semesters 1 through 5</div>
            </div>
            <div>
              <div className="text-xs font-medium text-slate-500">Institution Average SGPA</div>
              <div className="font-mono text-2xl font-bold text-slate-950 mt-1">
                {overview ? overview.averageSgpa.toFixed(2) : '—'}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Credit-weighted calculation</div>
            </div>
            <div>
              <div className="text-xs font-medium text-slate-500">Overall Pass Percentage</div>
              <div className="font-mono text-2xl font-bold text-emerald-700 mt-1">
                {overview ? `${overview.overallPassRate.toFixed(1)}%` : '—'}
              </div>
              <div className="text-xs text-slate-500 mt-0.5">Calculated from SQLite ledger</div>
            </div>
          </div>
        </div>
      </section>

      {/* Platform Capabilities */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="max-w-2xl">
          <h2 className="font-display text-2xl font-bold text-slate-950 tracking-tight">
            Designed for examination cells, faculty advisors, and students
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Every view queries the relational SQLite database in real time—no static spreadsheets or
            client-side mock totals.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <button
            type="button"
            onClick={() => onNavigate('results')}
            className="text-left bg-white border border-slate-200 hover:border-blue-300 rounded-xl p-6 transition-colors space-y-3"
          >
            <FileCheck2 className="w-5 h-5 text-blue-700" />
            <h3 className="font-display text-base font-semibold text-slate-950">
              Official A4 Marksheets
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Subject-wise internal, external, and grade points with one-click A4 PDF download and
              print formatting.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className="text-left bg-white border border-slate-200 hover:border-blue-300 rounded-xl p-6 transition-colors space-y-3"
          >
            <Calculator className="w-5 h-5 text-blue-700" />
            <h3 className="font-display text-base font-semibold text-slate-950">
              SGPA & CGPA Progression
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Credit-weighted semester tracking, earned credits ledger, and historical trend lines
              across terms.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('analytics')}
            className="text-left bg-white border border-slate-200 hover:border-blue-300 rounded-xl p-6 transition-colors space-y-3"
          >
            <BarChart3 className="w-5 h-5 text-blue-700" />
            <h3 className="font-display text-base font-semibold text-slate-950">
              Batch & Subject Radar
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Pass-rate diagnostics, top-10 department leaderboards, CGPA histograms, and cohort
              comparisons.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('admin')}
            className="text-left bg-white border border-slate-200 hover:border-blue-300 rounded-xl p-6 transition-colors space-y-3"
          >
            <ShieldCheck className="w-5 h-5 text-blue-700" />
            <h3 className="font-display text-base font-semibold text-slate-950">
              Protected Admin Console
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Role-gated marks entry, student enrollment, and automatic SGPA/CGPA recalculation on
              every update.
            </p>
          </button>
        </div>
      </section>

      {/* Live Academic Analytics Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="font-display text-xl font-bold text-slate-950">
                CSE Semester 5 Subject Pass-Rate Preview
              </h2>
              <p className="text-sm text-slate-600 mt-1">
                Live SQL aggregation across 50 CSE students · Operating Systems flagged at 68.0%
                pass rate
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('analytics')}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-slate-900 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Open Batch Analytics
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {previewChartConfig ? (
            <ChartCanvas
              config={previewChartConfig}
              heightClass="h-72"
              ariaLabel="CSE Semester 5 subject pass rate bar chart"
            />
          ) : (
            <div className="h-72 bg-slate-50 rounded-lg flex items-center justify-center text-sm text-slate-500">
              Loading live subject pass-rate chart...
            </div>
          )}
        </div>
      </section>

      {/* Clean Institutional Footer */}
      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 border-t border-slate-200">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            <span className="font-semibold text-slate-700">MarkMirror – ResultRadar Rush</span> ·
            Demonstration academic examination ledger. Synthetic records are clearly marked and do
            not represent official university transcripts.
          </div>
          <div className="flex items-center gap-5 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('results')}
              className="hover:text-slate-900"
            >
              Result Lookup
            </button>
            <button
              type="button"
              onClick={() => onNavigate('analytics')}
              className="hover:text-slate-900"
            >
              Batch Analytics
            </button>
            <button
              type="button"
              onClick={() => onNavigate('admin')}
              className="hover:text-slate-900"
            >
              Admin Console
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
