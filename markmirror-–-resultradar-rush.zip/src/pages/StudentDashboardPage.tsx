import type { ChartConfiguration } from 'chart.js';
import { ArrowDownRight, ArrowUpRight, Search } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { ChartCanvas } from '../components/ChartCanvas';
import { fetchStudentAnalytics } from '../services/api';
import type { StudentAnalyticsResponse } from '../types/markmirror';

interface StudentDashboardPageProps {
  initialHallTicket: string;
  onOpenSemesterMarksheet: (hallTicket: string, semesterNumber: number) => void;
}

export function StudentDashboardPage({
  initialHallTicket,
  onOpenSemesterMarksheet,
}: StudentDashboardPageProps) {
  const [hallTicketInput, setHallTicketInput] = useState(initialHallTicket || '22CSE104');
  const [data, setData] = useState<StudentAnalyticsResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadAnalytics = async (ht: string) => {
    const cleaned = ht.trim().toUpperCase();
    if (!/^[0-9]{2}[A-Z]{2,6}[0-9]{2,5}$/.test(cleaned)) {
      setError('Enter a valid hall ticket number (e.g. 22CSE104).');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetchStudentAnalytics(cleaned);
      setData(res);
    } catch (err) {
      setData(null);
      setError(err instanceof Error ? err.message : 'Unable to load student analytics.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAnalytics(initialHallTicket || '22CSE104');
  }, [initialHallTicket]);

  const trendChartConfig = useMemo<ChartConfiguration | null>(() => {
    if (!data || data.semesterHistory.length === 0) return null;
    return {
      type: 'line',
      data: {
        labels: data.semesterHistory.map((s) => `Sem ${s.semesterNumber}`),
        datasets: [
          {
            label: 'Semester SGPA',
            data: data.semesterHistory.map((s) => s.sgpa),
            borderColor: '#1D4ED8',
            backgroundColor: 'rgba(29, 78, 216, 0.08)',
            tension: 0.25,
            fill: true,
            pointRadius: 5,
            pointBackgroundColor: '#1D4ED8',
          },
          {
            label: 'Cumulative CGPA',
            data: data.semesterHistory.map((s) => s.cgpa),
            borderColor: '#0F2547',
            borderDash: [5, 5],
            tension: 0.25,
            fill: false,
            pointRadius: 4,
            pointBackgroundColor: '#0F2547',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            align: 'end',
            labels: {
              usePointStyle: true,
              boxWidth: 8,
              color: '#334155',
              font: { family: 'Public Sans, sans-serif', size: 12 },
            },
          },
        },
        scales: {
          y: {
            min: 4,
            max: 10,
            grid: { color: '#E2E8F0' },
            ticks: {
              color: '#475569',
              font: { family: 'JetBrains Mono, monospace', size: 11 },
            },
          },
          x: {
            grid: { display: false },
            ticks: {
              color: '#334155',
              font: { family: 'Public Sans, sans-serif', size: 12 },
            },
          },
        },
      },
    };
  }, [data]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header & Hall Ticket Switcher */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-950">
            Student Academic Performance Dashboard
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Historical SGPA/CGPA progression, earned credits ledger, and semester summary.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            loadAnalytics(hallTicketInput);
          }}
          className="flex items-center gap-2"
        >
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={hallTicketInput}
              onChange={(e) => setHallTicketInput(e.target.value.toUpperCase())}
              placeholder="Hall Ticket"
              aria-label="Student hall ticket"
              className="h-10 w-44 pl-9 pr-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm font-medium text-slate-950 focus:outline-none focus:border-blue-700"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="h-10 px-4 bg-slate-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            Load Profile
          </button>
        </form>
      </section>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-5 text-sm text-red-800">
          {error}
        </div>
      )}

      {loading && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4 animate-pulse">
          <div className="h-6 bg-slate-200 rounded w-1/4" />
          <div className="h-64 bg-slate-100 rounded-lg" />
        </div>
      )}

      {!loading && data && (
        <div className="space-y-8">
          {/* Student Identity & 5 KPI Summary */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-4">
              <div>
                <div className="text-xs text-slate-500">
                  DEMONSTRATION DATA · Batch {data.student.batchCode}
                </div>
                <h2 className="font-display text-xl font-bold text-slate-950 mt-0.5">
                  {data.student.fullName} ·{' '}
                  <span className="font-mono text-blue-800">{data.student.hallTicket}</span>
                </h2>
              </div>
              <div className="text-sm text-slate-600">
                {data.student.departmentName} ({data.student.departmentCode})
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 tabular-nums">
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <div className="text-xs text-slate-500">Current SGPA</div>
                <div className="font-mono text-2xl font-bold text-blue-800 mt-1">
                  {data.kpis.currentSgpa.toFixed(2)}
                </div>
                {data.kpis.sgpaDeltaFromPrevious !== 0 && (
                  <div
                    className={`mt-1 text-xs font-medium inline-flex items-center gap-0.5 ${
                      data.kpis.sgpaDeltaFromPrevious > 0 ? 'text-emerald-700' : 'text-red-700'
                    }`}
                  >
                    {data.kpis.sgpaDeltaFromPrevious > 0 ? (
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    ) : (
                      <ArrowDownRight className="w-3.5 h-3.5" />
                    )}
                    {data.kpis.sgpaDeltaFromPrevious > 0 ? '+' : ''}
                    {data.kpis.sgpaDeltaFromPrevious.toFixed(2)} vs prev sem
                  </div>
                )}
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <div className="text-xs text-slate-500">Overall CGPA</div>
                <div className="font-mono text-2xl font-bold text-slate-950 mt-1">
                  {data.kpis.overallCgpa.toFixed(2)}
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  Across {data.kpis.semestersCompleted} semesters
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <div className="text-xs text-slate-500">Total Credits Earned</div>
                <div className="font-mono text-2xl font-bold text-slate-950 mt-1">
                  {data.kpis.totalCreditsEarned}
                </div>
                <div className="text-xs text-slate-500 mt-1">Credit-bearing courses</div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <div className="text-xs text-slate-500">Subjects Passed</div>
                <div className="font-mono text-2xl font-bold text-emerald-700 mt-1">
                  {data.kpis.subjectsPassed}
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  of {data.kpis.totalSubjectsEvaluated} evaluated
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <div className="text-xs text-slate-500">Subjects Failed</div>
                <div
                  className={`font-mono text-2xl font-bold mt-1 ${
                    data.kpis.subjectsFailed > 0 ? 'text-red-700' : 'text-slate-950'
                  }`}
                >
                  {data.kpis.subjectsFailed}
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  Avg score {data.kpis.averageScore}%
                </div>
              </div>
            </div>
          </section>

          {/* SGPA & CGPA Progression Chart */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div>
              <h3 className="font-display text-lg font-semibold text-slate-950">
                Historical Semester SGPA & CGPA Trend
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Semester-over-semester performance progression computed from historical examination
                records.
              </p>
            </div>
            {trendChartConfig ? (
              <ChartCanvas
                config={trendChartConfig}
                heightClass="h-72"
                ariaLabel="Student SGPA and CGPA progression chart"
              />
            ) : (
              <div className="h-72 flex items-center justify-center text-sm text-slate-500">
                No historical semester results available.
              </div>
            )}
          </section>

          {/* Semester History Table */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div>
              <h3 className="font-display text-lg font-semibold text-slate-950">
                Semester-Wise Academic Performance
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Select any semester row to view or print its official A4 marksheet.
              </p>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left border-collapse text-sm tabular-nums">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Semester</th>
                    <th className="py-3 px-4">Academic Year</th>
                    <th className="py-3 px-4 text-right">Marks</th>
                    <th className="py-3 px-4 text-right">Credits Earned</th>
                    <th className="py-3 px-4 text-right">SGPA</th>
                    <th className="py-3 px-4 text-right">CGPA</th>
                    <th className="py-3 px-4 text-center">Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {data.semesterHistory.map((sem) => (
                    <tr key={sem.resultId} className="hover:bg-slate-50">
                      <td className="py-3 px-4 font-medium text-slate-950">
                        {sem.semesterTitle}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-slate-600">
                        {sem.academicYear}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700">
                        {sem.totalMarksObtained} / {sem.totalMaxMarks}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700">
                        {sem.creditsEarned} / {sem.creditsAttempted}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-blue-800">
                        {sem.sgpa.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-semibold text-slate-900">
                        {sem.cgpa.toFixed(2)}
                      </td>
                      <td
                        className={`py-3 px-4 text-center text-xs font-semibold ${
                          sem.resultStatus === 'PASS' ? 'text-emerald-700' : 'text-red-700'
                        }`}
                      >
                        {sem.resultStatus}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() =>
                            onOpenSemesterMarksheet(data.student.hallTicket, sem.semesterNumber)
                          }
                          className="text-xs font-semibold text-blue-700 hover:text-blue-900 hover:underline whitespace-nowrap"
                        >
                          View Marksheet
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
