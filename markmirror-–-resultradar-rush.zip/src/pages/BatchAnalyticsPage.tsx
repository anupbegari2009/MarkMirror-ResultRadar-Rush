import type { ChartConfiguration } from 'chart.js';
import { Award, Filter, TrendingDown, TrendingUp } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { ChartCanvas } from '../components/ChartCanvas';
import {
  fetchAnalyticsOverview,
  fetchBatchComparison,
  fetchCgpaDistribution,
  fetchFiltersMetadata,
  fetchPassRates,
  fetchSubjectDifficulty,
  fetchToppers,
} from '../services/api';
import type {
  AnalyticsOverview,
  BatchComparisonResponse,
  CgpaDistributionResponse,
  FiltersMetadata,
  PassRatesResponse,
  SubjectDifficultyItem,
  TopperEntry,
} from '../types/markmirror';

interface BatchAnalyticsPageProps {
  onInspectStudent: (hallTicket: string, semester?: number) => void;
}

export function BatchAnalyticsPage({ onInspectStudent }: BatchAnalyticsPageProps) {
  const [filtersMeta, setFiltersMeta] = useState<FiltersMetadata | null>(null);
  const [department, setDepartment] = useState<string>('ALL');
  const [batch, setBatch] = useState<string>('ALL');
  const [semester, setSemester] = useState<string>('5');
  const [compareBatches, setCompareBatches] = useState<string[]>(['2022-26', '2023-27', '2024-28']);

  const [overview, setOverview] = useState<AnalyticsOverview | null>(null);
  const [passRates, setPassRates] = useState<PassRatesResponse | null>(null);
  const [toppers, setToppers] = useState<TopperEntry[]>([]);
  const [cgpaDist, setCgpaDist] = useState<CgpaDistributionResponse | null>(null);
  const [difficulty, setDifficulty] = useState<SubjectDifficultyItem[]>([]);
  const [batchComp, setBatchComp] = useState<BatchComparisonResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchFiltersMetadata()
      .then((meta) => setFiltersMeta(meta))
      .catch(() => {});
  }, []);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);

    const filterObj = {
      department: department === 'ALL' ? undefined : department,
      batch: batch === 'ALL' ? undefined : batch,
      semester: semester === 'ALL' ? undefined : Number(semester),
    };

    Promise.all([
      fetchAnalyticsOverview(filterObj),
      fetchPassRates(filterObj),
      fetchToppers({ ...filterObj, limit: 10 }),
      fetchCgpaDistribution({
        department: filterObj.department,
        batch: filterObj.batch,
      }),
      fetchSubjectDifficulty({
        department: filterObj.department,
        batch: filterObj.batch,
      }),
    ])
      .then(([ov, pr, tp, cg, df]) => {
        if (!active) return;
        setOverview(ov);
        setPassRates(pr);
        setToppers(tp.toppers);
        setCgpaDist(cg);
        setDifficulty(df.subjects);
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Failed to load analytics.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [department, batch, semester]);

  useEffect(() => {
    if (compareBatches.length === 0) return;
    let active = true;
    fetchBatchComparison(compareBatches, department === 'ALL' ? undefined : department)
      .then((res) => {
        if (active) setBatchComp(res);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [compareBatches, department]);

  const toggleCompareBatch = (code: string) => {
    setCompareBatches((prev) => {
      if (prev.includes(code)) {
        return prev.length > 1 ? prev.filter((c) => c !== code) : prev;
      }
      return [...prev, code];
    });
  };

  // Chart 1: Subject Pass-Rate Bar Chart
  const passRateChartConfig = useMemo<ChartConfiguration | null>(() => {
    if (!passRates || passRates.subjects.length === 0) return null;
    return {
      type: 'bar',
      data: {
        labels: passRates.subjects.map((s) => `${s.subjectName} (${s.subjectCode})`),
        datasets: [
          {
            label: 'Pass %',
            data: passRates.subjects.map((s) => s.passRate),
            backgroundColor: passRates.subjects.map((s) =>
              s.subjectCode === 'CS503' ? '#B91C1C' : '#1D4ED8'
            ),
            borderRadius: 6,
            maxBarThickness: 32,
          },
          {
            label: 'Fail %',
            data: passRates.subjects.map((s) => s.failRate),
            backgroundColor: '#CBD5E1',
            borderRadius: 6,
            maxBarThickness: 32,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            align: 'end',
            labels: {
              boxWidth: 10,
              color: '#334155',
              font: { family: 'Public Sans, sans-serif', size: 12 },
            },
          },
          tooltip: {
            callbacks: {
              label: (ctx) => `${ctx.dataset.label}: ${ctx.parsed.y}%`,
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            grid: { color: '#E2E8F0' },
            ticks: {
              callback: (v) => `${v}%`,
              color: '#475569',
              font: { family: 'JetBrains Mono, monospace', size: 11 },
            },
          },
          x: {
            grid: { display: false },
            ticks: {
              color: '#334155',
              font: { family: 'Public Sans, sans-serif', size: 11 },
            },
          },
        },
      },
    };
  }, [passRates]);

  // Chart 2: CGPA Distribution Histogram
  const cgpaChartConfig = useMemo<ChartConfiguration | null>(() => {
    if (!cgpaDist) return null;
    return {
      type: 'bar',
      data: {
        labels: cgpaDist.distribution.map((b) => b.range),
        datasets: [
          {
            label: 'Students',
            data: cgpaDist.distribution.map((b) => b.count),
            backgroundColor: ['#0F2547', '#1D4ED8', '#3B82F6', '#64748B', '#B91C1C'],
            borderRadius: 6,
            maxBarThickness: 48,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => {
                const idx = ctx.dataIndex;
                const item = cgpaDist.distribution[idx];
                return `${item.count} students (${item.percentage}%)`;
              },
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            grid: { color: '#E2E8F0' },
            ticks: {
              stepSize: 5,
              color: '#475569',
              font: { family: 'JetBrains Mono, monospace', size: 11 },
            },
          },
          x: {
            grid: { display: false },
            ticks: {
              color: '#334155',
              font: { family: 'JetBrains Mono, monospace', size: 12 },
            },
          },
        },
      },
    };
  }, [cgpaDist]);

  // Chart 3: Batch Comparison Grouped Bar Chart
  const batchCompChartConfig = useMemo<ChartConfiguration | null>(() => {
    if (!batchComp || batchComp.batches.length === 0) return null;
    return {
      type: 'bar',
      data: {
        labels: batchComp.batches.map((b) => b.batchCode),
        datasets: [
          {
            label: 'Average SGPA (×10)',
            data: batchComp.batches.map((b) => Math.round(b.averageSgpa * 100) / 10),
            backgroundColor: '#1D4ED8',
            borderRadius: 6,
            maxBarThickness: 36,
          },
          {
            label: 'Average CGPA (×10)',
            data: batchComp.batches.map((b) => Math.round(b.averageCgpa * 100) / 10),
            backgroundColor: '#0F2547',
            borderRadius: 6,
            maxBarThickness: 36,
          },
          {
            label: 'Overall Pass Rate (%)',
            data: batchComp.batches.map((b) => b.overallPassRate),
            backgroundColor: '#15803D',
            borderRadius: 6,
            maxBarThickness: 36,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            align: 'end',
            labels: {
              boxWidth: 10,
              color: '#334155',
              font: { family: 'Public Sans, sans-serif', size: 12 },
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            grid: { color: '#E2E8F0' },
            ticks: {
              color: '#475569',
              font: { family: 'JetBrains Mono, monospace', size: 11 },
            },
          },
          x: {
            grid: { display: false },
            ticks: {
              color: '#334155',
              font: { family: 'JetBrains Mono, monospace', size: 12 },
            },
          },
        },
      },
    };
  }, [batchComp]);

  const osSubject = passRates?.subjects.find((s) => s.subjectCode === 'CS503');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header & Interactive Filter Controls */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="text-xs text-slate-500">
              Faculty & Administration · Demonstration Data · Live SQLite Queries
            </div>
            <h1 className="font-display text-2xl font-bold text-slate-950 mt-0.5">
              Batch & Department Academic Analytics
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs font-medium text-slate-500">
              <Filter className="w-3.5 h-3.5" />
              Filters:
            </div>

            <select
              aria-label="Filter by department"
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="h-9 px-3 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-900 focus:outline-none focus:border-blue-700"
            >
              <option value="ALL">All Departments</option>
              {filtersMeta?.departments.map((d) => (
                <option key={d.code} value={d.code}>
                  {d.code} · {d.name}
                </option>
              ))}
            </select>

            <select
              aria-label="Filter by batch"
              value={batch}
              onChange={(e) => setBatch(e.target.value)}
              className="h-9 px-3 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-900 focus:outline-none focus:border-blue-700"
            >
              <option value="ALL">All Batches</option>
              {filtersMeta?.batches.map((b) => (
                <option key={b.batchCode} value={b.batchCode}>
                  Batch {b.batchCode}
                </option>
              ))}
            </select>

            <select
              aria-label="Filter by semester"
              value={semester}
              onChange={(e) => setSemester(e.target.value)}
              className="h-9 px-3 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-900 focus:outline-none focus:border-blue-700"
            >
              <option value="ALL">All Semesters</option>
              {filtersMeta?.semesters.map((s) => (
                <option key={s.semesterNumber} value={String(s.semesterNumber)}>
                  {s.title}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Overview KPI Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t border-slate-200 tabular-nums">
          <div>
            <div className="text-xs text-slate-500">Students in Scope</div>
            <div className="font-mono text-2xl font-bold text-slate-950 mt-0.5">
              {overview ? overview.totalStudents : '—'}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Exam Records Evaluated</div>
            <div className="font-mono text-2xl font-bold text-slate-950 mt-0.5">
              {overview ? overview.totalExamRecords : '—'}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Average SGPA</div>
            <div className="font-mono text-2xl font-bold text-blue-800 mt-0.5">
              {overview ? overview.averageSgpa.toFixed(2) : '—'}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Overall Pass Rate</div>
            <div className="font-mono text-2xl font-bold text-emerald-700 mt-0.5">
              {overview ? `${overview.overallPassRate.toFixed(1)}%` : '—'}
            </div>
          </div>
        </div>
      </section>

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {/* 1. Subject Pass-Rate Analytics */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <h2 className="font-display text-xl font-bold text-slate-950">
              1. Subject Pass-Rate Analytics
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Pass vs. failure percentage per subject computed directly from student grade records.
            </p>
          </div>

          {osSubject && (
            <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-2.5 text-xs text-red-900 shrink-0 tabular-nums">
              <div className="font-semibold">
                Bottleneck Highlight: {osSubject.subjectName} ({osSubject.subjectCode})
              </div>
              <div className="mt-0.5 font-mono">
                {osSubject.passRate.toFixed(1)}% Pass ({osSubject.passedCount}/{osSubject.evaluatedCount} passed)
              </div>
            </div>
          )}
        </div>

        {/* Highest & Lowest Pass-Rate Summary */}
        {passRates && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 tabular-nums">
            {passRates.highestPassSubject && (
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-500 flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-700" />
                    Highest Pass-Rate Subject
                  </div>
                  <div className="font-semibold text-slate-950 mt-1">
                    {passRates.highestPassSubject.subjectName} (
                    <span className="font-mono text-xs">{passRates.highestPassSubject.subjectCode}</span>)
                  </div>
                </div>
                <div className="font-mono text-xl font-bold text-emerald-700">
                  {passRates.highestPassSubject.passRate.toFixed(1)}%
                </div>
              </div>
            )}

            {passRates.lowestPassSubject && (
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-500 flex items-center gap-1">
                    <TrendingDown className="w-3.5 h-3.5 text-red-700" />
                    Lowest Pass-Rate Subject
                  </div>
                  <div className="font-semibold text-slate-950 mt-1">
                    {passRates.lowestPassSubject.subjectName} (
                    <span className="font-mono text-xs">{passRates.lowestPassSubject.subjectCode}</span>)
                  </div>
                </div>
                <div className="font-mono text-xl font-bold text-red-700">
                  {passRates.lowestPassSubject.passRate.toFixed(1)}%
                </div>
              </div>
            )}
          </div>
        )}

        {loading ? (
          <div className="h-80 bg-slate-50 rounded-lg animate-pulse" />
        ) : passRateChartConfig ? (
          <ChartCanvas
            config={passRateChartConfig}
            heightClass="h-80"
            ariaLabel="Subject pass rate and failure rate comparison bar chart"
          />
        ) : (
          <div className="h-48 flex items-center justify-center text-sm text-slate-500">
            No subject records match the selected filters.
          </div>
        )}

        {passRates && passRates.subjects.length > 0 && (
          <div className="overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full text-left border-collapse text-xs sm:text-sm tabular-nums">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-4">Code</th>
                  <th className="py-2.5 px-4">Subject</th>
                  <th className="py-2.5 px-4">Dept · Sem</th>
                  <th className="py-2.5 px-4 text-right">Evaluated</th>
                  <th className="py-2.5 px-4 text-right">Passed</th>
                  <th className="py-2.5 px-4 text-right">Pass %</th>
                  <th className="py-2.5 px-4 text-right">Fail %</th>
                  <th className="py-2.5 px-4 text-right">Avg Marks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {passRates.subjects.map((sub) => (
                  <tr
                    key={sub.subjectCode}
                    className={sub.subjectCode === 'CS503' ? 'bg-red-50/40' : 'hover:bg-slate-50'}
                  >
                    <td className="py-2.5 px-4 font-mono font-semibold text-slate-900">
                      {sub.subjectCode}
                    </td>
                    <td className="py-2.5 px-4 font-medium text-slate-900">{sub.subjectName}</td>
                    <td className="py-2.5 px-4 text-slate-600">
                      {sub.departmentCode} · Sem {sub.semesterNumber}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono">{sub.evaluatedCount}</td>
                    <td className="py-2.5 px-4 text-right font-mono">{sub.passedCount}</td>
                    <td
                      className={`py-2.5 px-4 text-right font-mono font-semibold ${
                        sub.passRate < 75 ? 'text-red-700' : 'text-emerald-700'
                      }`}
                    >
                      {sub.passRate.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono text-slate-600">
                      {sub.failRate.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono text-slate-800">
                      {sub.averageMarks.toFixed(1)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* 2. Department Topper Leaderboard & 3. CGPA Distribution Histogram */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-xl font-bold text-slate-950 flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-600" />
                2. Department Topper Leaderboard
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Top 10 performers ranked by CGPA/SGPA · Click any student to inspect marksheet
              </p>
            </div>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full text-left border-collapse text-xs sm:text-sm tabular-nums">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-3">Rank</th>
                  <th className="py-2.5 px-3">Hall Ticket</th>
                  <th className="py-2.5 px-3">Student Name</th>
                  <th className="py-2.5 px-3">Branch</th>
                  <th className="py-2.5 px-3 text-right">SGPA</th>
                  <th className="py-2.5 px-3 text-right">CGPA</th>
                  <th className="py-2.5 px-3 text-right">Credits</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {toppers.map((t) => {
                  const medalLabel =
                    t.medal === 'GOLD'
                      ? '1st · Gold'
                      : t.medal === 'SILVER'
                        ? '2nd · Silver'
                        : t.medal === 'BRONZE'
                          ? '3rd · Bronze'
                          : `#${t.rank}`;
                  return (
                    <tr
                      key={t.hallTicket}
                      onClick={() => onInspectStudent(t.hallTicket, t.semesterNumber)}
                      className={`cursor-pointer hover:bg-blue-50/50 transition-colors ${
                        t.rank <= 5 ? 'bg-slate-50/60' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3 font-mono font-semibold text-slate-900 whitespace-nowrap">
                        {medalLabel}
                      </td>
                      <td className="py-2.5 px-3 font-mono font-semibold text-blue-700">
                        {t.hallTicket}
                      </td>
                      <td className="py-2.5 px-3 font-medium text-slate-950">{t.fullName}</td>
                      <td className="py-2.5 px-3 text-slate-600">{t.departmentCode}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-900">
                        {t.sgpa.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-blue-800">
                        {t.cgpa.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-slate-700">
                        {t.creditsEarned}
                      </td>
                    </tr>
                  );
                })}
                {toppers.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-6 text-center text-slate-500">
                      No topper records for selected filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div>
            <h2 className="font-display text-xl font-bold text-slate-950">
              3. CGPA Distribution Histogram
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Distribution across {cgpaDist?.totalStudents ?? 0} evaluated students
            </p>
          </div>

          {cgpaChartConfig ? (
            <ChartCanvas
              config={cgpaChartConfig}
              heightClass="h-64"
              ariaLabel="CGPA distribution histogram"
            />
          ) : (
            <div className="h-64 flex items-center justify-center text-sm text-slate-500">
              No CGPA data available.
            </div>
          )}

          {cgpaDist && (
            <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg text-xs tabular-nums">
              {cgpaDist.distribution.map((bucket) => (
                <div key={bucket.range} className="px-3.5 py-2 flex items-center justify-between">
                  <span className="font-mono font-semibold text-slate-800">{bucket.range}</span>
                  <span className="text-slate-600">
                    <span className="font-mono font-semibold text-slate-950">{bucket.count}</span>{' '}
                    students ({bucket.percentage.toFixed(1)}%)
                  </span>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      {/* 4. Batch Comparison Tool */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-xl font-bold text-slate-950">
              4. Batch Comparison Analysis
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Compare average SGPA, cumulative CGPA, and overall pass percentages across graduating
              cohorts.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {['2022-26', '2023-27', '2024-28'].map((code) => {
              const active = compareBatches.includes(code);
              return (
                <button
                  key={code}
                  type="button"
                  onClick={() => toggleCompareBatch(code)}
                  className={`px-3 py-1.5 text-xs font-mono font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                    active
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  {code}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7">
            {batchCompChartConfig ? (
              <ChartCanvas
                config={batchCompChartConfig}
                heightClass="h-72"
                ariaLabel="Multi-batch SGPA, CGPA, and pass rate comparison chart"
              />
            ) : (
              <div className="h-72 flex items-center justify-center text-sm text-slate-500">
                Select batches to compare.
              </div>
            )}
          </div>

          <div className="lg:col-span-5 overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full text-left border-collapse text-xs sm:text-sm tabular-nums">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                  <th className="py-2.5 px-3">Batch</th>
                  <th className="py-2.5 px-3 text-right">Students</th>
                  <th className="py-2.5 px-3 text-right">Avg SGPA</th>
                  <th className="py-2.5 px-3 text-right">Avg CGPA</th>
                  <th className="py-2.5 px-3 text-right">Pass %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {batchComp?.batches.map((b) => (
                  <tr key={b.batchCode}>
                    <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">
                      {b.batchCode}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono">{b.studentCount}</td>
                    <td className="py-2.5 px-3 text-right font-mono font-semibold text-blue-800">
                      {b.averageSgpa.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-900">
                      {b.averageCgpa.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-semibold text-emerald-700">
                      {b.overallPassRate.toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* 5. Subject Difficulty Index */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-950">
            5. Subject Difficulty Index
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Composite difficulty score weighted by historical failure rate (70%) and mean score
            shortfall (30%).
          </p>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-lg">
          <table className="w-full text-left border-collapse text-xs sm:text-sm tabular-nums">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                <th className="py-2.5 px-4">Code</th>
                <th className="py-2.5 px-4">Subject Name</th>
                <th className="py-2.5 px-4">Dept · Sem</th>
                <th className="py-2.5 px-4 text-right">Fail Rate</th>
                <th className="py-2.5 px-4 text-right">Avg Marks</th>
                <th className="py-2.5 px-4 text-right">Difficulty Index</th>
                <th className="py-2.5 px-4">Classification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {difficulty.slice(0, 12).map((item) => (
                <tr key={item.subjectCode} className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-mono font-semibold text-slate-900">
                    {item.subjectCode}
                  </td>
                  <td className="py-2.5 px-4 font-medium text-slate-900">{item.subjectName}</td>
                  <td className="py-2.5 px-4 text-slate-600">
                    {item.departmentCode} · Sem {item.semesterNumber}
                  </td>
                  <td
                    className={`py-2.5 px-4 text-right font-mono font-semibold ${
                      item.failRate >= 25 ? 'text-red-700' : 'text-slate-700'
                    }`}
                  >
                    {item.failRate.toFixed(1)}%
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono">{item.averageMarks.toFixed(1)}</td>
                  <td className="py-2.5 px-4 text-right font-mono font-bold text-slate-950">
                    {item.difficultyIndex.toFixed(1)}
                  </td>
                  <td
                    className={`py-2.5 px-4 text-xs font-semibold ${
                      item.tier === 'High Difficulty'
                        ? 'text-red-700'
                        : item.tier === 'Moderate Difficulty'
                          ? 'text-amber-700'
                          : 'text-slate-600'
                    }`}
                  >
                    {item.tier}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
