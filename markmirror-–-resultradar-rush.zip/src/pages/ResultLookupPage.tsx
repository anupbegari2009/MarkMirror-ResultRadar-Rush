import {
  AlertCircle,
  Calculator,
  CheckCircle2,
  FileText,
  Lock,
  Search,
  ShieldCheck,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import { OfficialMarksheet } from '../components/OfficialMarksheet';
import {
  estimateReevaluation,
  fetchGradingScale,
  fetchStudentResults,
  verifyStudentIdentity,
} from '../services/api';
import type {
  ActiveRoute,
  GradingRule,
  ReevaluationEstimate,
  StudentResultRecord,
} from '../types/markmirror';

interface ResultLookupPageProps {
  initialHallTicket: string;
  initialSemester?: number;
  onSelectStudent: (hallTicket: string) => void;
  onNavigate: (route: ActiveRoute) => void;
}

export function ResultLookupPage({
  initialHallTicket,
  initialSemester,
  onSelectStudent,
  onNavigate,
}: ResultLookupPageProps) {
  const [hallTicket, setHallTicket] = useState(initialHallTicket || '22CSE104');
  const [semester, setSemester] = useState<string>(initialSemester ? String(initialSemester) : '5');
  const [dobInput, setDobInput] = useState('');
  const [verifiedEmail, setVerifiedEmail] = useState<string | null>(null);
  const [verifyMessage, setVerifyMessage] = useState<string | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [records, setRecords] = useState<StudentResultRecord[]>([]);
  const [viewMode, setViewMode] = useState<'details' | 'marksheet'>('details');
  const [gradingRules, setGradingRules] = useState<GradingRule[]>([]);
  const [gradingNote, setGradingNote] = useState('');

  // Re-evaluation estimator state
  const [selectedReevalCodes, setSelectedReevalCodes] = useState<string[]>([]);
  const [feePerSubject, setFeePerSubject] = useState(500);
  const [processingFee, setProcessingFee] = useState(100);
  const [reevalEstimate, setReevalEstimate] = useState<ReevaluationEstimate | null>(null);
  const [reevalError, setReevalError] = useState<string | null>(null);

  const executeLookup = async (ht: string, semStr: string, dob?: string) => {
    const cleaned = ht.trim().toUpperCase();
    if (!/^[0-9]{2}[A-Z]{2,6}[0-9]{2,5}$/.test(cleaned)) {
      setError('Invalid hall ticket format. Expected format like 22CSE104.');
      setRecords([]);
      return;
    }

    setLoading(true);
    setError(null);
    setReevalEstimate(null);
    setSelectedReevalCodes([]);
    try {
      const semNum = semStr === 'ALL' ? undefined : Number(semStr);
      const data = await fetchStudentResults(cleaned, semNum, dob || undefined);
      setRecords(data.results);
      onSelectStudent(cleaned);
    } catch (err) {
      setRecords([]);
      setError(err instanceof Error ? err.message : 'Failed to fetch student results.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGradingScale()
      .then((res) => {
        setGradingRules(res.rules);
        setGradingNote(res.note);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (initialHallTicket) {
      setHallTicket(initialHallTicket);
      const semToUse = initialSemester ? String(initialSemester) : semester;
      if (initialSemester) setSemester(String(initialSemester));
      executeLookup(initialHallTicket, semToUse);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialHallTicket, initialSemester]);

  const activeRecord = records[0] || null;

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setVerifiedEmail(null);
    setVerifyMessage(null);
    executeLookup(hallTicket, semester, dobInput);
  };

  const handleVerifyIdentity = async () => {
    if (!dobInput) {
      setVerifyMessage('Enter date of birth (YYYY-MM-DD) to verify identity.');
      return;
    }
    try {
      const res = await verifyStudentIdentity(hallTicket.trim().toUpperCase(), dobInput);
      setVerifiedEmail(res.email);
      setVerifyMessage('Identity verified. Unmasked student contact is now visible.');
      executeLookup(hallTicket, semester, dobInput);
    } catch (err) {
      setVerifiedEmail(null);
      setVerifyMessage(err instanceof Error ? err.message : 'Verification failed.');
    }
  };

  const toggleReevalSubject = (code: string) => {
    setSelectedReevalCodes((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]
    );
    setReevalEstimate(null);
    setReevalError(null);
  };

  const handleCalculateReeval = async () => {
    if (!activeRecord) return;
    if (selectedReevalCodes.length === 0) {
      setReevalError('Select at least one subject to estimate re-evaluation fees.');
      return;
    }
    setReevalError(null);
    try {
      const est = await estimateReevaluation(
        activeRecord.student.hallTicket,
        selectedReevalCodes,
        feePerSubject,
        processingFee
      );
      setReevalEstimate(est);
    } catch (err) {
      setReevalError(err instanceof Error ? err.message : 'Failed to calculate estimate.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header & Search Controls */}
      <section className="no-print bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-2xl font-bold text-slate-950">
              Student Examination Result Lookup
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Retrieve verified semester marksheets, SGPA/CGPA calculations, and official A4 PDF
              transcripts.
            </p>
          </div>
          {activeRecord && (
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start">
              <button
                type="button"
                onClick={() => setViewMode('details')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  viewMode === 'details'
                    ? 'bg-white text-slate-950 shadow-sm'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                Marks Breakdown
              </button>
              <button
                type="button"
                onClick={() => setViewMode('marksheet')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  viewMode === 'marksheet'
                    ? 'bg-white text-slate-950 shadow-sm'
                    : 'text-slate-600 hover:text-slate-950'
                }`}
              >
                Official A4 Marksheet
              </button>
            </div>
          )}
        </div>

        <form onSubmit={handleFormSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-4">
            <label htmlFor="ht-input" className="block text-xs font-medium text-slate-700 mb-1.5">
              Hall Ticket Number
            </label>
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="ht-input"
                type="text"
                value={hallTicket}
                onChange={(e) => setHallTicket(e.target.value.toUpperCase())}
                placeholder="e.g. 22CSE104"
                className="w-full h-11 pl-9 pr-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm font-medium text-slate-950 focus:outline-none focus:border-blue-700 focus:bg-white"
              />
            </div>
          </div>

          <div className="md:col-span-3">
            <label htmlFor="sem-select" className="block text-xs font-medium text-slate-700 mb-1.5">
              Semester
            </label>
            <select
              id="sem-select"
              value={semester}
              onChange={(e) => setSemester(e.target.value)}
              className="w-full h-11 px-3 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-700 focus:bg-white"
            >
              <option value="5">Semester 5</option>
              <option value="4">Semester 4</option>
              <option value="3">Semester 3</option>
              <option value="2">Semester 2</option>
              <option value="1">Semester 1</option>
              <option value="ALL">Latest Available Semester</option>
            </select>
          </div>

          <div className="md:col-span-3">
            <label htmlFor="dob-verify" className="block text-xs font-medium text-slate-700 mb-1.5">
              DOB Verification (Optional · Demo: 2004-05-14)
            </label>
            <input
              id="dob-verify"
              type="date"
              value={dobInput}
              onChange={(e) => setDobInput(e.target.value)}
              className="w-full h-11 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm text-slate-900 focus:outline-none focus:border-blue-700 focus:bg-white"
            />
          </div>

          <div className="md:col-span-2 flex gap-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full h-11 px-4 bg-blue-700 hover:bg-blue-800 disabled:opacity-60 text-white text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              {loading ? 'Searching...' : 'Fetch Result'}
            </button>
          </div>
        </form>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 text-xs text-slate-500">
          <div className="flex flex-wrap items-center gap-3">
            <span>Samples:</span>
            {['22CSE104', '22CSE101', '22CSE124', '22ECE102', '22MECH101'].map((sample) => (
              <button
                key={sample}
                type="button"
                onClick={() => {
                  setHallTicket(sample);
                  setSemester('5');
                  executeLookup(sample, '5');
                }}
                className="font-mono text-blue-700 hover:underline"
              >
                {sample}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleVerifyIdentity}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 hover:text-blue-700"
          >
            <Lock className="w-3.5 h-3.5" />
            Verify DOB for Unmasked Contact
          </button>
        </div>

        {verifyMessage && (
          <div
            className={`text-xs px-3 py-2 rounded-lg border ${
              verifiedEmail
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : 'bg-amber-50 border-amber-200 text-amber-800'
            }`}
          >
            {verifyMessage}
          </div>
        )}
      </section>

      {/* Loading State */}
      {loading && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4 animate-pulse">
          <div className="h-5 bg-slate-200 rounded w-1/3" />
          <div className="grid grid-cols-4 gap-4">
            <div className="h-16 bg-slate-100 rounded-lg" />
            <div className="h-16 bg-slate-100 rounded-lg" />
            <div className="h-16 bg-slate-100 rounded-lg" />
            <div className="h-16 bg-slate-100 rounded-lg" />
          </div>
          <div className="h-48 bg-slate-100 rounded-lg" />
        </div>
      )}

      {/* Error State */}
      {!loading && error && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-6 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h2 className="font-display text-base font-semibold text-red-900">
              Result Record Not Found
            </h2>
            <p className="text-sm text-red-800">{error}</p>
          </div>
        </div>
      )}

      {/* Empty State */}
      {!loading && !error && !activeRecord && (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
          <FileText className="w-8 h-8 text-slate-400 mx-auto" />
          <h2 className="font-display text-lg font-semibold text-slate-900">
            Enter a hall ticket number to inspect results
          </h2>
          <p className="text-sm text-slate-600 max-w-md mx-auto">
            Try demonstration hall ticket <span className="font-mono font-semibold">22CSE104</span>{' '}
            for Semester 5 to verify the 8.85 SGPA marksheet.
          </p>
        </div>
      )}

      {/* Populated Result View */}
      {!loading && activeRecord && viewMode === 'marksheet' && (
        <OfficialMarksheet
          record={activeRecord}
          onReturnToDashboard={() => onNavigate('dashboard')}
        />
      )}

      {!loading && activeRecord && viewMode === 'details' && (
        <div className="space-y-8">
          {/* Student Overview Card */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 pb-5">
              <div className="space-y-1">
                <div className="text-xs text-slate-500">
                  {activeRecord.isDemoData ? 'DEMONSTRATION DATA' : 'OFFICIAL RECORD'} ·{' '}
                  {activeRecord.semester.academicYear} · Batch {activeRecord.student.batchCode}
                </div>
                <h2 className="font-display text-2xl font-bold text-slate-950">
                  {activeRecord.student.fullName}
                </h2>
                <div className="text-sm text-slate-600 flex flex-wrap items-center gap-x-2 gap-y-1">
                  <span className="font-mono font-semibold text-slate-900">
                    {activeRecord.student.hallTicket}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {activeRecord.student.departmentName} ({activeRecord.student.departmentCode})
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{activeRecord.semester.semesterTitle}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-xs">
                    {activeRecord.student.email || activeRecord.student.emailMasked}
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setViewMode('marksheet')}
                  className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Open Official A4 Marksheet
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('dashboard')}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Student Trend Dashboard
                </button>
              </div>
            </div>

            {/* 4-Column Academic KPIs */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 tabular-nums">
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <div className="text-xs text-slate-500">Semester SGPA</div>
                <div className="font-mono text-2xl font-bold text-blue-800 mt-1">
                  {activeRecord.summary.sgpa.toFixed(2)}
                </div>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <div className="text-xs text-slate-500">Cumulative CGPA</div>
                <div className="font-mono text-2xl font-bold text-slate-950 mt-1">
                  {activeRecord.summary.cgpa.toFixed(2)}
                </div>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <div className="text-xs text-slate-500">Credits Earned</div>
                <div className="font-mono text-2xl font-bold text-slate-950 mt-1">
                  {activeRecord.summary.totalCreditsEarned} / {activeRecord.summary.totalCreditsAttempted}
                </div>
              </div>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
                <div className="text-xs text-slate-500">Result Status</div>
                <div
                  className={`font-display text-xl font-bold mt-1.5 inline-flex items-center gap-1.5 ${
                    activeRecord.summary.resultStatus === 'PASS' ? 'text-emerald-700' : 'text-red-700'
                  }`}
                >
                  <CheckCircle2 className="w-5 h-5" />
                  {activeRecord.summary.resultStatus}
                </div>
              </div>
            </div>

            {/* Subject-wise Marks Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <th className="py-3 px-4">Code</th>
                    <th className="py-3 px-4">Subject Name</th>
                    <th className="py-3 px-4 text-right">Internal</th>
                    <th className="py-3 px-4 text-right">External</th>
                    <th className="py-3 px-4 text-right">Total</th>
                    <th className="py-3 px-4 text-center">Grade</th>
                    <th className="py-3 px-4 text-right">Points</th>
                    <th className="py-3 px-4 text-right">Credits</th>
                    <th className="py-3 px-4 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 tabular-nums">
                  {activeRecord.subjects.map((sub) => (
                    <tr key={sub.subjectCode} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-mono text-xs font-semibold text-slate-900">
                        {sub.subjectCode}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-900">{sub.subjectName}</td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700">
                        {sub.isAbsent ? 'AB' : sub.internalMarks}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700">
                        {sub.isAbsent ? 'AB' : sub.externalMarks}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-semibold text-slate-950">
                        {sub.isAbsent ? 'AB' : sub.totalMarks}
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-slate-900">
                        {sub.letterGrade}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700">
                        {sub.gradePoint}
                      </td>
                      <td className="py-3 px-4 text-right font-mono text-slate-700">
                        {sub.credits.toFixed(1)}
                      </td>
                      <td
                        className={`py-3 px-4 text-center text-xs font-semibold ${
                          sub.passStatus === 'PASS' ? 'text-emerald-700' : 'text-red-700'
                        }`}
                      >
                        {sub.passStatus}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          {/* Stretch Feature: Re-evaluation Fee Estimator & Grading Scale */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <section className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="font-display text-lg font-semibold text-slate-950 flex items-center gap-2">
                    <Calculator className="w-4 h-4 text-blue-700" />
                    Re-evaluation Fee Estimator
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Configurable sample fee schedule for estimation only. Select subjects below.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {activeRecord.subjects.map((sub) => {
                  const checked = selectedReevalCodes.includes(sub.subjectCode);
                  return (
                    <label
                      key={sub.subjectCode}
                      className={`flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-lg border text-sm cursor-pointer transition-colors ${
                        checked
                          ? 'bg-blue-50 border-blue-300 text-slate-950'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <span className="flex items-center gap-2.5 truncate">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => toggleReevalSubject(sub.subjectCode)}
                          className="rounded border-slate-300 text-blue-700 focus:ring-blue-700"
                        />
                        <span className="truncate font-medium">{sub.subjectName}</span>
                      </span>
                      <span className="font-mono text-xs text-slate-500 shrink-0">
                        {sub.totalMarks} ({sub.letterGrade})
                      </span>
                    </label>
                  );
                })}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end pt-2">
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Sample Fee / Subject (INR)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={feePerSubject}
                    onChange={(e) => setFeePerSubject(Math.max(0, Number(e.target.value)))}
                    className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1">
                    Processing Fee (INR)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={processingFee}
                    onChange={(e) => setProcessingFee(Math.max(0, Number(e.target.value)))}
                    className="w-full h-10 px-3 bg-slate-50 border border-slate-300 rounded-lg font-mono text-sm"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleCalculateReeval}
                  className="h-10 px-4 bg-slate-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Calculate Fee Breakdown
                </button>
              </div>

              {reevalError && <p className="text-xs font-medium text-red-700">{reevalError}</p>}

              {reevalEstimate && (
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-2 text-sm tabular-nums">
                  <div className="text-xs font-semibold text-slate-700">
                    Transparent Estimate Breakdown ({reevalEstimate.subjectCount} subjects)
                  </div>
                  <div className="divide-y divide-slate-200">
                    {reevalEstimate.items.map((item) => (
                      <div key={item.subjectCode} className="py-1.5 flex justify-between text-xs">
                        <span>
                          {item.subjectCode} · {item.subjectName}
                        </span>
                        <span className="font-mono">INR {item.fee.toFixed(2)}</span>
                      </div>
                    ))}
                    <div className="py-1.5 flex justify-between text-xs text-slate-600">
                      <span>Application Processing Fee</span>
                      <span className="font-mono">INR {reevalEstimate.processingFee.toFixed(2)}</span>
                    </div>
                    <div className="pt-2 flex justify-between font-semibold text-slate-950">
                      <span>Estimated Total</span>
                      <span className="font-mono">INR {reevalEstimate.totalFee.toFixed(2)}</span>
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-500 pt-1">{reevalEstimate.disclaimer}</p>
                </div>
              )}
            </section>

            {/* Configurable Grading Scale Reference */}
            <section className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
              <div>
                <h3 className="font-display text-lg font-semibold text-slate-950 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-700" />
                  Grading Rules & Assumptions
                </h3>
                <p className="text-xs text-slate-500 mt-1">{gradingNote}</p>
              </div>

              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left border-collapse text-xs tabular-nums">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                      <th className="py-2 px-3">Grade</th>
                      <th className="py-2 px-3 text-right">Points</th>
                      <th className="py-2 px-3 text-right">Marks %</th>
                      <th className="py-2 px-3">Rule Source</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {gradingRules.map((rule) => (
                      <tr key={rule.letterGrade}>
                        <td className="py-2 px-3 font-mono font-bold text-slate-900">
                          {rule.letterGrade}
                        </td>
                        <td className="py-2 px-3 text-right font-mono">{rule.gradePoint}</td>
                        <td className="py-2 px-3 text-right font-mono">
                          {rule.letterGrade === 'AB'
                            ? 'Absent'
                            : `${rule.minMarks}–${rule.maxMarks}`}
                        </td>
                        <td className="py-2 px-3 text-slate-600">
                          {rule.isVerifiedRule ? 'Specified Rule' : 'Sample Configurable'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        </div>
      )}
    </div>
  );
}
