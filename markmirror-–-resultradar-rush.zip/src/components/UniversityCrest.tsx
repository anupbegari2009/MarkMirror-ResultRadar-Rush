export function UniversityCrest({ className = 'w-11 h-11' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <circle cx="32" cy="32" r="30" fill="#0F2547" stroke="#B48A3E" strokeWidth="2" />
      <circle cx="32" cy="32" r="25" stroke="#B48A3E" strokeOpacity="0.45" strokeWidth="1" />
      <path
        d="M19 20C19 18.8954 19.8954 18 21 18H43C44.1046 18 45 18.8954 45 20V33C45 41.2843 38.75 46.5 32 49C25.25 46.5 19 41.2843 19 33V20Z"
        fill="#173464"
        stroke="#F8FAFC"
        strokeWidth="1.5"
      />
      <path
        d="M24 27C26.5 25.5 29.5 25.5 32 27.5C34.5 25.5 37.5 25.5 40 27V37C37.5 35.5 34.5 35.5 32 37.5C29.5 35.5 26.5 35.5 24 37V27Z"
        fill="#FFFFFF"
        fillOpacity="0.94"
      />
      <line x1="32" y1="27.5" x2="32" y2="37.5" stroke="#0F2547" strokeWidth="1.5" />
      <path d="M27 22H37" stroke="#B48A3E" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}
