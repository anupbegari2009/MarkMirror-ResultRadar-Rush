import { ArrowLeft, Download, Printer } from 'lucide-react';
import type { StudentResultRecord } from '../types/markmirror';
import { downloadOfficialMarksheetPdf } from '../utils/pdfGenerator';
import { UniversityCrest } from './UniversityCrest';

interface OfficialMarksheetProps {
  record: StudentResultRecord;
  onReturnToDashboard: () => void;
}

export function OfficialMarksheet({ record, onReturnToDashboard }: OfficialMarksheetProps) {
  const generatedDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <section className="space-y-4">
      {/* Action Toolbar */}
      <div className="no-print flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 rounded-xl px-5 py-3.5">
        <div className="text-sm text-slate-600">
          Official A4 Statement of Grades ·{' '}
          <span className="font-mono font-semibold text-slate-900">{record.student.hallTicket}</span> ·{' '}
          <span>{record.semester.semesterTitle}</span>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onReturnToDashboard}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Return to Dashboard
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-900 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Marksheet
          </button>
          <button
            type="button"
            onClick={() => downloadOfficialMarksheetPdf(record)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            Download PDF
          </button>
        </div>
      </div>

      {/* Printable A4 Sheet */}
      <div className="print-only-sheet bg-white border border-slate-300 rounded-xl overflow-hidden max-w-4xl mx-auto">
        {/* Institutional Header */}
        <div className="bg-[#0F2547] text-white px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4 border-b-2 border-[#B48A3E]">
          <div className="flex items-center gap-4">
            <UniversityCrest className="w-14 h-14 shrink-0" />
            <div>
              <h2 className="font-display text-lg sm:text-xl font-bold tracking-tight text-white">
                MarkMirror Institute of Technology
              </h2>
              <p className="text-xs sm:text-sm text-slate-200 mt-0.5">
                Office of the Controller of Examinations · Provisional Statement of Grades
              </p>
            </div>
          </div>

          <div className="text-center sm:text-right text-xs text-slate-200 font-mono">
            <div>Record #{record.resultId}</div>
            <div className="mt-0.5">{record.semester.academicYear}</div>
          </div>
        </div>

        {/* Demonstration Banner */}
        {record.isDemoData && (
          <div className="bg-slate-100 border-b border-slate-200 px-8 py-2 text-xs text-slate-700 flex items-center justify-between">
            <span className="font-semibold">DEMONSTRATION DATA</span>
            <span>Generated synthetic university transcript for ResultRadar Rush verification</span>
          </div>
        )}

        <div className="p-6 sm:p-8 space-y-6">
          {/* Student Metadata Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-3 bg-slate-50 border border-slate-200 rounded-lg p-4 text-sm">
            <div>
              <div className="text-xs text-slate-500">Student Name</div>
              <div className="font-semibold text-slate-950 mt-0.5">{record.student.fullName}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Hall Ticket Number</div>
              <div className="font-mono font-semibold text-slate-950 mt-0.5">{record.student.hallTicket}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Branch / Department</div>
              <div className="font-medium text-slate-900 mt-0.5">
                {record.student.departmentName} ({record.student.departmentCode})
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Semester</div>
              <div className="font-medium text-slate-900 mt-0.5">{record.semester.semesterTitle}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Academic Year</div>
              <div className="font-mono text-slate-900 mt-0.5">{record.semester.academicYear}</div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Batch Cohort</div>
              <div className="font-mono text-slate-900 mt-0.5">{record.student.batchCode}</div>
            </div>
          </div>

          {/* Subject-wise Marks Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-200 text-xs font-semibold text-slate-700">
                  <th className="py-2.5 px-3">Code</th>
                  <th className="py-2.5 px-3">Subject Title</th>
                  <th className="py-2.5 px-3 text-right">Credits</th>
                  <th className="py-2.5 px-3 text-right">Internal</th>
                  <th className="py-2.5 px-3 text-right">External</th>
                  <th className="py-2.5 px-3 text-right">Total</th>
                  <th className="py-2.5 px-3 text-center">Grade</th>
                  <th className="py-2.5 px-3 text-right">Points</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 tabular-nums">
                {record.subjects.map((sub) => (
                  <tr key={sub.subjectCode} className="hover:bg-slate-50/70">
                    <td className="py-2.5 px-3 font-mono text-xs font-semibold text-slate-900">
                      {sub.subjectCode}
                    </td>
                    <td className="py-2.5 px-3 font-medium text-slate-900">{sub.subjectName}</td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-700">
                      {sub.credits.toFixed(1)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-700">
                      {sub.isAbsent ? 'AB' : `${sub.internalMarks}/${sub.maxInternal}`}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-700">
                      {sub.isAbsent ? 'AB' : `${sub.externalMarks}/${sub.maxExternal}`}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-950">
                      {sub.isAbsent ? 'AB' : `${sub.totalMarks}/${sub.maxMarks}`}
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono font-semibold text-slate-900">
                      {sub.letterGrade}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-800">{sub.gradePoint}</td>
                    <td
                      className={`py-2.5 px-3 text-center text-xs font-semibold ${
                        sub.passStatus === 'PASS' ? 'text-emerald-700' : 'text-red-700'
                      }`}
                    >
                      {sub.passStatus}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Summary Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-4 border border-slate-200 rounded-lg p-4 bg-slate-50 tabular-nums">
            <div>
              <div className="text-xs text-slate-500">Total Marks</div>
              <div className="font-mono text-base font-semibold text-slate-950 mt-0.5">
                {record.summary.totalMarksObtained} / {record.summary.totalMaxMarks}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Credits Earned</div>
              <div className="font-mono text-base font-semibold text-slate-950 mt-0.5">
                {record.summary.totalCreditsEarned} / {record.summary.totalCreditsAttempted}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Semester SGPA</div>
              <div className="font-mono text-xl font-bold text-blue-800 mt-0.5">
                {record.summary.sgpa.toFixed(2)}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Cumulative CGPA</div>
              <div className="font-mono text-xl font-bold text-slate-950 mt-0.5">
                {record.summary.cgpa.toFixed(2)}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-500">Result Status</div>
              <div
                className={`font-display text-base font-bold mt-0.5 ${
                  record.summary.resultStatus === 'PASS' ? 'text-emerald-700' : 'text-red-700'
                }`}
              >
                {record.summary.resultStatus}
              </div>
            </div>
          </div>

          {/* Footer & Signatures */}
          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-end justify-between gap-6 text-xs text-slate-500">
            <div className="space-y-1">
              <div>
                Grading Specification: O = 10 (90–100) · A+ = 9 (80–89) · A = 8 (70–79) · Configurable sample brackets B+ = 7, B = 6, C = 5, F = 0
              </div>
              <div>Date of Generation: {generatedDate}</div>
            </div>
            <div className="flex items-center gap-10 pt-4 sm:pt-0">
              <div className="text-center">
                <div className="w-32 border-t border-slate-400 pt-1 text-slate-700 font-medium">
                  Examination Cell
                </div>
              </div>
              <div className="text-center">
                <div className="w-36 border-t border-slate-400 pt-1 text-slate-700 font-medium">
                  Controller of Examinations
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
