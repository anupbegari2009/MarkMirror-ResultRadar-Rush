import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { StudentResultRecord } from '../types/markmirror';

export function downloadOfficialMarksheetPdf(record: StudentResultRecord): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();

  // Outer institutional frame
  doc.setDrawColor(15, 37, 71);
  doc.setLineWidth(0.6);
  doc.rect(10, 10, pageWidth - 20, 277);
  doc.setLineWidth(0.2);
  doc.rect(12, 12, pageWidth - 24, 273);

  // Header band
  doc.setFillColor(15, 37, 71);
  doc.rect(12, 12, pageWidth - 24, 28, 'F');

  // Vector Emblem Circle
  doc.setDrawColor(180, 138, 62);
  doc.setFillColor(255, 255, 255);
  doc.circle(26, 26, 8, 'FD');
  doc.setTextColor(15, 37, 71);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('MM', 26, 27.5, { align: 'center' });

  // University Title
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('MARKMIRROR INSTITUTE OF TECHNOLOGY', pageWidth / 2 + 6, 22, { align: 'center' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text('OFFICE OF THE CONTROLLER OF EXAMINATIONS · STATEMENT OF GRADES', pageWidth / 2 + 6, 28.5, {
    align: 'center',
  });
  doc.setFontSize(7.5);
  doc.setTextColor(203, 213, 225);
  doc.text(
    record.isDemoData
      ? 'DEMONSTRATION RECORD — FOR ACADEMIC EVALUATION ONLY'
      : 'OFFICIAL EXAMINATION TRANSCRIPT',
    pageWidth / 2 + 6,
    34.5,
    { align: 'center' }
  );

  // Student Metadata Grid
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9.5);
  const startY = 48;

  doc.setDrawColor(226, 232, 240);
  doc.setFillColor(248, 250, 252);
  doc.rect(16, startY, pageWidth - 32, 28, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.text('Student Name:', 20, startY + 7);
  doc.text('Hall Ticket No:', 20, startY + 14.5);
  doc.text('Department:', 20, startY + 22);

  doc.setFont('helvetica', 'normal');
  doc.text(record.student.fullName, 50, startY + 7);
  doc.setFont('courier', 'bold');
  doc.text(record.student.hallTicket, 50, startY + 14.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`${record.student.departmentName} (${record.student.departmentCode})`, 50, startY + 22);

  doc.setFont('helvetica', 'bold');
  doc.text('Semester:', 125, startY + 7);
  doc.text('Academic Year:', 125, startY + 14.5);
  doc.text('Batch Cohort:', 125, startY + 22);

  doc.setFont('helvetica', 'normal');
  doc.text(`${record.semester.semesterTitle}`, 155, startY + 7);
  doc.text(record.semester.academicYear, 155, startY + 14.5);
  doc.text(record.student.batchCode, 155, startY + 22);

  // Subject-wise Marks Table
  autoTable(doc, {
    startY: startY + 34,
    margin: { left: 16, right: 16 },
    head: [
      [
        'Code',
        'Subject Name',
        'Credits',
        'Internal (30)',
        'External (70)',
        'Total (100)',
        'Grade',
        'Points',
        'Status',
      ],
    ],
    body: record.subjects.map((s) => [
      s.subjectCode,
      s.subjectName,
      s.credits.toFixed(1),
      s.isAbsent ? 'AB' : String(s.internalMarks),
      s.isAbsent ? 'AB' : String(s.externalMarks),
      s.isAbsent ? 'AB' : String(s.totalMarks),
      s.letterGrade,
      String(s.gradePoint),
      s.passStatus,
    ]),
    styles: {
      fontSize: 8.5,
      cellPadding: 3,
      textColor: [15, 23, 42],
      lineColor: [203, 213, 225],
      lineWidth: 0.2,
    },
    headStyles: {
      fillColor: [15, 37, 71],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', font: 'courier', fontStyle: 'bold', cellWidth: 18 },
      1: { halign: 'left', cellWidth: 50 },
      2: { halign: 'right', cellWidth: 14 },
      3: { halign: 'right', cellWidth: 18 },
      4: { halign: 'right', cellWidth: 18 },
      5: { halign: 'right', cellWidth: 18 },
      6: { halign: 'center', fontStyle: 'bold', cellWidth: 14 },
      7: { halign: 'right', cellWidth: 14 },
      8: { halign: 'center', fontStyle: 'bold', cellWidth: 14 },
    },
  });

  const finalY = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY || 170;

  // Summary Metrics Box
  const boxY = finalY + 8;
  doc.setDrawColor(203, 213, 225);
  doc.setFillColor(248, 250, 252);
  doc.rect(16, boxY, pageWidth - 32, 26, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text(`Total Marks: ${record.summary.totalMarksObtained} / ${record.summary.totalMaxMarks}`, 22, boxY + 9);
  doc.text(
    `Credits Earned: ${record.summary.totalCreditsEarned} / ${record.summary.totalCreditsAttempted}`,
    22,
    boxY + 18
  );

  doc.text(`SGPA: ${record.summary.sgpa.toFixed(2)}`, 110, boxY + 9);
  doc.text(`Cumulative CGPA: ${record.summary.cgpa.toFixed(2)}`, 110, boxY + 18);

  doc.setTextColor(
    record.summary.resultStatus === 'PASS' ? 21 : 185,
    record.summary.resultStatus === 'PASS' ? 128 : 28,
    record.summary.resultStatus === 'PASS' ? 61 : 28
  );
  doc.setFontSize(11);
  doc.text(`RESULT: ${record.summary.resultStatus}`, pageWidth - 22, boxY + 14, { align: 'right' });

  // Grading Rules & Generation Note
  doc.setTextColor(71, 85, 105);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text(
    'Grading Reference: O = 10 (90–100) | A+ = 9 (80–89) | A = 8 (70–79) | Sample Configurable Brackets: B+ = 7, B = 6, C = 5, F = 0.',
    16,
    boxY + 36
  );
  doc.text(
    `Date of Generation: ${new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
    })} | Result Record ID: #${record.resultId}`,
    16,
    boxY + 42
  );

  // Signatures
  const sigY = 258;
  doc.setDrawColor(148, 163, 184);
  doc.line(22, sigY, 72, sigY);
  doc.line(pageWidth - 72, sigY, pageWidth - 22, sigY);
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  doc.text('Verified By (Examination Cell)', 47, sigY + 5, { align: 'center' });
  doc.text('Controller of Examinations', pageWidth - 47, sigY + 5, { align: 'center' });

  doc.save(`${record.student.hallTicket}_Sem${record.semester.semesterNumber}_Marksheet.pdf`);
}
