import { useCallback, useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { AdminConsolePage } from './pages/AdminConsolePage';
import { BatchAnalyticsPage } from './pages/BatchAnalyticsPage';
import { LandingPage } from './pages/LandingPage';
import { ResultLookupPage } from './pages/ResultLookupPage';
import { StudentDashboardPage } from './pages/StudentDashboardPage';
import type { ActiveRoute } from './types/markmirror';

function parseRouteFromHash(): ActiveRoute {
  const hash = window.location.hash.replace('#', '').toLowerCase();
  if (hash === 'results' || hash === 'dashboard' || hash === 'analytics' || hash === 'admin') {
    return hash;
  }
  return 'landing';
}

export default function App() {
  const [activeRoute, setActiveRoute] = useState<ActiveRoute>(() => parseRouteFromHash());
  const [selectedHallTicket, setSelectedHallTicket] = useState<string>('22CSE104');
  const [selectedSemester, setSelectedSemester] = useState<number | undefined>(5);

  const navigate = useCallback((route: ActiveRoute) => {
    setActiveRoute(route);
    window.location.hash = route === 'landing' ? '' : route;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const onHashChange = () => {
      setActiveRoute(parseRouteFromHash());
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const handleLookupHallTicket = useCallback(
    (hallTicket: string, semester?: number) => {
      setSelectedHallTicket(hallTicket);
      setSelectedSemester(semester ?? 5);
      navigate('results');
    },
    [navigate]
  );

  const handleQuickLookupSample = useCallback(() => {
    setSelectedHallTicket('22CSE104');
    setSelectedSemester(5);
    navigate('results');
  }, [navigate]);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Navbar
        activeRoute={activeRoute}
        onNavigate={navigate}
        onQuickLookupSample={handleQuickLookupSample}
      />

      <main className="flex-1">
        {activeRoute === 'landing' && (
          <LandingPage
            onLookupHallTicket={handleLookupHallTicket}
            onNavigate={navigate}
          />
        )}

        {activeRoute === 'results' && (
          <ResultLookupPage
            initialHallTicket={selectedHallTicket}
            initialSemester={selectedSemester}
            onSelectStudent={(ht) => setSelectedHallTicket(ht)}
            onNavigate={navigate}
          />
        )}

        {activeRoute === 'dashboard' && (
          <StudentDashboardPage
            initialHallTicket={selectedHallTicket}
            onOpenSemesterMarksheet={handleLookupHallTicket}
          />
        )}

        {activeRoute === 'analytics' && (
          <BatchAnalyticsPage
            onInspectStudent={(ht, sem) => handleLookupHallTicket(ht, sem)}
          />
        )}

        {activeRoute === 'admin' && <AdminConsolePage />}
      </main>
    </div>
  );
}
