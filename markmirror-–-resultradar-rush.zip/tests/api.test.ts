import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import test, { after, before } from 'node:test';
import { createApiApp } from '../backend/app.ts';
import { closeDb } from '../backend/database/db.ts';

process.env.SQLITE_DB_PATH = ':memory:';

let baseUrl = '';
let server: ReturnType<ReturnType<typeof createApiApp>['listen']>;

before(async () => {
  const app = createApiApp();
  await new Promise<void>((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      const addr = server.address() as AddressInfo;
      baseUrl = `http://127.0.0.1:${addr.port}`;
      resolve();
    });
  });
});

after(async () => {
  await new Promise<void>((resolve) => server.close(() => resolve()));
  closeDb();
});

test('GET /api/students/22CSE104/results?semester=5 returns SGPA 8.85 with 6 subjects', async () => {
  const res = await fetch(`${baseUrl}/api/students/22CSE104/results?semester=5`);
  assert.equal(res.status, 200);
  const body = (await res.json()) as {
    hallTicket: string;
    results: Array<{
      summary: { sgpa: number; resultStatus: string };
      subjects: Array<{ subjectName: string }>;
    }>;
  };
  assert.equal(body.hallTicket, '22CSE104');
  assert.equal(body.results[0].summary.sgpa, 8.85);
  assert.equal(body.results[0].summary.resultStatus, 'PASS');
  assert.equal(body.results[0].subjects.length, 6);
});

test('Invalid hall ticket returns 400 and unknown hall ticket returns 404', async () => {
  const badRes = await fetch(`${baseUrl}/api/students/INVALID!!/results`);
  assert.equal(badRes.status, 400);

  const notFoundRes = await fetch(`${baseUrl}/api/students/99CSE999/results`);
  assert.equal(notFoundRes.status, 404);
});

test('GET /api/analytics/pass-rates reports Operating Systems at exactly 68% pass rate', async () => {
  const res = await fetch(`${baseUrl}/api/analytics/pass-rates`);
  assert.equal(res.status, 200);
  const body = (await res.json()) as {
    subjects: Array<{ subjectCode: string; subjectName: string; passRate: number; evaluatedCount: number }>;
  };
  const os = body.subjects.find((s) => s.subjectCode === 'CS503');
  assert.ok(os, 'Operating Systems (CS503) should exist in analytics');
  assert.equal(os.subjectName, 'Operating Systems');
  assert.equal(os.evaluatedCount, 50);
  assert.equal(os.passRate, 68);
});

test('GET /api/analytics/overview confirms >= 100 seeded students and valid metrics', async () => {
  const res = await fetch(`${baseUrl}/api/analytics/overview`);
  assert.equal(res.status, 200);
  const body = (await res.json()) as { totalStudents: number; totalDepartments: number; averageSgpa: number };
  assert.ok(body.totalStudents >= 100);
  assert.equal(body.totalDepartments, 3);
  assert.ok(body.averageSgpa > 0);
});

test('GET /api/analytics/toppers returns top 5 department performers ranked descending', async () => {
  const res = await fetch(`${baseUrl}/api/analytics/toppers?department=CSE&limit=5`);
  assert.equal(res.status, 200);
  const body = (await res.json()) as {
    toppers: Array<{ rank: number; cgpa: number; departmentCode: string }>;
  };
  assert.equal(body.toppers.length, 5);
  assert.equal(body.toppers[0].rank, 1);
  assert.ok(body.toppers[0].cgpa >= body.toppers[1].cgpa);
});

test('GET /api/analytics/cgpa-distribution sums to 100% across 5 buckets', async () => {
  const res = await fetch(`${baseUrl}/api/analytics/cgpa-distribution`);
  assert.equal(res.status, 200);
  const body = (await res.json()) as {
    totalStudents: number;
    distribution: Array<{ range: string; count: number; percentage: number }>;
  };
  assert.equal(body.distribution.length, 5);
  const countSum = body.distribution.reduce((acc, b) => acc + b.count, 0);
  assert.equal(countSum, body.totalStudents);
});

test('Protected admin endpoints reject unauthenticated requests and allow authorized SUPER_ADMIN', async () => {
  const unauth = await fetch(`${baseUrl}/api/admin/students`);
  assert.equal(unauth.status, 401);

  const loginRes = await fetch(`${baseUrl}/api/admin/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: 'admin',
      password: process.env.SEED_ADMIN_PASSWORD || 'MarkMirror@2026',
    }),
  });
  assert.equal(loginRes.status, 200);
  const { token } = (await loginRes.json()) as { token: string };
  assert.ok(token);

  const authStudents = await fetch(`${baseUrl}/api/admin/students?limit=10`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  assert.equal(authStudents.status, 200);
});
