import assert from 'node:assert/strict';
import test from 'node:test';
import {
  calculateCGPA,
  calculateSGPA,
  DEFAULT_GRADING_SCALE,
  estimateReevaluationFee,
  resolveGradeFromMarks,
  type SubjectEvaluationConfig,
} from '../backend/services/calculationService.ts';

const makeSubject = (
  code: string,
  name: string,
  credits: number,
  isCreditBearing = true
): SubjectEvaluationConfig => ({
  subjectCode: code,
  subjectName: name,
  credits,
  maxInternal: 30,
  maxExternal: 70,
  passInternalMin: 12,
  passExternalMin: 28,
  passTotalMin: 40,
  isCreditBearing,
});

test('22CSE104 Semester 5 exact SGPA calculation yields 8.85', () => {
  const result = calculateSGPA([
    { internalMarks: 27, externalMarks: 65, subject: makeSubject('CS501', 'Mathematics', 4) },
    { internalMarks: 25, externalMarks: 59, subject: makeSubject('CS502', 'DBMS', 4) },
    { internalMarks: 22, externalMarks: 52, subject: makeSubject('CS503', 'Operating Systems', 4) },
    { internalMarks: 26, externalMarks: 57, subject: makeSubject('CS504', 'Computer Networks', 3) },
    { internalMarks: 23, externalMarks: 52, subject: makeSubject('CS505', 'Software Engineering', 3) },
    { internalMarks: 27, externalMarks: 60, subject: makeSubject('CS506', 'AI Lab', 2) },
  ]);

  assert.equal(result.totalCreditsAttempted, 20);
  assert.equal(result.totalCreditsEarned, 20);
  assert.equal(result.sgpa, 8.85);
  assert.equal(result.resultStatus, 'PASS');
  assert.equal(result.subjects[0].letterGrade, 'O');
  assert.equal(result.subjects[1].letterGrade, 'A+');
  assert.equal(result.subjects[2].letterGrade, 'A');
});

test('Non-credit-bearing subjects are excluded from SGPA denominator', () => {
  const result = calculateSGPA([
    { internalMarks: 28, externalMarks: 65, subject: makeSubject('CS501', 'Mathematics', 4, true) }, // 10 * 4
    { internalMarks: 15, externalMarks: 30, subject: makeSubject('NC101', 'Audit Seminar', 2, false) }, // excluded
  ]);

  assert.equal(result.totalCreditsAttempted, 4);
  assert.equal(result.sgpa, 10);
});

test('Absent students receive AB grade, 0 grade points, and ABSENT/FAIL status', () => {
  const singleAbsent = resolveGradeFromMarks({
    internalMarks: 0,
    externalMarks: 0,
    isAbsent: true,
    subject: makeSubject('CS503', 'Operating Systems', 4),
  });
  assert.equal(singleAbsent.letterGrade, 'AB');
  assert.equal(singleAbsent.gradePoint, 0);
  assert.equal(singleAbsent.passStatus, 'ABSENT');

  const allAbsent = calculateSGPA([
    { internalMarks: 0, externalMarks: 0, isAbsent: true, subject: makeSubject('CS501', 'Mathematics', 4) },
  ]);
  assert.equal(allAbsent.sgpa, 0);
  assert.equal(allAbsent.resultStatus, 'ABSENT');
});

test('External minimum threshold failure triggers FAIL even if total >= 40', () => {
  const grade = resolveGradeFromMarks({
    internalMarks: 30,
    externalMarks: 20, // Below passExternalMin (28), even though total=50
    subject: makeSubject('CS503', 'Operating Systems', 4),
  });
  assert.equal(grade.letterGrade, 'F');
  assert.equal(grade.gradePoint, 0);
  assert.equal(grade.passStatus, 'FAIL');
});

test('Division-by-zero protection for SGPA and CGPA', () => {
  const emptySgpa = calculateSGPA([], DEFAULT_GRADING_SCALE);
  assert.equal(emptySgpa.sgpa, 0);
  assert.equal(emptySgpa.totalCreditsAttempted, 0);

  assert.equal(calculateCGPA([]), 0);
  assert.equal(calculateCGPA([{ semesterNumber: 1, creditsAttempted: 0, sgpa: 9.0 }]), 0);
});

test('Credit-weighted CGPA calculation across semesters', () => {
  const cgpa = calculateCGPA([
    { semesterNumber: 1, creditsAttempted: 20, sgpa: 8.2 },
    { semesterNumber: 2, creditsAttempted: 20, sgpa: 8.6 },
    { semesterNumber: 3, creditsAttempted: 20, sgpa: 8.85 },
  ]);
  assert.equal(cgpa, 8.55);
});

test('Validation rejects out-of-range marks', () => {
  assert.throws(
    () =>
      calculateSGPA([
        { internalMarks: 35, externalMarks: 60, subject: makeSubject('CS501', 'Mathematics', 4) },
      ]),
    /Internal marks/
  );
});

test('Re-evaluation fee estimator computes transparent breakdown', () => {
  const est = estimateReevaluationFee(
    [
      { subjectCode: 'CS503', subjectName: 'Operating Systems' },
      { subjectCode: 'CS505', subjectName: 'Software Engineering' },
    ],
    600,
    150
  );
  assert.equal(est.subjectCount, 2);
  assert.equal(est.subtotal, 1200);
  assert.equal(est.totalFee, 1350);
  assert.equal(est.isSampleFeeSchedule, true);
});
