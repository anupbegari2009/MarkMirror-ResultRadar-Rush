# MarkMirror – ResultRadar Rush

Centralized examination result lookup, official A4 marksheet PDF generator, credit-weighted SGPA/CGPA calculation engine, and batch academic analytics platform built with Express, SQLite, React, TypeScript, Tailwind CSS, and Chart.js.

## 1. Problem Statement & Solution Overview

University examination cells often rely on fragmented PDF circulars or unindexed static result sheets that make it difficult for students to track multi-semester SGPA/CGPA progression and impossible for faculty to diagnose subject-level failure bottlenecks across cohorts.

**MarkMirror – ResultRadar Rush** solves this by unifying:
- **Instant Hall Ticket Result Lookup** with optional Date-of-Birth identity verification for sensitive fields.
- **Official A4 Marksheet Viewer, Print Layout & PDF Export** powered by `jspdf` + `jspdf-autotable` and dedicated `@media print` A4 formatting.
- **Credit-Weighted SGPA & CGPA Engine** with configurable grading scale rules, non-credit-bearing subject exclusion, absent handling, and division-by-zero safety.
- **Batch & Department Analytics Dashboard** backed by live SQL aggregations and Chart.js visualizations (subject pass rates, department topper leaderboard, CGPA distribution histogram, multi-batch comparisons, and subject difficulty index).
- **Protected Administration Console** with JWT authentication and role-based access control (`SUPER_ADMIN`, `EXAM_CELL`, `FACULTY`) that automatically recalculates SGPA/CGPA history on marks entry or update.

## 2. Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Chart.js 4, jsPDF + jspdf-autotable, Lucide Icons
- **Backend**: Node.js, Express.js REST APIs, JWT (`jsonwebtoken`), Password Hashing (`bcryptjs`)
- **Database**: SQLite (`better-sqlite3` with `WAL` mode and enforced `foreign_keys = ON`)
- **Testing**: Node built-in test runner (`node:test` / `tsx --test`)

## 3. Normalized SQLite Database Schema

Defined in `backend/database/schema.sql` across 10 normalized tables:
1. `departments` — Engineering branches (`CSE`, `ECE`, `MECH`)
2. `batches` — Graduating cohorts (`2022-26`, `2023-27`, `2024-28`)
3. `semesters` — Academic terms (`1` through `5`)
4. `grading_scales` — Configurable letter grade rules (`O = 10`, `A+ = 9`, `A = 8`, plus configurable sample brackets)
5. `subjects` — Curriculum subjects with credit weights and pass thresholds
6. `students` — 120 seeded synthetic demonstration students
7. `student_results` — Semester result summaries (`sgpa`, `cgpa`, credits, status)
8. `subject_grades` — Subject-level internal, external, total marks, grades, and pass/fail status
9. `historical_results` — Semester progression ledger for trend charts
10. `administrators` — Role-scoped staff accounts (`SUPER_ADMIN`, `FACULTY`)

> **Demonstration Data Notice**: All seeded student records and sample grading brackets beyond `O=10`, `A+=9`, `A=8` are clearly flagged as **DEMONSTRATION DATA** and do not represent real university records.

## 4. API Documentation

### Student & Result Endpoints
- `GET /api/students/:hallTicket` — Student profile and available semesters (masks email unless `?dob=YYYY-MM-DD` matches)
- `POST /api/students/:hallTicket/verify` — Verifies student DOB against records
- `GET /api/students/:hallTicket/results?semester=5` — Full semester marksheet(s) and subject breakdown
- `GET /api/results/:resultId` — Retrieve single marksheet by ID
- `GET /api/students/:hallTicket/analytics` — Student KPIs and historical SGPA/CGPA progression
- `POST /api/students/:hallTicket/reevaluation-estimate` — Transparent configurable sample re-evaluation fee breakdown

### Analytics Endpoints
- `GET /api/analytics/overview` — Total students, exam records, average SGPA/CGPA, overall pass rate
- `GET /api/analytics/pass-rates` — Subject-wise pass/fail counts and percentages
- `GET /api/analytics/toppers` — Top 10 ranked performers by branch/batch/semester
- `GET /api/analytics/cgpa-distribution` — Histogram buckets (`9–10`, `8–9`, `7–8`, `6–7`, `Below 6`)
- `GET /api/analytics/subject-difficulty` — Composite difficulty index ranked by failure rates
- `GET /api/analytics/batch-comparison` — Cross-cohort SGPA, CGPA, pass rate, and subject comparisons
- `GET /api/analytics/filters` & `GET /api/analytics/grading-scale` — Metadata and active grading scale

### Protected Administrator Endpoints (JWT Bearer Token Required)
- `POST /api/admin/auth/login` — Authenticate and receive JWT
- `GET /api/admin/auth/me` — Verify active session
- `GET /api/admin/students` & `POST /api/admin/students`
- `GET /api/admin/subjects` & `POST /api/admin/subjects`
- `GET /api/admin/results`, `POST /api/admin/results`, `PUT /api/admin/results/:resultId`, `DELETE /api/admin/results/:resultId`

## 5. Installation & Startup

```bash
# 1. Install dependencies
npm install

# 2. Configure environment variables (optional for local dev; defaults provided)
cp .env.example .env

# 3. Start full-stack development server on port 3000
npm run dev
```

For production build & start:
```bash
npm run build
NODE_ENV=production npm start
```

Open `http://localhost:3000` in your browser.

## 6. Testing

Run the calculation engine unit tests and REST API integration tests:
```bash
npm test
```

Type-check and verify build:
```bash
npm run lint
npm run build
```

## 7. Hackathon Demonstration Flow

1. Open the MarkMirror homepage (`http://localhost:3000`).
2. Enter hall ticket **`22CSE104`** (optional DOB verification: `2004-05-14`) and click **Search Results**.
3. Inspect Semester 5 marks across all 6 subjects (`Mathematics`, `DBMS`, `Operating Systems`, `Computer Networks`, `Software Engineering`, `AI Lab`) confirming **SGPA = 8.85** and `PASS` status.
4. Switch to **Official A4 Marksheet** and click **Download PDF** or **Print Marksheet**.
5. Navigate to **Student Portal** to inspect the multi-semester SGPA/CGPA trend chart.
6. Navigate to **Batch Analytics** to inspect:
   - **Operating Systems** highlighted at **68.0% pass rate** (`34/50` passed).
   - **Top 5 / Top 10 Department Performers** leaderboard with medal ranks.
   - **CGPA Distribution Histogram**, **Batch Comparison**, and **Subject Difficulty Index**.
7. Navigate to **Admin Console** and sign in (`admin` / `MarkMirror@2026` in local demo) to manage students, subjects, and auto-recalculating exam results.

## 8. Limitations & Future Improvements

- Sample grading brackets below `A` (`B+`, `B`, `C`, `F`) and re-evaluation fees are configurable placeholders and should be aligned with official university ordinances prior to production deployment.
- Future enhancements include bulk CSV/Excel marks upload, automated student email notifications on result publication, and multi-campus SSO integration.
