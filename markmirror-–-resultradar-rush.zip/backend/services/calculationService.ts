export interface GradingScaleRule {
  letterGrade: string;
  gradePoint: number;
  minMarks: number;
  maxMarks: number;
  isPassing: boolean;
  isVerifiedRule: boolean;
  description?: string;
}

export interface SubjectEvaluationConfig {
  subjectCode: string;
  subjectName: string;
  credits: number;
  maxInternal: number;
  maxExternal: number;
  passInternalMin: number;
  passExternalMin: number;
  passTotalMin: number;
  isCreditBearing: boolean;
}

export interface SubjectMarkInput {
  internalMarks: number;
  externalMarks: number;
  isAbsent?: boolean;
  subject: SubjectEvaluationConfig;
}

export interface ComputedSubjectGrade {
  subjectCode: string;
  subjectName: string;
  credits: number;
  isCreditBearing: boolean;
  internalMarks: number;
  externalMarks: number;
  totalMarks: number;
  maxMarks: number;
  letterGrade: string;
  gradePoint: number;
  isAbsent: boolean;
  passStatus: 'PASS' | 'FAIL' | 'ABSENT';
}

export interface SemesterCalculationResult {
  subjects: ComputedSubjectGrade[];
  sgpa: number;
  totalCreditsAttempted: number;
  totalCreditsEarned: number;
  totalMarksObtained: number;
  totalMaxMarks: number;
  resultStatus: 'PASS' | 'FAIL' | 'ABSENT';
}

export interface SemesterSummaryForCGPA {
  semesterNumber: number;
  creditsAttempted: number;
  sgpa: number;
}

export interface ReevaluationEstimateItem {
  subjectCode: string;
  subjectName: string;
  fee: number;
}

export interface ReevaluationEstimateResult {
  items: ReevaluationEstimateItem[];
  subjectCount: number;
  feePerSubject: number;
  processingFee: number;
  subtotal: number;
  totalFee: number;
  isSampleFeeSchedule: boolean;
  disclaimer: string;
}

/**
 * Default configurable grading rules.
 * Note: O=10, A+=9, A=8 follow the project brief specification; remaining brackets
 * are clearly marked as sample configurable grading assumptions (isVerifiedRule=false).
 */
export const DEFAULT_GRADING_SCALE: GradingScaleRule[] = [
  { letterGrade: 'O', gradePoint: 10, minMarks: 90, maxMarks: 100, isPassing: true, isVerifiedRule: true, description: 'Outstanding (Specified in brief)' },
  { letterGrade: 'A+', gradePoint: 9, minMarks: 80, maxMarks: 89, isPassing: true, isVerifiedRule: true, description: 'Excellent (Specified in brief)' },
  { letterGrade: 'A', gradePoint: 8, minMarks: 70, maxMarks: 79, isPassing: true, isVerifiedRule: true, description: 'Very Good (Specified in brief)' },
  { letterGrade: 'B+', gradePoint: 7, minMarks: 60, maxMarks: 69, isPassing: true, isVerifiedRule: false, description: 'Good (Configurable sample bracket)' },
  { letterGrade: 'B', gradePoint: 6, minMarks: 50, maxMarks: 59, isPassing: true, isVerifiedRule: false, description: 'Above Average (Configurable sample bracket)' },
  { letterGrade: 'C', gradePoint: 5, minMarks: 40, maxMarks: 49, isPassing: true, isVerifiedRule: false, description: 'Pass (Configurable sample bracket)' },
  { letterGrade: 'F', gradePoint: 0, minMarks: 0, maxMarks: 39, isPassing: false, isVerifiedRule: false, description: 'Fail (Configurable sample bracket)' },
  { letterGrade: 'AB', gradePoint: 0, minMarks: 0, maxMarks: 0, isPassing: false, isVerifiedRule: false, description: 'Absent (Configurable sample rule)' },
];

export function roundToTwo(value: number): number {
  if (!Number.isFinite(value)) {
    return 0;
  }
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function validateSubjectMarks(input: SubjectMarkInput): void {
  const { internalMarks, externalMarks, isAbsent, subject } = input;
  if (!subject || typeof subject.credits !== 'number' || subject.credits < 0) {
    throw new Error(`Invalid subject credit configuration for ${subject?.subjectCode || 'unknown'}`);
  }
  if (isAbsent) {
    return;
  }
  if (!Number.isInteger(internalMarks) || internalMarks < 0 || internalMarks > subject.maxInternal) {
    throw new Error(
      `Internal marks for ${subject.subjectCode} must be an integer between 0 and ${subject.maxInternal}`
    );
  }
  if (!Number.isInteger(externalMarks) || externalMarks < 0 || externalMarks > subject.maxExternal) {
    throw new Error(
      `External marks for ${subject.subjectCode} must be an integer between 0 and ${subject.maxExternal}`
    );
  }
}

export function resolveGradeFromMarks(
  input: SubjectMarkInput,
  gradingScale: GradingScaleRule[] = DEFAULT_GRADING_SCALE
): ComputedSubjectGrade {
  validateSubjectMarks(input);
  const { subject } = input;
  const isAbsent = Boolean(input.isAbsent);
  const maxMarks = subject.maxInternal + subject.maxExternal;

  if (isAbsent) {
    const abRule = gradingScale.find((r) => r.letterGrade === 'AB');
    return {
      subjectCode: subject.subjectCode,
      subjectName: subject.subjectName,
      credits: subject.credits,
      isCreditBearing: subject.isCreditBearing,
      internalMarks: 0,
      externalMarks: 0,
      totalMarks: 0,
      maxMarks,
      letterGrade: abRule ? abRule.letterGrade : 'AB',
      gradePoint: abRule ? abRule.gradePoint : 0,
      isAbsent: true,
      passStatus: 'ABSENT',
    };
  }

  const totalMarks = input.internalMarks + input.externalMarks;
  const normalizedPercent = maxMarks > 0 ? Math.round((totalMarks / maxMarks) * 100) : 0;

  const meetsMinimums =
    input.internalMarks >= subject.passInternalMin &&
    input.externalMarks >= subject.passExternalMin &&
    totalMarks >= subject.passTotalMin;

  if (!meetsMinimums) {
    const failRule = gradingScale.find((r) => !r.isPassing && r.letterGrade !== 'AB');
    return {
      subjectCode: subject.subjectCode,
      subjectName: subject.subjectName,
      credits: subject.credits,
      isCreditBearing: subject.isCreditBearing,
      internalMarks: input.internalMarks,
      externalMarks: input.externalMarks,
      totalMarks,
      maxMarks,
      letterGrade: failRule ? failRule.letterGrade : 'F',
      gradePoint: failRule ? failRule.gradePoint : 0,
      isAbsent: false,
      passStatus: 'FAIL',
    };
  }

  const passingRules = gradingScale
    .filter((r) => r.isPassing)
    .sort((a, b) => b.minMarks - a.minMarks);

  const matchedRule =
    passingRules.find((r) => normalizedPercent >= r.minMarks && normalizedPercent <= r.maxMarks) ||
    passingRules[passingRules.length - 1];

  return {
    subjectCode: subject.subjectCode,
    subjectName: subject.subjectName,
    credits: subject.credits,
    isCreditBearing: subject.isCreditBearing,
    internalMarks: input.internalMarks,
    externalMarks: input.externalMarks,
    totalMarks,
    maxMarks,
    letterGrade: matchedRule ? matchedRule.letterGrade : 'C',
    gradePoint: matchedRule ? matchedRule.gradePoint : 5,
    isAbsent: false,
    passStatus: 'PASS',
  };
}

/**
 * SGPA = Sum(Credits * Grade Points) / Sum(Credits)
 * Excludes non-credit-bearing subjects and prevents division-by-zero.
 */
export function calculateSGPA(
  inputs: SubjectMarkInput[],
  gradingScale: GradingScaleRule[] = DEFAULT_GRADING_SCALE
): SemesterCalculationResult {
  const computedSubjects = inputs.map((item) => resolveGradeFromMarks(item, gradingScale));

  let weightedPointsSum = 0;
  let totalCreditsAttempted = 0;
  let totalCreditsEarned = 0;
  let totalMarksObtained = 0;
  let totalMaxMarks = 0;
  let anyFail = false;
  let allAbsent = computedSubjects.length > 0;

  for (const subj of computedSubjects) {
    totalMarksObtained += subj.totalMarks;
    totalMaxMarks += subj.maxMarks;

    if (!subj.isAbsent) {
      allAbsent = false;
    }

    if (subj.passStatus !== 'PASS') {
      anyFail = true;
    }

    if (subj.isCreditBearing && subj.credits > 0) {
      totalCreditsAttempted += subj.credits;
      weightedPointsSum += subj.credits * subj.gradePoint;
      if (subj.passStatus === 'PASS') {
        totalCreditsEarned += subj.credits;
      }
    }
  }

  const sgpa = totalCreditsAttempted > 0 ? roundToTwo(weightedPointsSum / totalCreditsAttempted) : 0;

  const resultStatus: 'PASS' | 'FAIL' | 'ABSENT' = allAbsent
    ? 'ABSENT'
    : anyFail
      ? 'FAIL'
      : 'PASS';

  return {
    subjects: computedSubjects,
    sgpa,
    totalCreditsAttempted: roundToTwo(totalCreditsAttempted),
    totalCreditsEarned: roundToTwo(totalCreditsEarned),
    totalMarksObtained,
    totalMaxMarks,
    resultStatus,
  };
}

/**
 * CGPA = Sum(Semester Credits * Semester SGPA) / Sum(Semester Credits)
 * Prevents division-by-zero when total credits across semesters is 0.
 */
export function calculateCGPA(semesters: SemesterSummaryForCGPA[]): number {
  if (!Array.isArray(semesters) || semesters.length === 0) {
    return 0;
  }

  let totalWeightedSgpa = 0;
  let totalCredits = 0;

  for (const sem of semesters) {
    if (sem.creditsAttempted > 0 && Number.isFinite(sem.sgpa) && sem.sgpa >= 0) {
      totalWeightedSgpa += sem.creditsAttempted * sem.sgpa;
      totalCredits += sem.creditsAttempted;
    }
  }

  if (totalCredits <= 0) {
    return 0;
  }

  return roundToTwo(totalWeightedSgpa / totalCredits);
}

export function estimateReevaluationFee(
  subjects: Array<{ subjectCode: string; subjectName: string }>,
  feePerSubject = 500,
  processingFee = 100
): ReevaluationEstimateResult {
  if (!Array.isArray(subjects) || subjects.length === 0) {
    throw new Error('Select at least one subject for re-evaluation estimation.');
  }
  if (!Number.isFinite(feePerSubject) || feePerSubject < 0) {
    throw new Error('Fee per subject must be a non-negative number.');
  }
  if (!Number.isFinite(processingFee) || processingFee < 0) {
    throw new Error('Processing fee must be a non-negative number.');
  }

  const items: ReevaluationEstimateItem[] = subjects.map((s) => ({
    subjectCode: s.subjectCode,
    subjectName: s.subjectName,
    fee: roundToTwo(feePerSubject),
  }));

  const subtotal = roundToTwo(items.length * feePerSubject);
  const totalFee = roundToTwo(subtotal + processingFee);

  return {
    items,
    subjectCount: items.length,
    feePerSubject: roundToTwo(feePerSubject),
    processingFee: roundToTwo(processingFee),
    subtotal,
    totalFee,
    isSampleFeeSchedule: true,
    disclaimer:
      'Configurable sample fee schedule for estimation only. Verify official university examination circulars before payment.',
  };
}
