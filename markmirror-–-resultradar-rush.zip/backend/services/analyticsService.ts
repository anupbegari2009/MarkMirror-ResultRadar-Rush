import type Database from 'better-sqlite3';
import { roundToTwo } from './calculationService.ts';

export interface AnalyticsFilter {
  departmentCode?: string;
  batchCode?: string;
  semesterNumber?: number;
}

function buildFilterWhere(
  filter: AnalyticsFilter,
  aliases: { dept: string; batch: string; sem: string }
): { sql: string; params: unknown[] } {
  const clauses: string[] = [];
  const params: unknown[] = [];

  if (filter.departmentCode && filter.departmentCode !== 'ALL') {
    clauses.push(`${aliases.dept}.code = ?`);
    params.push(filter.departmentCode.toUpperCase());
  }
  if (filter.batchCode && filter.batchCode !== 'ALL') {
    clauses.push(`${aliases.batch}.batch_code = ?`);
    params.push(filter.batchCode);
  }
  if (filter.semesterNumber && Number.isInteger(filter.semesterNumber)) {
    clauses.push(`${aliases.sem}.semester_number = ?`);
    params.push(filter.semesterNumber);
  }

  return {
    sql: clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '',
    params,
  };
}

export function getAnalyticsOverview(db: Database.Database, filter: AnalyticsFilter = {}) {
  const { sql: whereSql, params } = buildFilterWhere(filter, {
    dept: 'd',
    batch: 'b',
    sem: 'sem',
  });

  const totalsRow = db
    .prepare(
      `SELECT
         COUNT(DISTINCT s.id) as totalStudents,
         COUNT(DISTINCT d.id) as totalDepartments,
         COUNT(sr.id) as totalExamRecords,
         ROUND(AVG(sr.sgpa), 2) as averageSgpa,
         ROUND(AVG(sr.cgpa), 2) as averageCgpa,
         SUM(CASE WHEN sr.result_status = 'PASS' THEN 1 ELSE 0 END) as passedResults
       FROM student_results sr
       JOIN students s ON s.id = sr.student_id
       JOIN departments d ON d.id = s.department_id
       JOIN batches b ON b.id = s.batch_id
       JOIN semesters sem ON sem.id = sr.semester_id
       ${whereSql}`
    )
    .get(...params) as {
    totalStudents: number;
    totalDepartments: number;
    totalExamRecords: number;
    averageSgpa: number | null;
    averageCgpa: number | null;
    passedResults: number | null;
  };

  const globalDeptCount = (db.prepare('SELECT COUNT(*) as cnt FROM departments').get() as { cnt: number }).cnt;
  const globalStudentCount = (db.prepare('SELECT COUNT(*) as cnt FROM students').get() as { cnt: number }).cnt;

  const totalExamRecords = totalsRow?.totalExamRecords || 0;
  const passedResults = totalsRow?.passedResults || 0;
  const overallPassRate = totalExamRecords > 0 ? roundToTwo((passedResults / totalExamRecords) * 100) : 0;

  return {
    totalStudents: filter.departmentCode || filter.batchCode ? totalsRow?.totalStudents || 0 : globalStudentCount,
    totalDepartments: filter.departmentCode ? totalsRow?.totalDepartments || 0 : globalDeptCount,
    totalExamRecords,
    averageSgpa: totalsRow?.averageSgpa ?? 0,
    averageCgpa: totalsRow?.averageCgpa ?? 0,
    overallPassRate,
    isDemoData: true,
  };
}

export function getSubjectPassRates(db: Database.Database, filter: AnalyticsFilter = {}) {
  const { sql: whereSql, params } = buildFilterWhere(filter, {
    dept: 'd',
    batch: 'b',
    sem: 'sem',
  });

  const rows = db
    .prepare(
      `SELECT
         sub.id as subjectId,
         sub.subject_code as subjectCode,
         sub.subject_name as subjectName,
         d.code as departmentCode,
         sem.semester_number as semesterNumber,
         sub.credits as credits,
         COUNT(sg.id) as evaluatedCount,
         SUM(CASE WHEN sg.pass_status = 'PASS' THEN 1 ELSE 0 END) as passedCount,
         SUM(CASE WHEN sg.pass_status != 'PASS' THEN 1 ELSE 0 END) as failedCount,
         ROUND(AVG(sg.total_marks), 1) as averageMarks
       FROM subject_grades sg
       JOIN subjects sub ON sub.id = sg.subject_id
       JOIN student_results sr ON sr.id = sg.student_result_id
       JOIN students s ON s.id = sr.student_id
       JOIN departments d ON d.id = s.department_id
       JOIN batches b ON b.id = s.batch_id
       JOIN semesters sem ON sem.id = sr.semester_id
       ${whereSql}
       GROUP BY sub.id
       HAVING evaluatedCount > 0
       ORDER BY (CAST(SUM(CASE WHEN sg.pass_status = 'PASS' THEN 1 ELSE 0 END) AS REAL) / COUNT(sg.id)) ASC, sub.subject_code ASC`
    )
    .all(...params) as Array<{
    subjectId: number;
    subjectCode: string;
    subjectName: string;
    departmentCode: string;
    semesterNumber: number;
    credits: number;
    evaluatedCount: number;
    passedCount: number;
    failedCount: number;
    averageMarks: number;
  }>;

  const subjects = rows.map((r) => {
    const passRate = roundToTwo((r.passedCount / r.evaluatedCount) * 100);
    const failRate = roundToTwo(100 - passRate);
    return {
      ...r,
      passRate,
      failRate,
    };
  });

  const sortedByPass = [...subjects].sort((a, b) => b.passRate - a.passRate);
  const highestPassSubject = sortedByPass[0] || null;
  const lowestPassSubject = sortedByPass[sortedByPass.length - 1] || null;

  return {
    subjects,
    highestPassSubject,
    lowestPassSubject,
    isDemoData: true,
  };
}

export function getDepartmentToppers(
  db: Database.Database,
  filter: AnalyticsFilter & { limit?: number } = {}
) {
  const limit = Math.min(Math.max(filter.limit || 10, 1), 50);
  const { sql: whereSql, params } = buildFilterWhere(filter, {
    dept: 'd',
    batch: 'b',
    sem: 'sem',
  });

  // If semesterNumber specified, rank by that semester's SGPA; otherwise rank by student's latest semester
  const rows = filter.semesterNumber
    ? (db
        .prepare(
          `SELECT
             s.hall_ticket as hallTicket,
             s.full_name as fullName,
             d.code as departmentCode,
             d.name as departmentName,
             b.batch_code as batchCode,
             sem.semester_number as semesterNumber,
             sr.sgpa as sgpa,
             sr.cgpa as cgpa,
             sr.total_credits_earned as creditsEarned,
             sr.total_marks_obtained as totalMarksObtained,
             sr.result_status as resultStatus
           FROM student_results sr
           JOIN students s ON s.id = sr.student_id
           JOIN departments d ON d.id = s.department_id
           JOIN batches b ON b.id = s.batch_id
           JOIN semesters sem ON sem.id = sr.semester_id
           ${whereSql}
           ORDER BY sr.sgpa DESC, sr.cgpa DESC, sr.total_marks_obtained DESC, s.hall_ticket ASC
           LIMIT ?`
        )
        .all(...params, limit) as Array<Record<string, unknown>>)
    : (db
        .prepare(
          `SELECT
             s.hall_ticket as hallTicket,
             s.full_name as fullName,
             d.code as departmentCode,
             d.name as departmentName,
             b.batch_code as batchCode,
             sem.semester_number as semesterNumber,
             sr.sgpa as sgpa,
             sr.cgpa as cgpa,
             (
               SELECT COALESCE(SUM(sr2.total_credits_earned), 0)
               FROM student_results sr2
               WHERE sr2.student_id = s.id
             ) as creditsEarned,
             sr.total_marks_obtained as totalMarksObtained,
             sr.result_status as resultStatus
           FROM student_results sr
           JOIN students s ON s.id = sr.student_id
           JOIN departments d ON d.id = s.department_id
           JOIN batches b ON b.id = s.batch_id
           JOIN semesters sem ON sem.id = sr.semester_id
           INNER JOIN (
             SELECT sr_latest.student_id, MAX(sem_latest.semester_number) as max_sem
             FROM student_results sr_latest
             JOIN semesters sem_latest ON sem_latest.id = sr_latest.semester_id
             GROUP BY sr_latest.student_id
           ) latest ON latest.student_id = s.id AND sem.semester_number = latest.max_sem
           ${whereSql}
           ORDER BY sr.cgpa DESC, sr.sgpa DESC, sr.total_marks_obtained DESC, s.hall_ticket ASC
           LIMIT ?`
        )
        .all(...params, limit) as Array<Record<string, unknown>>);

  const toppers = rows.map((row, idx) => ({
    rank: idx + 1,
    medal: idx === 0 ? 'GOLD' : idx === 1 ? 'SILVER' : idx === 2 ? 'BRONZE' : null,
    ...row,
  }));

  return {
    toppers,
    isDemoData: true,
  };
}

export function getCgpaDistribution(db: Database.Database, filter: AnalyticsFilter = {}) {
  const { sql: whereSql, params } = buildFilterWhere(
    { departmentCode: filter.departmentCode, batchCode: filter.batchCode },
    { dept: 'd', batch: 'b', sem: 'sem' }
  );

  const rows = db
    .prepare(
      `SELECT
         sr.cgpa as cgpa
       FROM student_results sr
       JOIN students s ON s.id = sr.student_id
       JOIN departments d ON d.id = s.department_id
       JOIN batches b ON b.id = s.batch_id
       JOIN semesters sem ON sem.id = sr.semester_id
       INNER JOIN (
         SELECT sr_latest.student_id, MAX(sem_latest.semester_number) as max_sem
         FROM student_results sr_latest
         JOIN semesters sem_latest ON sem_latest.id = sr_latest.semester_id
         GROUP BY sr_latest.student_id
       ) latest ON latest.student_id = s.id AND sem.semester_number = latest.max_sem
       ${whereSql}`
    )
    .all(...params) as Array<{ cgpa: number }>;

  const buckets = [
    { label: '9–10', min: 9, max: 10.01, count: 0 },
    { label: '8–9', min: 8, max: 9, count: 0 },
    { label: '7–8', min: 7, max: 8, count: 0 },
    { label: '6–7', min: 6, max: 7, count: 0 },
    { label: 'Below 6', min: 0, max: 6, count: 0 },
  ];

  for (const row of rows) {
    const val = row.cgpa;
    const target = buckets.find((b) => val >= b.min && val < b.max) || buckets[buckets.length - 1];
    target.count += 1;
  }

  const totalStudents = rows.length;
  const distribution = buckets.map((b) => ({
    range: b.label,
    count: b.count,
    percentage: totalStudents > 0 ? roundToTwo((b.count / totalStudents) * 100) : 0,
  }));

  return {
    totalStudents,
    distribution,
    isDemoData: true,
  };
}

export function getSubjectDifficultyIndex(db: Database.Database, filter: AnalyticsFilter = {}) {
  const { subjects } = getSubjectPassRates(db, filter);

  const ranked = subjects
    .map((s) => {
      // Difficulty Index combines failure rate (70% weight) and inverse average marks (30% weight)
      const normalizedMarkGap = Math.max(0, 100 - s.averageMarks);
      const difficultyIndex = roundToTwo(s.failRate * 0.7 + normalizedMarkGap * 0.3);
      const tier =
        s.failRate >= 25
          ? 'High Difficulty'
          : s.failRate >= 12
            ? 'Moderate Difficulty'
            : 'Standard';
      return {
        subjectCode: s.subjectCode,
        subjectName: s.subjectName,
        departmentCode: s.departmentCode,
        semesterNumber: s.semesterNumber,
        evaluatedCount: s.evaluatedCount,
        passRate: s.passRate,
        failRate: s.failRate,
        averageMarks: s.averageMarks,
        difficultyIndex,
        tier,
      };
    })
    .sort((a, b) => b.difficultyIndex - a.difficultyIndex || b.failRate - a.failRate);

  return {
    subjects: ranked,
    isDemoData: true,
  };
}

export function getBatchComparison(
  db: Database.Database,
  options: { batchCodes?: string[]; departmentCode?: string } = {}
) {
  const deptClause =
    options.departmentCode && options.departmentCode !== 'ALL' ? 'AND d.code = ?' : '';
  const batchCodes =
    options.batchCodes && options.batchCodes.length > 0
      ? options.batchCodes
      : (
          db.prepare('SELECT batch_code FROM batches ORDER BY start_year ASC').all() as Array<{
            batch_code: string;
          }>
        ).map((b) => b.batch_code);

  const placeholders = batchCodes.map(() => '?').join(', ');
  const params: unknown[] = [...batchCodes];
  if (deptClause) {
    params.push(options.departmentCode!.toUpperCase());
  }

  const batchRows = db
    .prepare(
      `SELECT
         b.batch_code as batchCode,
         b.label as batchLabel,
         COUNT(DISTINCT s.id) as studentCount,
         COUNT(sr.id) as resultCount,
         ROUND(AVG(sr.sgpa), 2) as averageSgpa,
         ROUND(AVG(sr.cgpa), 2) as averageCgpa,
         ROUND(
           100.0 * SUM(CASE WHEN sr.result_status = 'PASS' THEN 1 ELSE 0 END) / NULLIF(COUNT(sr.id), 0),
           2
         ) as overallPassRate
       FROM batches b
       LEFT JOIN students s ON s.batch_id = b.id
       LEFT JOIN departments d ON d.id = s.department_id
       LEFT JOIN student_results sr ON sr.student_id = s.id
       WHERE b.batch_code IN (${placeholders})
       ${deptClause}
       GROUP BY b.id
       ORDER BY b.start_year ASC`
    )
    .all(...params) as Array<{
    batchCode: string;
    batchLabel: string;
    studentCount: number;
    resultCount: number;
    averageSgpa: number | null;
    averageCgpa: number | null;
    overallPassRate: number | null;
  }>;

  // Subject-wise comparison for Semester 1 (common across all 3 cohorts) + any shared semesters
  const subjectComparison = db
    .prepare(
      `SELECT
         b.batch_code as batchCode,
         sub.subject_code as subjectCode,
         sub.subject_name as subjectName,
         sem.semester_number as semesterNumber,
         ROUND(AVG(sg.total_marks), 1) as averageMarks,
         ROUND(
           100.0 * SUM(CASE WHEN sg.pass_status = 'PASS' THEN 1 ELSE 0 END) / COUNT(sg.id),
           1
         ) as passRate
       FROM subject_grades sg
       JOIN subjects sub ON sub.id = sg.subject_id
       JOIN student_results sr ON sr.id = sg.student_result_id
       JOIN students s ON s.id = sr.student_id
       JOIN departments d ON d.id = s.department_id
       JOIN batches b ON b.id = s.batch_id
       JOIN semesters sem ON sem.id = sr.semester_id
       WHERE b.batch_code IN (${placeholders})
       ${deptClause}
       GROUP BY b.batch_code, sub.id
       ORDER BY sem.semester_number ASC, sub.subject_code ASC, b.start_year ASC`
    )
    .all(...params);

  return {
    batches: batchRows.map((b) => ({
      ...b,
      averageSgpa: b.averageSgpa ?? 0,
      averageCgpa: b.averageCgpa ?? 0,
      overallPassRate: b.overallPassRate ?? 0,
    })),
    subjectComparison,
    isDemoData: true,
  };
}
