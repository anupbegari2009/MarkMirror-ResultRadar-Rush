import type { NextFunction, Request, Response } from 'express';
import { getDb } from '../database/db.ts';
import {
  getAnalyticsOverview,
  getBatchComparison,
  getCgpaDistribution,
  getDepartmentToppers,
  getSubjectDifficultyIndex,
  getSubjectPassRates,
  type AnalyticsFilter,
} from '../services/analyticsService.ts';

function extractAnalyticsFilter(req: Request): AnalyticsFilter {
  const departmentCode =
    typeof req.query.department === 'string' && req.query.department.trim()
      ? req.query.department.trim().toUpperCase()
      : undefined;
  const batchCode =
    typeof req.query.batch === 'string' && req.query.batch.trim()
      ? req.query.batch.trim()
      : undefined;
  const semRaw = req.query.semester ? Number(req.query.semester) : undefined;
  const semesterNumber = semRaw && Number.isInteger(semRaw) && semRaw > 0 ? semRaw : undefined;

  return { departmentCode, batchCode, semesterNumber };
}

export function getOverview(req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const filter = extractAnalyticsFilter(req);
    res.json(getAnalyticsOverview(db, filter));
  } catch (err) {
    next(err);
  }
}

export function getPassRates(req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const filter = extractAnalyticsFilter(req);
    res.json(getSubjectPassRates(db, filter));
  } catch (err) {
    next(err);
  }
}

export function getToppers(req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const filter = extractAnalyticsFilter(req);
    const limitRaw = req.query.limit ? Number(req.query.limit) : 10;
    const limit = Number.isInteger(limitRaw) && limitRaw > 0 ? limitRaw : 10;
    res.json(getDepartmentToppers(db, { ...filter, limit }));
  } catch (err) {
    next(err);
  }
}

export function getCgpaDistributionHandler(req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const filter = extractAnalyticsFilter(req);
    res.json(getCgpaDistribution(db, filter));
  } catch (err) {
    next(err);
  }
}

export function getSubjectDifficulty(req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const filter = extractAnalyticsFilter(req);
    res.json(getSubjectDifficultyIndex(db, filter));
  } catch (err) {
    next(err);
  }
}

export function getBatchComparisonHandler(req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const batchesParam = typeof req.query.batches === 'string' ? req.query.batches : '';
    const batchCodes = batchesParam
      .split(',')
      .map((b) => b.trim())
      .filter(Boolean);
    const departmentCode =
      typeof req.query.department === 'string' && req.query.department.trim()
        ? req.query.department.trim().toUpperCase()
        : undefined;

    res.json(getBatchComparison(db, { batchCodes, departmentCode }));
  } catch (err) {
    next(err);
  }
}

export function getFiltersMetadata(_req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const departments = db
      .prepare('SELECT id, code, name, head_of_department as headOfDepartment FROM departments ORDER BY code ASC')
      .all();
    const batches = db
      .prepare('SELECT id, batch_code as batchCode, start_year as startYear, end_year as endYear, label FROM batches ORDER BY start_year ASC')
      .all();
    const semesters = db
      .prepare('SELECT id, semester_number as semesterNumber, title, academic_year as academicYear FROM semesters ORDER BY semester_number ASC')
      .all();
    res.json({ departments, batches, semesters });
  } catch (err) {
    next(err);
  }
}

export function getGradingScaleMetadata(_req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const rules = db
      .prepare(
        `SELECT
           id,
           scale_name as scaleName,
           letter_grade as letterGrade,
           grade_point as gradePoint,
           min_marks as minMarks,
           max_marks as maxMarks,
           is_passing as isPassing,
           is_verified_rule as isVerifiedRule,
           description
         FROM grading_scales
         ORDER BY grade_point DESC, min_marks DESC`
      )
      .all() as Array<Record<string, unknown>>;

    res.json({
      rules: rules.map((r) => ({
        ...r,
        isPassing: Boolean(r.isPassing),
        isVerifiedRule: Boolean(r.isVerifiedRule),
      })),
      note: 'Grades O=10, A+=9, A=8 follow the MarkMirror specification. Additional brackets are configurable sample assumptions.',
    });
  } catch (err) {
    next(err);
  }
}
