import bcrypt from 'bcryptjs';
import type { NextFunction, Request, Response } from 'express';
import { getDb } from '../database/db.ts';
import {
  signAdminToken,
  type AdminRole,
  type AuthenticatedRequest,
} from '../middleware/auth.ts';
import {
  ApiError,
  isValidHallTicketFormat,
  parsePositiveInt,
  sanitizeHallTicket,
} from '../middleware/errorHandler.ts';
import {
  calculateCGPA,
  calculateSGPA,
  type GradingScaleRule,
  type SubjectEvaluationConfig,
} from '../services/calculationService.ts';

function loadGradingScaleFromDb(): GradingScaleRule[] {
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT letter_grade as letterGrade, grade_point as gradePoint, min_marks as minMarks, max_marks as maxMarks, is_passing as isPassing, is_verified_rule as isVerifiedRule, description
       FROM grading_scales`
    )
    .all() as Array<{
    letterGrade: string;
    gradePoint: number;
    minMarks: number;
    maxMarks: number;
    isPassing: number;
    isVerifiedRule: number;
    description: string;
  }>;

  return rows.map((r) => ({
    letterGrade: r.letterGrade,
    gradePoint: r.gradePoint,
    minMarks: r.minMarks,
    maxMarks: r.maxMarks,
    isPassing: Boolean(r.isPassing),
    isVerifiedRule: Boolean(r.isVerifiedRule),
    description: r.description,
  }));
}

function recomputeStudentCgpHistory(studentId: number): void {
  const db = getDb();
  const results = db
    .prepare(
      `SELECT sr.id, sem.semester_number as semesterNumber, sr.academic_year as academicYear, sr.sgpa, sr.total_credits_attempted as creditsAttempted, sr.total_credits_earned as creditsEarned, sr.result_status as resultStatus
       FROM student_results sr
       JOIN semesters sem ON sem.id = sr.semester_id
       WHERE sr.student_id = ?
       ORDER BY sem.semester_number ASC`
    )
    .all(studentId) as Array<{
    id: number;
    semesterNumber: number;
    academicYear: string;
    sgpa: number;
    creditsAttempted: number;
    creditsEarned: number;
    resultStatus: string;
  }>;

  const summaries: Array<{ semesterNumber: number; creditsAttempted: number; sgpa: number }> = [];
  const updateResultCgpa = db.prepare('UPDATE student_results SET cgpa = ? WHERE id = ?');
  const upsertHistorical = db.prepare(
    `INSERT INTO historical_results (student_id, semester_number, academic_year, sgpa, cgpa, credits_earned, pass_status)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(student_id, semester_number) DO UPDATE SET
       academic_year = excluded.academic_year,
       sgpa = excluded.sgpa,
       cgpa = excluded.cgpa,
       credits_earned = excluded.credits_earned,
       pass_status = excluded.pass_status,
       recorded_at = datetime('now')`
  );

  for (const row of results) {
    summaries.push({
      semesterNumber: row.semesterNumber,
      creditsAttempted: row.creditsAttempted,
      sgpa: row.sgpa,
    });
    const cgpa = calculateCGPA(summaries);
    updateResultCgpa.run(cgpa, row.id);
    upsertHistorical.run(
      studentId,
      row.semesterNumber,
      row.academicYear,
      row.sgpa,
      cgpa,
      row.creditsEarned,
      row.resultStatus
    );
  }
}

export function loginAdmin(req: Request, res: Response, next: NextFunction): void {
  try {
    const username = typeof req.body?.username === 'string' ? req.body.username.trim() : '';
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    if (!username || !password) {
      throw new ApiError(400, 'Username and password are required.');
    }

    const db = getDb();
    const admin = db
      .prepare(
        `SELECT id, username, full_name as fullName, email, password_hash as passwordHash, role, department_id as departmentId
         FROM administrators
         WHERE username = ?`
      )
      .get(username) as
      | {
          id: number;
          username: string;
          fullName: string;
          email: string;
          passwordHash: string;
          role: AdminRole;
          departmentId: number | null;
        }
      | undefined;

    if (!admin || !bcrypt.compareSync(password, admin.passwordHash)) {
      throw new ApiError(401, 'Invalid administrator credentials.');
    }

    const token = signAdminToken({
      sub: admin.id,
      username: admin.username,
      fullName: admin.fullName,
      role: admin.role,
      departmentId: admin.departmentId,
    });

    res.json({
      token,
      user: {
        id: admin.id,
        username: admin.username,
        fullName: admin.fullName,
        email: admin.email,
        role: admin.role,
        departmentId: admin.departmentId,
      },
    });
  } catch (err) {
    next(err);
  }
}

export function getCurrentAdmin(req: AuthenticatedRequest, res: Response): void {
  res.json({ user: req.user });
}

export function listStudents(req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const page = parsePositiveInt(req.query.page, 1, 1000);
    const limit = parsePositiveInt(req.query.limit, 20, 100);
    const offset = (page - 1) * limit;
    const search = typeof req.query.search === 'string' ? req.query.search.trim() : '';
    const department =
      typeof req.query.department === 'string' && req.query.department !== 'ALL'
        ? req.query.department.trim().toUpperCase()
        : '';

    const clauses: string[] = [];
    const params: unknown[] = [];
    if (search) {
      clauses.push('(s.hall_ticket LIKE ? OR s.full_name LIKE ?)');
      params.push(`%${search}%`, `%${search}%`);
    }
    if (department) {
      clauses.push('d.code = ?');
      params.push(department);
    }
    const whereSql = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';

    const totalRow = db
      .prepare(
        `SELECT COUNT(*) as total
         FROM students s
         JOIN departments d ON d.id = s.department_id
         ${whereSql}`
      )
      .get(...params) as { total: number };

    const students = db
      .prepare(
        `SELECT
           s.id,
           s.hall_ticket as hallTicket,
           s.full_name as fullName,
           d.code as departmentCode,
           d.name as departmentName,
           b.batch_code as batchCode,
           s.current_semester as currentSemester,
           s.email,
           s.is_demo_data as isDemoData,
           (SELECT sr.cgpa FROM student_results sr JOIN semesters sem ON sem.id = sr.semester_id WHERE sr.student_id = s.id ORDER BY sem.semester_number DESC LIMIT 1) as latestCgpa
         FROM students s
         JOIN departments d ON d.id = s.department_id
         JOIN batches b ON b.id = s.batch_id
         ${whereSql}
         ORDER BY s.hall_ticket ASC
         LIMIT ? OFFSET ?`
      )
      .all(...params, limit, offset);

    res.json({
      students,
      pagination: {
        page,
        limit,
        total: totalRow.total,
        totalPages: Math.max(1, Math.ceil(totalRow.total / limit)),
      },
    });
  } catch (err) {
    next(err);
  }
}

export function createStudent(req: Request, res: Response, next: NextFunction): void {
  try {
    const hallTicket = sanitizeHallTicket(String(req.body?.hallTicket || ''));
    const fullName = typeof req.body?.fullName === 'string' ? req.body.fullName.trim() : '';
    const departmentCode = typeof req.body?.departmentCode === 'string' ? req.body.departmentCode.trim().toUpperCase() : '';
    const batchCode = typeof req.body?.batchCode === 'string' ? req.body.batchCode.trim() : '';
    const currentSemester = Number(req.body?.currentSemester || 1);
    const dobVerification = typeof req.body?.dobVerification === 'string' ? req.body.dobVerification.trim() : '2004-01-01';
    const email = typeof req.body?.email === 'string' ? req.body.email.trim() : `${hallTicket.toLowerCase()}@demo.markmirror.edu`;

    if (!isValidHallTicketFormat(hallTicket)) {
      throw new ApiError(400, 'Invalid hall ticket format (e.g. 22CSE155).');
    }
    if (fullName.length < 2) {
      throw new ApiError(400, 'Full name must be at least 2 characters.');
    }
    if (!Number.isInteger(currentSemester) || currentSemester < 1 || currentSemester > 10) {
      throw new ApiError(400, 'Current semester must be between 1 and 10.');
    }

    const db = getDb();
    const dept = db.prepare('SELECT id FROM departments WHERE code = ?').get(departmentCode) as { id: number } | undefined;
    if (!dept) {
      throw new ApiError(400, `Department '${departmentCode}' does not exist.`);
    }
    const batch = db.prepare('SELECT id FROM batches WHERE batch_code = ?').get(batchCode) as { id: number } | undefined;
    if (!batch) {
      throw new ApiError(400, `Batch '${batchCode}' does not exist.`);
    }

    const info = db
      .prepare(
        `INSERT INTO students (hall_ticket, full_name, department_id, batch_id, current_semester, dob_verification, email, is_demo_data)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0)`
      )
      .run(hallTicket, fullName, dept.id, batch.id, currentSemester, dobVerification, email);

    res.status(201).json({
      message: 'Student record created successfully.',
      student: {
        id: Number(info.lastInsertRowid),
        hallTicket,
        fullName,
        departmentCode,
        batchCode,
        currentSemester,
        email,
      },
    });
  } catch (err) {
    next(err);
  }
}

export function listSubjects(req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const department =
      typeof req.query.department === 'string' && req.query.department !== 'ALL'
        ? req.query.department.trim().toUpperCase()
        : '';
    const semester = req.query.semester ? Number(req.query.semester) : null;

    const clauses: string[] = [];
    const params: unknown[] = [];
    if (department) {
      clauses.push('d.code = ?');
      params.push(department);
    }
    if (semester && Number.isInteger(semester)) {
      clauses.push('sem.semester_number = ?');
      params.push(semester);
    }
    const whereSql = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';

    const subjects = db
      .prepare(
        `SELECT
           sub.id,
           sub.subject_code as subjectCode,
           sub.subject_name as subjectName,
           d.code as departmentCode,
           sem.semester_number as semesterNumber,
           sub.credits,
           sub.max_internal as maxInternal,
           sub.max_external as maxExternal,
           sub.pass_internal_min as passInternalMin,
           sub.pass_external_min as passExternalMin,
           sub.pass_total_min as passTotalMin,
           sub.is_credit_bearing as isCreditBearing
         FROM subjects sub
         JOIN departments d ON d.id = sub.department_id
         JOIN semesters sem ON sem.id = sub.semester_id
         ${whereSql}
         ORDER BY d.code ASC, sem.semester_number ASC, sub.subject_code ASC`
      )
      .all(...params);

    res.json({ subjects });
  } catch (err) {
    next(err);
  }
}

export function createSubject(req: Request, res: Response, next: NextFunction): void {
  try {
    const subjectCode = typeof req.body?.subjectCode === 'string' ? req.body.subjectCode.trim().toUpperCase() : '';
    const subjectName = typeof req.body?.subjectName === 'string' ? req.body.subjectName.trim() : '';
    const departmentCode = typeof req.body?.departmentCode === 'string' ? req.body.departmentCode.trim().toUpperCase() : '';
    const semesterNumber = Number(req.body?.semesterNumber);
    const credits = Number(req.body?.credits);
    const isCreditBearing = req.body?.isCreditBearing !== false;

    if (!/^[A-Z0-9]{3,12}$/.test(subjectCode)) {
      throw new ApiError(400, 'Subject code must be 3–12 alphanumeric characters.');
    }
    if (subjectName.length < 2) {
      throw new ApiError(400, 'Subject name is required.');
    }
    if (!Number.isFinite(credits) || credits < 0 || credits > 12) {
      throw new ApiError(400, 'Credits must be between 0 and 12.');
    }

    const db = getDb();
    const dept = db.prepare('SELECT id FROM departments WHERE code = ?').get(departmentCode) as { id: number } | undefined;
    if (!dept) {
      throw new ApiError(400, `Department '${departmentCode}' not found.`);
    }
    const sem = db.prepare('SELECT id FROM semesters WHERE semester_number = ?').get(semesterNumber) as { id: number } | undefined;
    if (!sem) {
      throw new ApiError(400, `Semester ${semesterNumber} not found.`);
    }

    const info = db
      .prepare(
        `INSERT INTO subjects (subject_code, subject_name, department_id, semester_id, credits, is_credit_bearing)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(subjectCode, subjectName, dept.id, sem.id, credits, isCreditBearing ? 1 : 0);

    res.status(201).json({
      message: 'Subject created successfully.',
      subject: {
        id: Number(info.lastInsertRowid),
        subjectCode,
        subjectName,
        departmentCode,
        semesterNumber,
        credits,
        isCreditBearing,
      },
    });
  } catch (err) {
    next(err);
  }
}

export function listResults(req: Request, res: Response, next: NextFunction): void {
  try {
    const db = getDb();
    const page = parsePositiveInt(req.query.page, 1, 1000);
    const limit = parsePositiveInt(req.query.limit, 20, 100);
    const offset = (page - 1) * limit;
    const search = typeof req.query.search === 'string' ? req.query.search.trim() : '';
    const department =
      typeof req.query.department === 'string' && req.query.department !== 'ALL'
        ? req.query.department.trim().toUpperCase()
        : '';

    const clauses: string[] = [];
    const params: unknown[] = [];
    if (search) {
      clauses.push('(s.hall_ticket LIKE ? OR s.full_name LIKE ?)');
      params.push(`%${search}%`, `%${search}%`);
    }
    if (department) {
      clauses.push('d.code = ?');
      params.push(department);
    }
    const whereSql = clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '';

    const totalRow = db
      .prepare(
        `SELECT COUNT(*) as total
         FROM student_results sr
         JOIN students s ON s.id = sr.student_id
         JOIN departments d ON d.id = s.department_id
         ${whereSql}`
      )
      .get(...params) as { total: number };

    const results = db
      .prepare(
        `SELECT
           sr.id as resultId,
           s.hall_ticket as hallTicket,
           s.full_name as fullName,
           d.code as departmentCode,
           b.batch_code as batchCode,
           sem.semester_number as semesterNumber,
           sr.academic_year as academicYear,
           sr.sgpa,
           sr.cgpa,
           sr.total_credits_earned as totalCreditsEarned,
           sr.total_marks_obtained as totalMarksObtained,
           sr.total_max_marks as totalMaxMarks,
           sr.result_status as resultStatus,
           sr.published_at as publishedAt
         FROM student_results sr
         JOIN students s ON s.id = sr.student_id
         JOIN departments d ON d.id = s.department_id
         JOIN batches b ON b.id = s.batch_id
         JOIN semesters sem ON sem.id = sr.semester_id
         ${whereSql}
         ORDER BY sem.semester_number DESC, s.hall_ticket ASC
         LIMIT ? OFFSET ?`
      )
      .all(...params, limit, offset);

    res.json({
      results,
      pagination: {
        page,
        limit,
        total: totalRow.total,
        totalPages: Math.max(1, Math.ceil(totalRow.total / limit)),
      },
    });
  } catch (err) {
    next(err);
  }
}

interface MarkPayloadItem {
  subjectCode: string;
  internalMarks: number;
  externalMarks: number;
  isAbsent?: boolean;
}

export function createResult(req: Request, res: Response, next: NextFunction): void {
  try {
    const hallTicket = sanitizeHallTicket(String(req.body?.hallTicket || ''));
    const semesterNumber = Number(req.body?.semesterNumber);
    const academicYear = typeof req.body?.academicYear === 'string' ? req.body.academicYear.trim() : '2024-25';
    const marksInput = Array.isArray(req.body?.marks) ? (req.body.marks as MarkPayloadItem[]) : [];

    if (!isValidHallTicketFormat(hallTicket)) {
      throw new ApiError(400, 'Invalid hall ticket format.');
    }
    if (!Number.isInteger(semesterNumber) || semesterNumber < 1 || semesterNumber > 10) {
      throw new ApiError(400, 'Semester number must be between 1 and 10.');
    }
    if (marksInput.length === 0) {
      throw new ApiError(400, 'At least one subject mark entry is required.');
    }

    const db = getDb();
    const student = db.prepare('SELECT id FROM students WHERE hall_ticket = ?').get(hallTicket) as { id: number } | undefined;
    if (!student) {
      throw new ApiError(404, `Student ${hallTicket} not found.`);
    }
    const sem = db.prepare('SELECT id FROM semesters WHERE semester_number = ?').get(semesterNumber) as { id: number } | undefined;
    if (!sem) {
      throw new ApiError(404, `Semester ${semesterNumber} not found.`);
    }

    const gradingScale = loadGradingScaleFromDb();
    const resolvedInputs = marksInput.map((item) => {
      const code = String(item.subjectCode || '').trim().toUpperCase();
      const subjRow = db
        .prepare(
          `SELECT id, subject_code as subjectCode, subject_name as subjectName, credits, max_internal as maxInternal, max_external as maxExternal, pass_internal_min as passInternalMin, pass_external_min as passExternalMin, pass_total_min as passTotalMin, is_credit_bearing as isCreditBearing
           FROM subjects
           WHERE subject_code = ?`
        )
        .get(code) as (Omit<SubjectEvaluationConfig, 'isCreditBearing'> & { id: number; isCreditBearing: number }) | undefined;
      if (!subjRow) {
        throw new ApiError(400, `Subject code '${code}' does not exist.`);
      }
      return {
        subjectId: subjRow.id,
        input: {
          internalMarks: Number(item.internalMarks),
          externalMarks: Number(item.externalMarks),
          isAbsent: Boolean(item.isAbsent),
          subject: {
            ...subjRow,
            isCreditBearing: Boolean(subjRow.isCreditBearing),
          },
        },
      };
    });

    const calc = calculateSGPA(
      resolvedInputs.map((r) => r.input),
      gradingScale
    );

    const createdId = db.transaction(() => {
      const resultInfo = db
        .prepare(
          `INSERT INTO student_results
            (student_id, semester_id, academic_year, sgpa, cgpa, total_credits_attempted, total_credits_earned, total_marks_obtained, total_max_marks, result_status, is_demo_data)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)`
        )
        .run(
          student.id,
          sem.id,
          academicYear,
          calc.sgpa,
          calc.sgpa,
          calc.totalCreditsAttempted,
          calc.totalCreditsEarned,
          calc.totalMarksObtained,
          calc.totalMaxMarks,
          calc.resultStatus
        );

      const newResultId = Number(resultInfo.lastInsertRowid);
      const insertGrade = db.prepare(
        `INSERT INTO subject_grades
          (student_result_id, subject_id, internal_marks, external_marks, total_marks, letter_grade, grade_point, credits, is_absent, pass_status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      );

      for (let i = 0; i < calc.subjects.length; i++) {
        const g = calc.subjects[i];
        insertGrade.run(
          newResultId,
          resolvedInputs[i].subjectId,
          g.internalMarks,
          g.externalMarks,
          g.totalMarks,
          g.letterGrade,
          g.gradePoint,
          g.credits,
          g.isAbsent ? 1 : 0,
          g.passStatus
        );
      }

      recomputeStudentCgpHistory(student.id);
      return newResultId;
    })();

    res.status(201).json({
      message: 'Examination result published and SGPA/CGPA calculated.',
      resultId: createdId,
      sgpa: calc.sgpa,
      resultStatus: calc.resultStatus,
    });
  } catch (err) {
    if (err instanceof Error && !(err instanceof ApiError)) {
      if (err.message.includes('must be an integer')) {
        next(new ApiError(400, err.message));
        return;
      }
    }
    next(err);
  }
}

export function updateResult(req: Request, res: Response, next: NextFunction): void {
  try {
    const resultId = Number(req.params.resultId);
    if (!Number.isInteger(resultId) || resultId < 1) {
      throw new ApiError(400, 'Invalid resultId.');
    }

    const marksInput = Array.isArray(req.body?.marks) ? (req.body.marks as MarkPayloadItem[]) : [];
    if (marksInput.length === 0) {
      throw new ApiError(400, 'Provide updated subject marks array.');
    }

    const db = getDb();
    const existing = db
      .prepare('SELECT id, student_id as studentId FROM student_results WHERE id = ?')
      .get(resultId) as { id: number; studentId: number } | undefined;

    if (!existing) {
      throw new ApiError(404, `Result #${resultId} not found.`);
    }

    const gradingScale = loadGradingScaleFromDb();
    const resolvedInputs = marksInput.map((item) => {
      const code = String(item.subjectCode || '').trim().toUpperCase();
      const subjRow = db
        .prepare(
          `SELECT id, subject_code as subjectCode, subject_name as subjectName, credits, max_internal as maxInternal, max_external as maxExternal, pass_internal_min as passInternalMin, pass_external_min as passExternalMin, pass_total_min as passTotalMin, is_credit_bearing as isCreditBearing
           FROM subjects
           WHERE subject_code = ?`
        )
        .get(code) as (Omit<SubjectEvaluationConfig, 'isCreditBearing'> & { id: number; isCreditBearing: number }) | undefined;
      if (!subjRow) {
        throw new ApiError(400, `Subject code '${code}' does not exist.`);
      }
      return {
        subjectId: subjRow.id,
        input: {
          internalMarks: Number(item.internalMarks),
          externalMarks: Number(item.externalMarks),
          isAbsent: Boolean(item.isAbsent),
          subject: {
            ...subjRow,
            isCreditBearing: Boolean(subjRow.isCreditBearing),
          },
        },
      };
    });

    const calc = calculateSGPA(
      resolvedInputs.map((r) => r.input),
      gradingScale
    );

    db.transaction(() => {
      db.prepare(
        `UPDATE student_results
         SET sgpa = ?, total_credits_attempted = ?, total_credits_earned = ?, total_marks_obtained = ?, total_max_marks = ?, result_status = ?, published_at = datetime('now')
         WHERE id = ?`
      ).run(
        calc.sgpa,
        calc.totalCreditsAttempted,
        calc.totalCreditsEarned,
        calc.totalMarksObtained,
        calc.totalMaxMarks,
        calc.resultStatus,
        resultId
      );

      db.prepare('DELETE FROM subject_grades WHERE student_result_id = ?').run(resultId);
      const insertGrade = db.prepare(
        `INSERT INTO subject_grades
          (student_result_id, subject_id, internal_marks, external_marks, total_marks, letter_grade, grade_point, credits, is_absent, pass_status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      );

      for (let i = 0; i < calc.subjects.length; i++) {
        const g = calc.subjects[i];
        insertGrade.run(
          resultId,
          resolvedInputs[i].subjectId,
          g.internalMarks,
          g.externalMarks,
          g.totalMarks,
          g.letterGrade,
          g.gradePoint,
          g.credits,
          g.isAbsent ? 1 : 0,
          g.passStatus
        );
      }

      recomputeStudentCgpHistory(existing.studentId);
    })();

    res.json({
      message: 'Result updated and SGPA/CGPA recalculated.',
      resultId,
      sgpa: calc.sgpa,
      resultStatus: calc.resultStatus,
    });
  } catch (err) {
    if (err instanceof Error && !(err instanceof ApiError)) {
      if (err.message.includes('must be an integer')) {
        next(new ApiError(400, err.message));
        return;
      }
    }
    next(err);
  }
}

export function deleteResult(req: Request, res: Response, next: NextFunction): void {
  try {
    const resultId = Number(req.params.resultId);
    if (!Number.isInteger(resultId) || resultId < 1) {
      throw new ApiError(400, 'Invalid resultId.');
    }

    const db = getDb();
    const existing = db
      .prepare(
        `SELECT sr.id, sr.student_id as studentId, sem.semester_number as semesterNumber
         FROM student_results sr
         JOIN semesters sem ON sem.id = sr.semester_id
         WHERE sr.id = ?`
      )
      .get(resultId) as { id: number; studentId: number; semesterNumber: number } | undefined;

    if (!existing) {
      throw new ApiError(404, `Result #${resultId} not found.`);
    }

    db.transaction(() => {
      db.prepare('DELETE FROM student_results WHERE id = ?').run(resultId);
      db.prepare('DELETE FROM historical_results WHERE student_id = ? AND semester_number = ?').run(
        existing.studentId,
        existing.semesterNumber
      );
      recomputeStudentCgpHistory(existing.studentId);
    })();

    res.json({ message: `Result #${resultId} deleted and CGPA history recomputed.` });
  } catch (err) {
    next(err);
  }
}
