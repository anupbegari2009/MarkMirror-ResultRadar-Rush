import type { NextFunction, Request, Response } from 'express';
import { getDb } from '../database/db.ts';
import { ApiError, isValidHallTicketFormat, sanitizeHallTicket } from '../middleware/errorHandler.ts';
import { estimateReevaluationFee, roundToTwo } from '../services/calculationService.ts';

function maskEmail(email: string): string {
  const [local, domain] = email.split('@');
  if (!local || !domain) return '***';
  const visible = local.slice(0, 2);
  return `${visible}${'*'.repeat(Math.max(3, local.length - 2))}@${domain}`;
}

export function getStudentByHallTicket(req: Request, res: Response, next: NextFunction): void {
  try {
    const hallTicket = sanitizeHallTicket(String(req.params.hallTicket || ''));
    if (!isValidHallTicketFormat(hallTicket)) {
      throw new ApiError(
        400,
        'Invalid hall ticket format. Expected format like 22CSE104 (2-digit year, branch code, roll number).'
      );
    }

    const db = getDb();
    const student = db
      .prepare(
        `SELECT
           s.id,
           s.hall_ticket as hallTicket,
           s.full_name as fullName,
           s.current_semester as currentSemester,
           s.dob_verification as dobVerification,
           s.email,
           s.is_demo_data as isDemoData,
           d.code as departmentCode,
           d.name as departmentName,
           b.batch_code as batchCode,
           b.label as batchLabel
         FROM students s
         JOIN departments d ON d.id = s.department_id
         JOIN batches b ON b.id = s.batch_id
         WHERE s.hall_ticket = ?`
      )
      .get(hallTicket) as
      | {
          id: number;
          hallTicket: string;
          fullName: string;
          currentSemester: number;
          dobVerification: string;
          email: string;
          isDemoData: number;
          departmentCode: string;
          departmentName: string;
          batchCode: string;
          batchLabel: string;
        }
      | undefined;

    if (!student) {
      throw new ApiError(404, `No student record found for hall ticket ${hallTicket}.`);
    }

    const dobParam = typeof req.query.dob === 'string' ? req.query.dob.trim() : '';
    const isIdentityVerified = Boolean(dobParam && dobParam === student.dobVerification);

    const semesters = db
      .prepare(
        `SELECT
           sr.id as resultId,
           sem.semester_number as semesterNumber,
           sem.title as semesterTitle,
           sr.academic_year as academicYear,
           sr.sgpa,
           sr.cgpa,
           sr.result_status as resultStatus
         FROM student_results sr
         JOIN semesters sem ON sem.id = sr.semester_id
         WHERE sr.student_id = ?
         ORDER BY sem.semester_number ASC`
      )
      .all(student.id);

    res.json({
      student: {
        id: student.id,
        hallTicket: student.hallTicket,
        fullName: student.fullName,
        departmentCode: student.departmentCode,
        departmentName: student.departmentName,
        branch: student.departmentName,
        batchCode: student.batchCode,
        batchLabel: student.batchLabel,
        currentSemester: student.currentSemester,
        email: isIdentityVerified ? student.email : maskEmail(student.email),
        identityVerified: isIdentityVerified,
        isDemoData: Boolean(student.isDemoData),
      },
      semesters,
      demoNotice: student.isDemoData
        ? 'DEMONSTRATION DATA: Synthetic academic records generated for MarkMirror evaluation.'
        : null,
    });
  } catch (err) {
    next(err);
  }
}

export function verifyStudentIdentity(req: Request, res: Response, next: NextFunction): void {
  try {
    const hallTicket = sanitizeHallTicket(String(req.params.hallTicket || ''));
    const dob = typeof req.body?.dob === 'string' ? req.body.dob.trim() : '';
    if (!isValidHallTicketFormat(hallTicket)) {
      throw new ApiError(400, 'Invalid hall ticket format.');
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dob)) {
      throw new ApiError(400, 'Date of birth must be in YYYY-MM-DD format.');
    }

    const db = getDb();
    const student = db
      .prepare('SELECT hall_ticket as hallTicket, dob_verification as dob, email FROM students WHERE hall_ticket = ?')
      .get(hallTicket) as { hallTicket: string; dob: string; email: string } | undefined;

    if (!student) {
      throw new ApiError(404, `No student record found for hall ticket ${hallTicket}.`);
    }

    if (student.dob !== dob) {
      throw new ApiError(403, 'Identity verification failed. Date of birth does not match university records.');
    }

    res.json({
      verified: true,
      hallTicket: student.hallTicket,
      email: student.email,
      verifiedAt: new Date().toISOString(),
    });
  } catch (err) {
    next(err);
  }
}

function buildResultPayload(resultId: number) {
  const db = getDb();
  const header = db
    .prepare(
      `SELECT
         sr.id as resultId,
         sr.academic_year as academicYear,
         sr.sgpa,
         sr.cgpa,
         sr.total_credits_attempted as totalCreditsAttempted,
         sr.total_credits_earned as totalCreditsEarned,
         sr.total_marks_obtained as totalMarksObtained,
         sr.total_max_marks as totalMaxMarks,
         sr.result_status as resultStatus,
         sr.published_at as publishedAt,
         sr.is_demo_data as isDemoData,
         sem.semester_number as semesterNumber,
         sem.title as semesterTitle,
         s.id as studentId,
         s.hall_ticket as hallTicket,
         s.full_name as fullName,
         s.email,
         s.dob_verification as dobVerification,
         d.code as departmentCode,
         d.name as departmentName,
         b.batch_code as batchCode,
         b.label as batchLabel
       FROM student_results sr
       JOIN students s ON s.id = sr.student_id
       JOIN departments d ON d.id = s.department_id
       JOIN batches b ON b.id = s.batch_id
       JOIN semesters sem ON sem.id = sr.semester_id
       WHERE sr.id = ?`
    )
    .get(resultId) as Record<string, unknown> | undefined;

  if (!header) {
    return null;
  }

  const subjects = db
    .prepare(
      `SELECT
         sub.id as subjectId,
         sub.subject_code as subjectCode,
         sub.subject_name as subjectName,
         sub.max_internal as maxInternal,
         sub.max_external as maxExternal,
         sub.is_credit_bearing as isCreditBearing,
         sg.internal_marks as internalMarks,
         sg.external_marks as externalMarks,
         sg.total_marks as totalMarks,
         sg.letter_grade as letterGrade,
         sg.grade_point as gradePoint,
         sg.credits,
         sg.is_absent as isAbsent,
         sg.pass_status as passStatus
       FROM subject_grades sg
       JOIN subjects sub ON sub.id = sg.subject_id
       WHERE sg.student_result_id = ?
       ORDER BY sub.subject_code ASC`
    )
    .all(resultId) as Array<Record<string, unknown>>;

  return {
    resultId: header.resultId,
    student: {
      hallTicket: header.hallTicket,
      fullName: header.fullName,
      departmentCode: header.departmentCode,
      departmentName: header.departmentName,
      branch: header.departmentName,
      batchCode: header.batchCode,
      batchLabel: header.batchLabel,
      emailMasked: maskEmail(String(header.email || '')),
    },
    semester: {
      semesterNumber: header.semesterNumber,
      semesterTitle: header.semesterTitle,
      academicYear: header.academicYear,
    },
    summary: {
      sgpa: header.sgpa,
      cgpa: header.cgpa,
      totalCreditsAttempted: header.totalCreditsAttempted,
      totalCreditsEarned: header.totalCreditsEarned,
      totalMarksObtained: header.totalMarksObtained,
      totalMaxMarks: header.totalMaxMarks,
      resultStatus: header.resultStatus,
      publishedAt: header.publishedAt,
    },
    subjects: subjects.map((s) => ({
      ...s,
      isAbsent: Boolean(s.isAbsent),
      isCreditBearing: Boolean(s.isCreditBearing),
      maxMarks: Number(s.maxInternal) + Number(s.maxExternal),
    })),
    isDemoData: Boolean(header.isDemoData),
    generatedAt: new Date().toISOString(),
  };
}

export function getStudentResults(req: Request, res: Response, next: NextFunction): void {
  try {
    const hallTicket = sanitizeHallTicket(String(req.params.hallTicket || ''));
    if (!isValidHallTicketFormat(hallTicket)) {
      throw new ApiError(
        400,
        'Invalid hall ticket format. Expected format like 22CSE104.'
      );
    }

    const db = getDb();
    const student = db
      .prepare('SELECT id, dob_verification as dobVerification, email FROM students WHERE hall_ticket = ?')
      .get(hallTicket) as { id: number; dobVerification: string; email: string } | undefined;

    if (!student) {
      throw new ApiError(404, `No examination records found for hall ticket ${hallTicket}.`);
    }

    const semesterParam = req.query.semester ? Number(req.query.semester) : null;
    if (req.query.semester && (!Number.isInteger(semesterParam) || semesterParam! < 1)) {
      throw new ApiError(400, 'Semester parameter must be a positive integer.');
    }

    const resultRows = semesterParam
      ? (db
          .prepare(
            `SELECT sr.id
             FROM student_results sr
             JOIN semesters sem ON sem.id = sr.semester_id
             WHERE sr.student_id = ? AND sem.semester_number = ?`
          )
          .all(student.id, semesterParam) as Array<{ id: number }>)
      : (db
          .prepare(
            `SELECT sr.id
             FROM student_results sr
             JOIN semesters sem ON sem.id = sr.semester_id
             WHERE sr.student_id = ?
             ORDER BY sem.semester_number DESC`
          )
          .all(student.id) as Array<{ id: number }>);

    if (resultRows.length === 0) {
      throw new ApiError(
        404,
        semesterParam
          ? `No published results found for ${hallTicket} in Semester ${semesterParam}.`
          : `No published results found for ${hallTicket}.`
      );
    }

    const dobParam = typeof req.query.dob === 'string' ? req.query.dob.trim() : '';
    const isVerified = Boolean(dobParam && dobParam === student.dobVerification);

    const results = resultRows
      .map((r) => buildResultPayload(r.id))
      .filter((item): item is NonNullable<typeof item> => item !== null)
      .map((item) => ({
        ...item,
        student: {
          ...item.student,
          email: isVerified ? student.email : item.student.emailMasked,
          identityVerified: isVerified,
        },
      }));

    res.json({
      hallTicket,
      count: results.length,
      results,
      demoNotice:
        'DEMONSTRATION DATA: Records shown are synthetic demonstration results. Sample grading scale O=10, A+=9, A=8 applies.',
    });
  } catch (err) {
    next(err);
  }
}

export function getResultById(req: Request, res: Response, next: NextFunction): void {
  try {
    const resultId = Number(req.params.resultId);
    if (!Number.isInteger(resultId) || resultId < 1) {
      throw new ApiError(400, 'Invalid resultId parameter.');
    }

    const payload = buildResultPayload(resultId);
    if (!payload) {
      throw new ApiError(404, `Result record #${resultId} not found.`);
    }

    res.json(payload);
  } catch (err) {
    next(err);
  }
}

export function getStudentAnalytics(req: Request, res: Response, next: NextFunction): void {
  try {
    const hallTicket = sanitizeHallTicket(String(req.params.hallTicket || ''));
    if (!isValidHallTicketFormat(hallTicket)) {
      throw new ApiError(400, 'Invalid hall ticket format.');
    }

    const db = getDb();
    const student = db
      .prepare(
        `SELECT
           s.id,
           s.hall_ticket as hallTicket,
           s.full_name as fullName,
           d.code as departmentCode,
           d.name as departmentName,
           b.batch_code as batchCode
         FROM students s
         JOIN departments d ON d.id = s.department_id
         JOIN batches b ON b.id = s.batch_id
         WHERE s.hall_ticket = ?`
      )
      .get(hallTicket) as
      | {
          id: number;
          hallTicket: string;
          fullName: string;
          departmentCode: string;
          departmentName: string;
          batchCode: string;
        }
      | undefined;

    if (!student) {
      throw new ApiError(404, `Student ${hallTicket} not found.`);
    }

    const semesterHistory = db
      .prepare(
        `SELECT
           sr.id as resultId,
           sem.semester_number as semesterNumber,
           sem.title as semesterTitle,
           sr.academic_year as academicYear,
           sr.sgpa,
           sr.cgpa,
           sr.total_credits_attempted as creditsAttempted,
           sr.total_credits_earned as creditsEarned,
           sr.total_marks_obtained as totalMarksObtained,
           sr.total_max_marks as totalMaxMarks,
           sr.result_status as resultStatus
         FROM student_results sr
         JOIN semesters sem ON sem.id = sr.semester_id
         WHERE sr.student_id = ?
         ORDER BY sem.semester_number ASC`
      )
      .all(student.id) as Array<{
      resultId: number;
      semesterNumber: number;
      semesterTitle: string;
      academicYear: string;
      sgpa: number;
      cgpa: number;
      creditsAttempted: number;
      creditsEarned: number;
      totalMarksObtained: number;
      totalMaxMarks: number;
      resultStatus: string;
    }>;

    const gradeStats = db
      .prepare(
        `SELECT
           COUNT(sg.id) as totalSubjects,
           SUM(CASE WHEN sg.pass_status = 'PASS' THEN 1 ELSE 0 END) as subjectsPassed,
           SUM(CASE WHEN sg.pass_status != 'PASS' THEN 1 ELSE 0 END) as subjectsFailed,
           ROUND(AVG(sg.total_marks), 1) as averageScore
         FROM subject_grades sg
         JOIN student_results sr ON sr.id = sg.student_result_id
         WHERE sr.student_id = ?`
      )
      .get(student.id) as {
      totalSubjects: number;
      subjectsPassed: number | null;
      subjectsFailed: number | null;
      averageScore: number | null;
    };

    const latest = semesterHistory[semesterHistory.length - 1] || null;
    const previous = semesterHistory.length >= 2 ? semesterHistory[semesterHistory.length - 2] : null;
    const totalCreditsEarned = roundToTwo(
      semesterHistory.reduce((acc, s) => acc + s.creditsEarned, 0)
    );
    const sgpaDelta = latest && previous ? roundToTwo(latest.sgpa - previous.sgpa) : 0;

    res.json({
      student,
      kpis: {
        currentSgpa: latest ? latest.sgpa : 0,
        overallCgpa: latest ? latest.cgpa : 0,
        totalCreditsEarned,
        subjectsPassed: gradeStats?.subjectsPassed || 0,
        subjectsFailed: gradeStats?.subjectsFailed || 0,
        totalSubjectsEvaluated: gradeStats?.totalSubjects || 0,
        averageScore: gradeStats?.averageScore || 0,
        sgpaDeltaFromPrevious: sgpaDelta,
        semestersCompleted: semesterHistory.length,
      },
      semesterHistory,
      isDemoData: true,
    });
  } catch (err) {
    next(err);
  }
}

export function estimateStudentReevaluation(req: Request, res: Response, next: NextFunction): void {
  try {
    const hallTicket = sanitizeHallTicket(String(req.params.hallTicket || ''));
    if (!isValidHallTicketFormat(hallTicket)) {
      throw new ApiError(400, 'Invalid hall ticket format.');
    }

    const subjectCodes = Array.isArray(req.body?.subjectCodes)
      ? req.body.subjectCodes.map((c: unknown) => String(c).trim().toUpperCase()).filter(Boolean)
      : [];
    const feePerSubject = req.body?.feePerSubject !== undefined ? Number(req.body.feePerSubject) : 500;
    const processingFee = req.body?.processingFee !== undefined ? Number(req.body.processingFee) : 100;

    if (subjectCodes.length === 0) {
      throw new ApiError(400, 'Please select at least one subject for re-evaluation.');
    }

    const db = getDb();
    const placeholders = subjectCodes.map(() => '?').join(', ');
    const subjects = db
      .prepare(
        `SELECT subject_code as subjectCode, subject_name as subjectName
         FROM subjects
         WHERE subject_code IN (${placeholders})
         ORDER BY subject_code ASC`
      )
      .all(...subjectCodes) as Array<{ subjectCode: string; subjectName: string }>;

    if (subjects.length === 0) {
      throw new ApiError(404, 'No matching subjects found for estimation.');
    }

    const estimate = estimateReevaluationFee(subjects, feePerSubject, processingFee);
    res.json({
      hallTicket,
      ...estimate,
    });
  } catch (err) {
    next(err);
  }
}
