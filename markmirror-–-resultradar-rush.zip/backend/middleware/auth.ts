import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';

export type AdminRole = 'SUPER_ADMIN' | 'EXAM_CELL' | 'FACULTY';

export interface AuthTokenPayload {
  sub: number;
  username: string;
  fullName: string;
  role: AdminRole;
  departmentId: number | null;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthTokenPayload;
}

// Ephemeral fallback secret per process if JWT_SECRET env var is not configured
const RUNTIME_FALLBACK_SECRET = crypto.randomBytes(32).toString('hex');

function getJwtSecret(): string {
  const configured = process.env.JWT_SECRET;
  if (configured && configured.trim().length >= 16) {
    return configured.trim();
  }
  return RUNTIME_FALLBACK_SECRET;
}

export function signAdminToken(payload: AuthTokenPayload): string {
  return jwt.sign(payload, getJwtSecret(), { expiresIn: '12h' });
}

export function verifyAdminToken(token: string): AuthTokenPayload {
  const decoded = jwt.verify(token, getJwtSecret());
  if (typeof decoded === 'string' || !decoded) {
    throw new Error('Invalid token payload');
  }
  return decoded as unknown as AuthTokenPayload;
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({
      error: 'Authentication required',
      message: 'Provide a valid Bearer authorization token.',
    });
    return;
  }

  const token = authHeader.slice(7).trim();
  try {
    req.user = verifyAdminToken(token);
    next();
  } catch {
    res.status(401).json({
      error: 'Invalid or expired token',
      message: 'Session expired. Please sign in again.',
    });
  }
}

export function requireRole(...allowedRoles: AdminRole[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }
    if (!allowedRoles.includes(req.user.role)) {
      res.status(403).json({
        error: 'Forbidden',
        message: `Access restricted to roles: ${allowedRoles.join(', ')}`,
      });
      return;
    }
    next();
  };
}
