import type { NextFunction, Request, Response } from 'express';

export class ApiError extends Error {
  statusCode: number;
  details?: unknown;

  constructor(statusCode: number, message: string, details?: unknown) {
    super(message);
    this.statusCode = statusCode;
    this.details = details;
  }
}

export function sanitizeHallTicket(raw: string): string {
  return raw.trim().toUpperCase().replace(/[^A-Z0-9-]/g, '');
}

export function isValidHallTicketFormat(hallTicket: string): boolean {
  return /^[0-9]{2}[A-Z]{2,6}[0-9]{2,5}$/.test(hallTicket);
}

export function parsePositiveInt(value: unknown, fallback: number, max = 500): number {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 1) {
    return fallback;
  }
  return Math.min(parsed, max);
}

export function notFoundHandler(req: Request, res: Response): void {
  res.status(404).json({
    error: 'Not Found',
    message: `Route ${req.method} ${req.originalUrl} does not exist.`,
  });
}

export function errorHandler(
  err: unknown,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  if (err instanceof ApiError) {
    res.status(err.statusCode).json({
      error: err.message,
      details: err.details,
    });
    return;
  }

  if (err instanceof Error) {
    const isConstraint =
      err.message.includes('UNIQUE constraint') || err.message.includes('FOREIGN KEY constraint');
    if (isConstraint) {
      res.status(409).json({
        error: 'Database constraint conflict',
        message: 'A conflicting or invalid reference record was provided.',
      });
      return;
    }

    res.status(500).json({
      error: 'Internal Server Error',
      message: process.env.NODE_ENV === 'production' ? 'An unexpected error occurred.' : err.message,
    });
    return;
  }

  res.status(500).json({ error: 'Internal Server Error' });
}
