import express from 'express';
import { getDb } from './database/db.ts';
import { seedDatabaseIfEmpty } from './database/seed.ts';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.ts';
import adminRoutes from './routes/adminRoutes.ts';
import analyticsRoutes from './routes/analyticsRoutes.ts';
import resultRoutes from './routes/resultRoutes.ts';
import studentRoutes from './routes/studentRoutes.ts';

export function createApiApp() {
  const db = getDb();
  seedDatabaseIfEmpty(db);

  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'MarkMirror API', timestamp: new Date().toISOString() });
  });

  app.use('/api/students', studentRoutes);
  app.use('/api/results', resultRoutes);
  app.use('/api/analytics', analyticsRoutes);
  app.use('/api/admin', adminRoutes);

  app.use('/api/*', notFoundHandler);
  app.use(errorHandler);

  return app;
}
