PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS departments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  head_of_department TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS batches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_code TEXT NOT NULL UNIQUE,
  start_year INTEGER NOT NULL CHECK (start_year >= 2000 AND start_year <= 2100),
  end_year INTEGER NOT NULL CHECK (end_year > start_year),
  label TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1))
);

CREATE TABLE IF NOT EXISTS semesters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  semester_number INTEGER NOT NULL UNIQUE CHECK (semester_number >= 1 AND semester_number <= 10),
  title TEXT NOT NULL,
  academic_year TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS grading_scales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scale_name TEXT NOT NULL DEFAULT 'Sample Engineering Scale',
  letter_grade TEXT NOT NULL UNIQUE,
  grade_point REAL NOT NULL CHECK (grade_point >= 0 AND grade_point <= 10),
  min_marks INTEGER NOT NULL CHECK (min_marks >= 0 AND min_marks <= 100),
  max_marks INTEGER NOT NULL CHECK (max_marks >= min_marks AND max_marks <= 100),
  is_passing INTEGER NOT NULL DEFAULT 1 CHECK (is_passing IN (0, 1)),
  is_verified_rule INTEGER NOT NULL DEFAULT 0 CHECK (is_verified_rule IN (0, 1)),
  description TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS subjects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subject_code TEXT NOT NULL UNIQUE,
  subject_name TEXT NOT NULL,
  department_id INTEGER NOT NULL,
  semester_id INTEGER NOT NULL,
  credits REAL NOT NULL CHECK (credits >= 0 AND credits <= 12),
  max_internal INTEGER NOT NULL DEFAULT 30 CHECK (max_internal >= 0),
  max_external INTEGER NOT NULL DEFAULT 70 CHECK (max_external >= 0),
  pass_internal_min INTEGER NOT NULL DEFAULT 12 CHECK (pass_internal_min >= 0),
  pass_external_min INTEGER NOT NULL DEFAULT 28 CHECK (pass_external_min >= 0),
  pass_total_min INTEGER NOT NULL DEFAULT 40 CHECK (pass_total_min >= 0),
  is_credit_bearing INTEGER NOT NULL DEFAULT 1 CHECK (is_credit_bearing IN (0, 1)),
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT,
  FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  hall_ticket TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  department_id INTEGER NOT NULL,
  batch_id INTEGER NOT NULL,
  current_semester INTEGER NOT NULL DEFAULT 1 CHECK (current_semester >= 1 AND current_semester <= 10),
  dob_verification TEXT NOT NULL,
  email TEXT NOT NULL,
  is_demo_data INTEGER NOT NULL DEFAULT 1 CHECK (is_demo_data IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT,
  FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS student_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  semester_id INTEGER NOT NULL,
  academic_year TEXT NOT NULL,
  sgpa REAL NOT NULL CHECK (sgpa >= 0 AND sgpa <= 10),
  cgpa REAL NOT NULL CHECK (cgpa >= 0 AND cgpa <= 10),
  total_credits_attempted REAL NOT NULL CHECK (total_credits_attempted >= 0),
  total_credits_earned REAL NOT NULL CHECK (total_credits_earned >= 0),
  total_marks_obtained INTEGER NOT NULL CHECK (total_marks_obtained >= 0),
  total_max_marks INTEGER NOT NULL CHECK (total_max_marks > 0),
  result_status TEXT NOT NULL CHECK (result_status IN ('PASS', 'FAIL', 'ABSENT')),
  published_at TEXT NOT NULL DEFAULT (datetime('now')),
  is_demo_data INTEGER NOT NULL DEFAULT 1 CHECK (is_demo_data IN (0, 1)),
  UNIQUE (student_id, semester_id),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (semester_id) REFERENCES semesters(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS subject_grades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_result_id INTEGER NOT NULL,
  subject_id INTEGER NOT NULL,
  internal_marks INTEGER NOT NULL CHECK (internal_marks >= 0),
  external_marks INTEGER NOT NULL CHECK (external_marks >= 0),
  total_marks INTEGER NOT NULL CHECK (total_marks >= 0),
  letter_grade TEXT NOT NULL,
  grade_point REAL NOT NULL CHECK (grade_point >= 0 AND grade_point <= 10),
  credits REAL NOT NULL CHECK (credits >= 0),
  is_absent INTEGER NOT NULL DEFAULT 0 CHECK (is_absent IN (0, 1)),
  pass_status TEXT NOT NULL CHECK (pass_status IN ('PASS', 'FAIL', 'ABSENT')),
  UNIQUE (student_result_id, subject_id),
  FOREIGN KEY (student_result_id) REFERENCES student_results(id) ON DELETE CASCADE,
  FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS historical_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL,
  semester_number INTEGER NOT NULL CHECK (semester_number >= 1 AND semester_number <= 10),
  academic_year TEXT NOT NULL,
  sgpa REAL NOT NULL CHECK (sgpa >= 0 AND sgpa <= 10),
  cgpa REAL NOT NULL CHECK (cgpa >= 0 AND cgpa <= 10),
  credits_earned REAL NOT NULL CHECK (credits_earned >= 0),
  pass_status TEXT NOT NULL CHECK (pass_status IN ('PASS', 'FAIL', 'ABSENT')),
  recorded_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (student_id, semester_number),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS administrators (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('SUPER_ADMIN', 'EXAM_CELL', 'FACULTY')),
  department_id INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_students_hall_ticket ON students(hall_ticket);
CREATE INDEX IF NOT EXISTS idx_students_dept_batch ON students(department_id, batch_id);
CREATE INDEX IF NOT EXISTS idx_subjects_dept_sem ON subjects(department_id, semester_id);
CREATE INDEX IF NOT EXISTS idx_student_results_student_sem ON student_results(student_id, semester_id);
CREATE INDEX IF NOT EXISTS idx_subject_grades_result ON subject_grades(student_result_id);
CREATE INDEX IF NOT EXISTS idx_subject_grades_subject ON subject_grades(subject_id);
CREATE INDEX IF NOT EXISTS idx_historical_results_student ON historical_results(student_id, semester_number);
