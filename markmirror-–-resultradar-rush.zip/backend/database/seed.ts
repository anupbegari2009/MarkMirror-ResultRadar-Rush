import bcrypt from 'bcryptjs';
import type Database from 'better-sqlite3';
import {
  calculateCGPA,
  calculateSGPA,
  DEFAULT_GRADING_SCALE,
  type GradingScaleRule,
  type SubjectEvaluationConfig,
} from '../services/calculationService.ts';

interface SubjectSeedDef {
  code: string;
  name: string;
  credits: number;
  departmentCode: 'CSE' | 'ECE' | 'MECH';
  semesterNumber: number;
}

const FIRST_NAMES = [
  'Aarav', 'Aditi', 'Akash', 'Ananya', 'Arjun', 'Bhavna', 'Chaitanya', 'Deepika',
  'Devansh', 'Divya', 'Esha', 'Gaurav', 'Harini', 'Ishaan', 'Jahnvi', 'Karthik',
  'Kavya', 'Kiran', 'Lakshmi', 'Madhav', 'Manasa', 'Meera', 'Nikhil', 'Niharika',
  'Pranav', 'Priya', 'Rahul', 'Rhea', 'Rohan', 'Sahana', 'Sai', 'Sanya',
  'Siddharth', 'Sneha', 'Surya', 'Tanvi', 'Tarun', 'Vaishnavi', 'Varun', 'Vidya',
  'Vikram', 'Yash', 'Zoya', 'Abhinav', 'Amrita', 'Anirudh', 'Daksh', 'Garima',
  'Kunal', 'Nandini',
];

const LAST_NAMES = [
  'Sharma', 'Patel', 'Reddy', 'Nair', 'Iyer', 'Verma', 'Kulkarni', 'Gupta',
  'Rao', 'Menon', 'Joshi', 'Chopra', 'Deshmukh', 'Bhat', 'Agarwal', 'Bose',
  'Chatterjee', 'Das', 'Fernandes', 'Gowda', 'Hegde', 'Jain', 'Kapoor', 'Malhotra',
  'Mishra', 'Mukherjee', 'Naidu', 'Pandey', 'Pillai', 'Prasad', 'Rajput', 'Saxena',
  'Sen', 'Shetty', 'Singh', 'Sinha', 'Subramanian', 'Tiwari', 'Trivedi', 'Venkatesh',
];

function deterministicRand(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

function buildSubjectCatalog(): SubjectSeedDef[] {
  const catalog: SubjectSeedDef[] = [];

  // Semester 5 CSE: exact 6 subjects requested in project brief
  const cseSem5: Array<[string, string, number]> = [
    ['CS501', 'Mathematics', 4],
    ['CS502', 'DBMS', 4],
    ['CS503', 'Operating Systems', 4],
    ['CS504', 'Computer Networks', 3],
    ['CS505', 'Software Engineering', 3],
    ['CS506', 'AI Lab', 2],
  ];
  for (const [code, name, credits] of cseSem5) {
    catalog.push({ code, name, credits, departmentCode: 'CSE', semesterNumber: 5 });
  }

  // Semesters 1-4 for CSE
  const cseEarlier: Record<number, Array<[string, string, number]>> = {
    1: [
      ['CS101', 'Linear Algebra & Calculus', 4],
      ['CS102', 'Programming in C', 4],
      ['CS103', 'Engineering Physics', 4],
      ['CS104', 'Digital Logic Design', 3],
      ['CS105', 'Professional Communication', 3],
      ['CS106', 'Computing Workshop', 2],
    ],
    2: [
      ['CS201', 'Discrete Mathematics', 4],
      ['CS202', 'Data Structures', 4],
      ['CS203', 'Object-Oriented Programming', 4],
      ['CS204', 'Computer Organization', 3],
      ['CS205', 'Environmental Science', 3],
      ['CS206', 'Data Structures Lab', 2],
    ],
    3: [
      ['CS301', 'Probability & Statistics', 4],
      ['CS302', 'Design & Analysis of Algorithms', 4],
      ['CS303', 'Theory of Computation', 4],
      ['CS304', 'Microprocessors', 3],
      ['CS305', 'Web Technologies', 3],
      ['CS306', 'Algorithms Lab', 2],
    ],
    4: [
      ['CS401', 'Numerical Methods', 4],
      ['CS402', 'Compiler Design', 4],
      ['CS403', 'Machine Learning Foundations', 4],
      ['CS404', 'Distributed Systems', 3],
      ['CS405', 'Information Security', 3],
      ['CS406', 'Systems Programming Lab', 2],
    ],
  };
  for (const [semStr, list] of Object.entries(cseEarlier)) {
    const sem = Number(semStr);
    for (const [code, name, credits] of list) {
      catalog.push({ code, name, credits, departmentCode: 'CSE', semesterNumber: sem });
    }
  }

  // ECE Semesters 1-5
  const eceBySem: Record<number, Array<[string, string, number]>> = {
    1: [
      ['EC101', 'Engineering Mathematics I', 4],
      ['EC102', 'Basic Electrical Engineering', 4],
      ['EC103', 'Semiconductor Physics', 4],
      ['EC104', 'C Programming', 3],
      ['EC105', 'Technical Writing', 3],
      ['EC106', 'Electronics Workshop', 2],
    ],
    2: [
      ['EC201', 'Engineering Mathematics II', 4],
      ['EC202', 'Network Theory', 4],
      ['EC203', 'Electronic Devices', 4],
      ['EC204', 'Digital Electronics', 3],
      ['EC205', 'Engineering Mechanics', 3],
      ['EC206', 'Circuits Lab', 2],
    ],
    3: [
      ['EC301', 'Complex Analysis', 4],
      ['EC302', 'Analog Circuits', 4],
      ['EC303', 'Electromagnetic Fields', 4],
      ['EC304', 'Linear Integrated Circuits', 3],
      ['EC305', 'Data Structures', 3],
      ['EC306', 'Analog Circuits Lab', 2],
    ],
    4: [
      ['EC401', 'Random Processes', 4],
      ['EC402', 'Analog Communication', 4],
      ['EC403', 'Computer Architecture', 4],
      ['EC404', 'Antennas & Propagation', 3],
      ['EC405', 'Embedded C', 3],
      ['EC406', 'Communication Lab', 2],
    ],
    5: [
      ['EC501', 'Signals & Systems', 4],
      ['EC502', 'VLSI Design', 4],
      ['EC503', 'Microcontrollers', 4],
      ['EC504', 'Digital Communication', 3],
      ['EC505', 'Control Systems', 3],
      ['EC506', 'DSP Lab', 2],
    ],
  };
  for (const [semStr, list] of Object.entries(eceBySem)) {
    const sem = Number(semStr);
    for (const [code, name, credits] of list) {
      catalog.push({ code, name, credits, departmentCode: 'ECE', semesterNumber: sem });
    }
  }

  // MECH Semesters 1-5
  const mechBySem: Record<number, Array<[string, string, number]>> = {
    1: [
      ['ME101', 'Calculus & Differential Equations', 4],
      ['ME102', 'Engineering Mechanics', 4],
      ['ME103', 'Materials Science', 4],
      ['ME104', 'Engineering Graphics', 3],
      ['ME105', 'Chemistry for Engineers', 3],
      ['ME106', 'Workshop Practice', 2],
    ],
    2: [
      ['ME201', 'Vector Calculus', 4],
      ['ME202', 'Strength of Materials', 4],
      ['ME203', 'Basic Thermodynamics', 4],
      ['ME204', 'Manufacturing Processes I', 3],
      ['ME205', 'Electrical Machines', 3],
      ['ME206', 'Materials Testing Lab', 2],
    ],
    3: [
      ['ME301', 'Applied Numerical Methods', 4],
      ['ME302', 'Kinematics of Machinery', 4],
      ['ME303', 'Applied Thermodynamics', 4],
      ['ME304', 'Metallurgy', 3],
      ['ME305', 'Metrology & Measurements', 3],
      ['ME306', 'Metrology Lab', 2],
    ],
    4: [
      ['ME401', 'Operations Research', 4],
      ['ME402', 'Dynamics of Machinery', 4],
      ['ME403', 'Turbo Machinery', 4],
      ['ME404', 'Manufacturing Processes II', 3],
      ['ME405', 'Industrial Engineering', 3],
      ['ME406', 'Thermal Engineering Lab', 2],
    ],
    5: [
      ['ME501', 'Thermodynamics', 4],
      ['ME502', 'Fluid Mechanics', 4],
      ['ME503', 'Machine Design', 4],
      ['ME504', 'Heat Transfer', 3],
      ['ME505', 'Manufacturing Technology', 3],
      ['ME506', 'CAD/CAM Lab', 2],
    ],
  };
  for (const [semStr, list] of Object.entries(mechBySem)) {
    const sem = Number(semStr);
    for (const [code, name, credits] of list) {
      catalog.push({ code, name, credits, departmentCode: 'MECH', semesterNumber: sem });
    }
  }

  return catalog;
}

function splitTotalMarks(total: number, rng: () => number): { internal: number; external: number } {
  const clamped = Math.max(0, Math.min(100, Math.round(total)));
  if (clamped < 40) {
    const internal = Math.min(30, Math.max(8, Math.round(clamped * 0.35 + (rng() * 4 - 2))));
    const external = Math.max(0, clamped - internal);
    return { internal: Math.min(30, internal), external: Math.min(70, external) };
  }
  const internalRatio = 0.28 + rng() * 0.04;
  let internal = Math.round(clamped * internalRatio);
  internal = Math.max(14, Math.min(30, internal));
  let external = clamped - internal;
  if (external > 70) {
    internal += external - 70;
    external = 70;
  }
  if (external < 28 && clamped >= 40) {
    external = 28;
    internal = clamped - 28;
  }
  return { internal, external };
}

export function seedDatabaseIfEmpty(db: Database.Database): void {
  const existingDeptCount = (db.prepare('SELECT COUNT(*) as cnt FROM departments').get() as { cnt: number }).cnt;
  if (existingDeptCount > 0) {
    return;
  }

  const runSeed = db.transaction(() => {
    // 1. Departments
    const insertDept = db.prepare(
      'INSERT INTO departments (code, name, head_of_department) VALUES (?, ?, ?)'
    );
    const deptIds: Record<'CSE' | 'ECE' | 'MECH', number> = {
      CSE: Number(insertDept.run('CSE', 'Computer Science & Engineering', 'Dr. Arvind Raghavan').lastInsertRowid),
      ECE: Number(insertDept.run('ECE', 'Electronics & Communication Engineering', 'Dr. Meenakshi Iyer').lastInsertRowid),
      MECH: Number(insertDept.run('MECH', 'Mechanical Engineering', 'Dr. Vikramaditya Kulkarni').lastInsertRowid),
    };

    // 2. Batches
    const insertBatch = db.prepare(
      'INSERT INTO batches (batch_code, start_year, end_year, label, is_active) VALUES (?, ?, ?, ?, ?)'
    );
    const batchIds: Record<string, number> = {
      '2022-26': Number(insertBatch.run('2022-26', 2022, 2026, 'Batch 2022–2026 (Senior Cohort)', 1).lastInsertRowid),
      '2023-27': Number(insertBatch.run('2023-27', 2023, 2027, 'Batch 2023–2027 (Junior Cohort)', 1).lastInsertRowid),
      '2024-28': Number(insertBatch.run('2024-28', 2024, 2028, 'Batch 2024–2028 (Sophomore Cohort)', 1).lastInsertRowid),
    };

    // 3. Semesters
    const insertSem = db.prepare(
      'INSERT INTO semesters (semester_number, title, academic_year) VALUES (?, ?, ?)'
    );
    const semIds: Record<number, number> = {};
    const semAcademicYears: Record<number, string> = {
      1: '2022-23',
      2: '2022-23',
      3: '2023-24',
      4: '2023-24',
      5: '2024-25',
    };
    for (let s = 1; s <= 5; s++) {
      semIds[s] = Number(insertSem.run(s, `Semester ${s}`, semAcademicYears[s]).lastInsertRowid);
    }

    // 4. Grading Scales
    const insertScale = db.prepare(
      `INSERT INTO grading_scales
        (scale_name, letter_grade, grade_point, min_marks, max_marks, is_passing, is_verified_rule, description)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );
    for (const rule of DEFAULT_GRADING_SCALE) {
      insertScale.run(
        'Configurable Sample Engineering Scale',
        rule.letterGrade,
        rule.gradePoint,
        rule.minMarks,
        rule.maxMarks,
        rule.isPassing ? 1 : 0,
        rule.isVerifiedRule ? 1 : 0,
        rule.description || ''
      );
    }

    // 5. Subjects
    const insertSubject = db.prepare(
      `INSERT INTO subjects
        (subject_code, subject_name, department_id, semester_id, credits, max_internal, max_external, pass_internal_min, pass_external_min, pass_total_min, is_credit_bearing)
       VALUES (?, ?, ?, ?, ?, 30, 70, 12, 28, 40, 1)`
    );
    const subjectMap = new Map<string, { id: number; config: SubjectEvaluationConfig }>();
    const subjectsByDeptSem = new Map<string, Array<{ id: number; config: SubjectEvaluationConfig }>>();

    for (const item of buildSubjectCatalog()) {
      const deptId = deptIds[item.departmentCode];
      const semId = semIds[item.semesterNumber];
      const id = Number(
        insertSubject.run(item.code, item.name, deptId, semId, item.credits).lastInsertRowid
      );
      const config: SubjectEvaluationConfig = {
        subjectCode: item.code,
        subjectName: item.name,
        credits: item.credits,
        maxInternal: 30,
        maxExternal: 70,
        passInternalMin: 12,
        passExternalMin: 28,
        passTotalMin: 40,
        isCreditBearing: true,
      };
      const entry = { id, config };
      subjectMap.set(item.code, entry);
      const key = `${item.departmentCode}:${item.semesterNumber}`;
      const arr = subjectsByDeptSem.get(key) || [];
      arr.push(entry);
      subjectsByDeptSem.set(key, arr);
    }

    // 6. Students (120 total demonstration students)
    const insertStudent = db.prepare(
      `INSERT INTO students
        (hall_ticket, full_name, department_id, batch_id, current_semester, dob_verification, email, is_demo_data)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1)`
    );

    interface StudentSeedSpec {
      hallTicket: string;
      fullName: string;
      deptCode: 'CSE' | 'ECE' | 'MECH';
      batchCode: '2022-26' | '2023-27' | '2024-28';
      maxSem: number;
      dob: string;
      tierOffset: number; // controls natural distribution
      indexInCohort: number;
    }

    const studentsToSeed: StudentSeedSpec[] = [];
    const rng = deterministicRand(20261119);

    const makeName = (idx: number): string => {
      const first = FIRST_NAMES[idx % FIRST_NAMES.length];
      const last = LAST_NAMES[(idx * 7 + Math.floor(idx / 5)) % LAST_NAMES.length];
      return `${first} ${last}`;
    };

    const makeDob = (yearBase: number, idx: number): string => {
      const month = ((idx % 12) + 1).toString().padStart(2, '0');
      const day = (((idx * 3) % 27) + 1).toString().padStart(2, '0');
      return `${yearBase}-${month}-${day}`;
    };

    // CSE 2022-26: 50 students (22CSE101 - 22CSE150), with 22CSE104 specifically calibrated
    for (let i = 1; i <= 50; i++) {
      const ht = `22CSE${100 + i}`;
      if (ht === '22CSE104') {
        studentsToSeed.push({
          hallTicket: ht,
          fullName: 'Aarav Sharma',
          deptCode: 'CSE',
          batchCode: '2022-26',
          maxSem: 5,
          dob: '2004-05-14',
          tierOffset: 16,
          indexInCohort: i,
        });
      } else {
        // Create realistic distribution across 9-10, 8-9, 7-8, 6-7, <6
        let tierOffset = 0;
        if (i <= 5) tierOffset = 22; // Top 5 performers
        else if (i <= 16) tierOffset = 13;
        else if (i <= 32) tierOffset = 5;
        else if (i <= 43) tierOffset = -4;
        else tierOffset = -14;

        studentsToSeed.push({
          hallTicket: ht,
          fullName: makeName(i + 3),
          deptCode: 'CSE',
          batchCode: '2022-26',
          maxSem: 5,
          dob: makeDob(2004, i),
          tierOffset,
          indexInCohort: i,
        });
      }
    }

    // ECE 2022-26: 25 students
    for (let i = 1; i <= 25; i++) {
      const tierOffset = i <= 3 ? 20 : i <= 10 ? 10 : i <= 19 ? 2 : -10;
      studentsToSeed.push({
        hallTicket: `22ECE${100 + i}`,
        fullName: makeName(55 + i),
        deptCode: 'ECE',
        batchCode: '2022-26',
        maxSem: 5,
        dob: makeDob(2004, i + 10),
        tierOffset,
        indexInCohort: i,
      });
    }

    // MECH 2022-26: 20 students
    for (let i = 1; i <= 20; i++) {
      const tierOffset = i <= 2 ? 19 : i <= 8 ? 9 : i <= 15 ? 1 : -11;
      studentsToSeed.push({
        hallTicket: `22MECH${100 + i}`,
        fullName: makeName(85 + i),
        deptCode: 'MECH',
        batchCode: '2022-26',
        maxSem: 5,
        dob: makeDob(2004, i + 20),
        tierOffset,
        indexInCohort: i,
      });
    }

    // 2023-27 Batch: 10 CSE + 5 ECE (Semesters 1-3)
    for (let i = 1; i <= 10; i++) {
      const tierOffset = i <= 2 ? 19 : i <= 6 ? 9 : -2;
      studentsToSeed.push({
        hallTicket: `23CSE${100 + i}`,
        fullName: makeName(110 + i),
        deptCode: 'CSE',
        batchCode: '2023-27',
        maxSem: 3,
        dob: makeDob(2005, i),
        tierOffset,
        indexInCohort: i,
      });
    }
    for (let i = 1; i <= 5; i++) {
      studentsToSeed.push({
        hallTicket: `23ECE${100 + i}`,
        fullName: makeName(125 + i),
        deptCode: 'ECE',
        batchCode: '2023-27',
        maxSem: 3,
        dob: makeDob(2005, i + 7),
        tierOffset: i === 1 ? 16 : 6,
        indexInCohort: i,
      });
    }

    // 2024-28 Batch: 5 CSE + 5 MECH (Semester 1)
    for (let i = 1; i <= 5; i++) {
      studentsToSeed.push({
        hallTicket: `24CSE${100 + i}`,
        fullName: makeName(135 + i),
        deptCode: 'CSE',
        batchCode: '2024-28',
        maxSem: 1,
        dob: makeDob(2006, i),
        tierOffset: i === 1 ? 18 : 8,
        indexInCohort: i,
      });
    }
    for (let i = 1; i <= 5; i++) {
      studentsToSeed.push({
        hallTicket: `24MECH${100 + i}`,
        fullName: makeName(145 + i),
        deptCode: 'MECH',
        batchCode: '2024-28',
        maxSem: 1,
        dob: makeDob(2006, i + 5),
        tierOffset: i === 1 ? 14 : 4,
        indexInCohort: i,
      });
    }

    const insertResult = db.prepare(
      `INSERT INTO student_results
        (student_id, semester_id, academic_year, sgpa, cgpa, total_credits_attempted, total_credits_earned, total_marks_obtained, total_max_marks, result_status, is_demo_data)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`
    );
    const insertSubjectGrade = db.prepare(
      `INSERT INTO subject_grades
        (student_result_id, subject_id, internal_marks, external_marks, total_marks, letter_grade, grade_point, credits, is_absent, pass_status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    const insertHistorical = db.prepare(
      `INSERT INTO historical_results
        (student_id, semester_number, academic_year, sgpa, cgpa, credits_earned, pass_status)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    );

    const gradingScale: GradingScaleRule[] = DEFAULT_GRADING_SCALE;

    // Pre-assign exactly 16 indices in CSE 2022-26 Sem 5 to fail Operating Systems (34/50 = 68.0% pass rate!)
    // Specifically choose indices from lower/mid tiers (never 22CSE104 or top 5)
    const osFailIndices = new Set<number>([
      24, 29, 31, 34, 36, 38, 39, 41, 42, 43, 44, 45, 46, 47, 48, 49,
    ]); // Exactly 16 out of 50 -> 34 pass -> 68% pass rate!

    for (const spec of studentsToSeed) {
      const email = `${spec.hallTicket.toLowerCase()}@demo.markmirror.edu`;
      const studentId = Number(
        insertStudent.run(
          spec.hallTicket,
          spec.fullName,
          deptIds[spec.deptCode],
          batchIds[spec.batchCode],
          spec.maxSem,
          spec.dob,
          email
        ).lastInsertRowid
      );

      const batchStartYear = Number(spec.batchCode.split('-')[0]);
      const semSummaries: Array<{ semesterNumber: number; creditsAttempted: number; sgpa: number }> = [];

      for (let semNum = 1; semNum <= spec.maxSem; semNum++) {
        const subjectList = subjectsByDeptSem.get(`${spec.deptCode}:${semNum}`) || [];
        const academicYearOffset = Math.floor((semNum - 1) / 2);
        const acadStart = batchStartYear + academicYearOffset;
        const acadYear = `${acadStart}-${String((acadStart + 1) % 100).padStart(2, '0')}`;

        const markInputs = subjectList.map((subjEntry, subjIdx) => {
          const code = subjEntry.config.subjectCode;

          // Exact calibration for 22CSE104 Semester 5 => SGPA 8.85
          if (spec.hallTicket === '22CSE104' && semNum === 5) {
            const exactMarks: Record<string, [number, number]> = {
              CS501: [27, 65], // 92 => O (10) * 4 = 40
              CS502: [25, 59], // 84 => A+ (9) * 4 = 36
              CS503: [22, 52], // 74 => A (8) * 4 = 32
              CS504: [26, 57], // 83 => A+ (9) * 3 = 27
              CS505: [23, 52], // 75 => A (8) * 3 = 24
              CS506: [27, 60], // 87 => A+ (9) * 2 = 18
            };
            const [internalMarks, externalMarks] = exactMarks[code] || [24, 54];
            return { internalMarks, externalMarks, isAbsent: false, subject: subjEntry.config };
          }

          // Smooth historical progression for 22CSE104 Semesters 1-4
          if (spec.hallTicket === '22CSE104' && semNum < 5) {
            const semBase = 72 + semNum * 3;
            const total = semBase + ((subjIdx % 3) * 4);
            const split = splitTotalMarks(total, rng);
            return { internalMarks: split.internal, externalMarks: split.external, isAbsent: false, subject: subjEntry.config };
          }

          // Exact 68% pass rate calibration for CS503 Operating Systems (34 pass, 16 fail)
          if (code === 'CS503') {
            if (osFailIndices.has(spec.indexInCohort)) {
              const failTotal = 24 + Math.floor(rng() * 13); // 24..36 (FAIL)
              const split = splitTotalMarks(failTotal, rng);
              return { internalMarks: split.internal, externalMarks: split.external, isAbsent: false, subject: subjEntry.config };
            }
            const passBase = Math.max(46, Math.min(96, 68 + spec.tierOffset + Math.floor(rng() * 14 - 5)));
            const split = splitTotalMarks(passBase, rng);
            return { internalMarks: split.internal, externalMarks: split.external, isAbsent: false, subject: subjEntry.config };
          }

          // General subject performance with realistic difficulty variation
          const batchBump = spec.batchCode === '2023-27' ? 2 : spec.batchCode === '2024-28' ? 4 : 0;
          const difficultyPenalty =
            code.endsWith('01') || code.endsWith('03') ? -4 : code.endsWith('06') ? 8 : 0;

          let rawTotal = 69 + spec.tierOffset + batchBump + difficultyPenalty + Math.floor(rng() * 16 - 7);
          // Occasional realistic fail in lower tier for non-OS subjects (~8-14% fail rate)
          if (spec.tierOffset <= -10 && rng() < 0.25) {
            rawTotal = 26 + Math.floor(rng() * 12);
          } else if (rawTotal < 42 && spec.tierOffset > -10) {
            rawTotal = 44 + Math.floor(rng() * 8);
          }
          const split = splitTotalMarks(rawTotal, rng);
          return {
            internalMarks: split.internal,
            externalMarks: split.external,
            isAbsent: false,
            subject: subjEntry.config,
          };
        });

        const calc = calculateSGPA(markInputs, gradingScale);
        semSummaries.push({
          semesterNumber: semNum,
          creditsAttempted: calc.totalCreditsAttempted,
          sgpa: calc.sgpa,
        });
        const runningCgpa = calculateCGPA(semSummaries);

        const resultId = Number(
          insertResult.run(
            studentId,
            semIds[semNum],
            acadYear,
            calc.sgpa,
            runningCgpa,
            calc.totalCreditsAttempted,
            calc.totalCreditsEarned,
            calc.totalMarksObtained,
            calc.totalMaxMarks,
            calc.resultStatus
          ).lastInsertRowid
        );

        for (let i = 0; i < calc.subjects.length; i++) {
          const computed = calc.subjects[i];
          const subjEntry = subjectList[i];
          insertSubjectGrade.run(
            resultId,
            subjEntry.id,
            computed.internalMarks,
            computed.externalMarks,
            computed.totalMarks,
            computed.letterGrade,
            computed.gradePoint,
            computed.credits,
            computed.isAbsent ? 1 : 0,
            computed.passStatus
          );
        }

        insertHistorical.run(
          studentId,
          semNum,
          acadYear,
          calc.sgpa,
          runningCgpa,
          calc.totalCreditsEarned,
          calc.resultStatus
        );
      }
    }

    // 7. Administrators
    const defaultPassword = process.env.SEED_ADMIN_PASSWORD || 'MarkMirror@2026';
    const adminHash = bcrypt.hashSync(defaultPassword, 10);
    const facultyHash = bcrypt.hashSync(defaultPassword, 10);

    const insertAdmin = db.prepare(
      `INSERT INTO administrators (username, full_name, email, password_hash, role, department_id)
       VALUES (?, ?, ?, ?, ?, ?)`
    );
    insertAdmin.run(
      'admin',
      'Controller of Examinations',
      'coe@demo.markmirror.edu',
      adminHash,
      'SUPER_ADMIN',
      null
    );
    insertAdmin.run(
      'faculty_cse',
      'Dr. Arvind Raghavan',
      'hod.cse@demo.markmirror.edu',
      facultyHash,
      'FACULTY',
      deptIds.CSE
    );
  });

  runSeed();
}
