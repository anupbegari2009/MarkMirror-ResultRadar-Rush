import { Router } from 'express';
import {
  getBatchComparisonHandler,
  getCgpaDistributionHandler,
  getFiltersMetadata,
  getGradingScaleMetadata,
  getOverview,
  getPassRates,
  getSubjectDifficulty,
  getToppers,
} from '../controllers/analyticsController.ts';

const router = Router();

router.get('/overview', getOverview);
router.get('/pass-rates', getPassRates);
router.get('/toppers', getToppers);
router.get('/cgpa-distribution', getCgpaDistributionHandler);
router.get('/subject-difficulty', getSubjectDifficulty);
router.get('/batch-comparison', getBatchComparisonHandler);
router.get('/filters', getFiltersMetadata);
router.get('/grading-scale', getGradingScaleMetadata);

export default router;
