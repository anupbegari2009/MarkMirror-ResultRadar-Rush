import { Router } from 'express';
import { getResultById } from '../controllers/studentController.ts';

const router = Router();

router.get('/:resultId', getResultById);

export default router;
