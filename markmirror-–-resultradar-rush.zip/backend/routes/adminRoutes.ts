import { Router } from 'express';
import {
  createResult,
  createStudent,
  createSubject,
  deleteResult,
  getCurrentAdmin,
  listResults,
  listStudents,
  listSubjects,
  loginAdmin,
  updateResult,
} from '../controllers/adminController.ts';
import { requireAuth, requireRole } from '../middleware/auth.ts';

const router = Router();

// Auth routes
router.post('/auth/login', loginAdmin);
router.get('/auth/me', requireAuth, getCurrentAdmin);

// Protected Admin & Faculty endpoints
router.get('/students', requireAuth, requireRole('SUPER_ADMIN', 'EXAM_CELL', 'FACULTY'), listStudents);
router.post('/students', requireAuth, requireRole('SUPER_ADMIN', 'EXAM_CELL'), createStudent);

router.get('/subjects', requireAuth, requireRole('SUPER_ADMIN', 'EXAM_CELL', 'FACULTY'), listSubjects);
router.post('/subjects', requireAuth, requireRole('SUPER_ADMIN', 'EXAM_CELL'), createSubject);

router.get('/results', requireAuth, requireRole('SUPER_ADMIN', 'EXAM_CELL', 'FACULTY'), listResults);
router.post('/results', requireAuth, requireRole('SUPER_ADMIN', 'EXAM_CELL'), createResult);
router.put('/results/:resultId', requireAuth, requireRole('SUPER_ADMIN', 'EXAM_CELL'), updateResult);
router.delete('/results/:resultId', requireAuth, requireRole('SUPER_ADMIN'), deleteResult);

export default router;
