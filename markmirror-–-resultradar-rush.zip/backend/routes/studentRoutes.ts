import { Router } from 'express';
import {
  estimateStudentReevaluation,
  getStudentAnalytics,
  getStudentByHallTicket,
  getStudentResults,
  verifyStudentIdentity,
} from '../controllers/studentController.ts';

const router = Router();

router.get('/:hallTicket', getStudentByHallTicket);
router.post('/:hallTicket/verify', verifyStudentIdentity);
router.get('/:hallTicket/results', getStudentResults);
router.get('/:hallTicket/analytics', getStudentAnalytics);
router.post('/:hallTicket/reevaluation-estimate', estimateStudentReevaluation);

export default router;
